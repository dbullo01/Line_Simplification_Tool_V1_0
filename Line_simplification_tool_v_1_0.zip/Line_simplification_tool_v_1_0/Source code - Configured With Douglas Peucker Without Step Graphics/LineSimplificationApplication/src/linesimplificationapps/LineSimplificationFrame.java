

package linesimplificationapps;

import java.awt.event.*;
import java.awt.event.MouseAdapter;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.util.ArrayList;
import java.awt.*;
import java.awt.geom.Line2D;
import java.util.LinkedHashSet;
import java.util.List;
import javax.swing.JOptionPane;


public class LineSimplificationFrame extends javax.swing.JFrame implements ItemListener {
    private ArrayList<Point> points;  //Original line
    private ArrayList<Point> points2; //Simplified Line
    private ArrayList<Point> points3; //copy of points for ChkOriginalLineButton
    private ArrayList<Point> points4; //copy of points2 for ChkSimplifiedLineButton
    private ArrayList<Liner> lines;
    private ArrayList<Point> circles;
    private ArrayList<Liner> perpendicularLines; 
    private ArrayList<Liner> simplifiedLines;    
    private ArrayList<Liner> perpendicularLinesLargerThanThreshold;
    private ArrayList<Polygon> effectiveAreaTriangles;
    private Polygon smallestEffectiveAreaTriangle;
    private ArrayList<Polygon> smallestEffectiveAreaTriangles;
    private double effectiveArea;
    private double minEffectiveArea;
    private MouseListener mouseListener;
    private final DisplayPanel panel2;
    private LineSimplification ls;
    private LinePerformance lp;
    private int count;
    private int i;
    private int minAreaIndex;
    private Point intermediatePoint;
    private ArrayList<Point> areacircles;
    private int radialDistance;
    private Point pointToDelete;
    private ArrayList<Liner> sleevesList;  
    private ArrayList<Liner> sleeve;       
    private ArrayList<Point> simplifiedLine;
    private ArrayList<Liner> pointList1DistortionLines; 
    private int keyPoint;
    private double maximumPerpendicularDistance;
    private int endPoint;
    private int lookAhead;
    private ArrayList<Point> searchRegion;
    private int iterations;
    private FileWrite fw;
    private ArrayList<ArrayList<Point>> listOfLists1;
    private ArrayList<ArrayList<Point>> listOfLists2;
    private ArrayList<Liner> resultLine1;
    private ArrayList<Liner> resultLine2;
    private ArrayList<ArrayList<Point>> individualDPSteps;
    private ArrayList<ArrayList<Point>> lineSegments;
    
    /**
     * Display Panel Class
     * 
     */
    public class DisplayPanel extends JPanel
    {  

        ///** The Constant FRAME_WIDTH & HEIGHT. */   
        private static final int FRAME_WIDTH =  600;
        private static final int FRAME_HEIGHT = 600;

        public DisplayPanel(){       
            //setSize(FRAME_WIDTH, FRAME_HEIGHT);           
        }
    }
   
    
    /** Creates new form LineSimplificationFrame*/
    public LineSimplificationFrame() {
        initComponents();
        this.points = null;     
        this.points2 = null;    
        this.points3 = null;   
        this.points4 = null;   
        this.lines = null;
        this.circles = null;
        this.perpendicularLines = null; 
        this.simplifiedLines = null;    
        this.perpendicularLinesLargerThanThreshold = null;
        this.effectiveAreaTriangles = null;
        this.ls = null;
        this.lp = null;
        this.count = 0;
        this.effectiveArea = 0;
        this.minEffectiveArea = 0;
        this.mouseListener = null;
        this.panel2 = null;
        this.ls = null;
        this.count = 0;
        this.i = 0;
        this.minAreaIndex = 0;
        this.intermediatePoint = null;
        this.areacircles = null;
        this.radialDistance = 0;
        this.pointToDelete = null;
        this.sleevesList = null;
        this.sleeve = null;
        this.simplifiedLine = null;
        this.pointList1DistortionLines = null;
        this.keyPoint = 0;
        this.maximumPerpendicularDistance = 0;
        this.endPoint = 0;
        this.lookAhead = 0;
        this.searchRegion = null;
        this.iterations = 0;
        this.fw = new FileWrite();
        this.listOfLists1 = null;
        this.listOfLists2 = null;
        this.resultLine1 = null;
        this.resultLine2 = null;
        this.individualDPSteps = null;
        this.lineSegments = null;
    }
    
    @Override
    public void itemStateChanged(ItemEvent e) {
        if (chkOriginalLineButton.isSelected()){
            setPoints2(getPoints2());
            repaint();
        }
        else{
            setPoints3(getPoints3());
            repaint();
        }
    }
   
    /**
     * getLineSegments
     * @return lineSegments - Collection of collection of points
     */
    public ArrayList<ArrayList<Point>> getLineSegments(){
        return this.lineSegments;
    }
    
   /**
     * setLineSegments
     * @param lineSegments - Collection of collection of points
     */
    public void setLineSegments(
            ArrayList<ArrayList<Point>> lineSegments){
        this.lineSegments = lineSegments;
    }
    
    
    
    
    /**
     * getIndividualDPSteps
     * @return individualDPSteps - Collection of collection of points
     */
    public ArrayList<ArrayList<Point>> getIndividualDPSteps(){
        return this.individualDPSteps;
    }
    
   /**
     * setIndividualDPSteps
     * @param individualDPSteps - Collection of collection of points
     */
    public void setIndividualDPSteps(
            ArrayList<ArrayList<Point>> individualDPSteps){
        this.individualDPSteps = individualDPSteps;
    }
    
    
    /**
     * getResultLine1
     * @return resultLine1 - Collection of lines
     */
    public ArrayList<Liner> getResultLine1(){
        return this.resultLine1;
    }
    
    
    /**
     * getResultLine1
     * @param resultLine1 - Collection of lines
     */
    public void setResultLine1(ArrayList<Liner> resultLine1){
        this.resultLine1 = resultLine1;
    }
    
    /**
     * getResultLine2
     * @return Liner - Collections of lines 
     */
    
    public ArrayList<Liner> getResultLine2(){
        return this.resultLine2;
    }
    
    /**
     * setResultLine2
     * @param resultLine2 - Collection relating to result lines 
     */
    public void setResultLine2(ArrayList<Liner> resultLine2){
        this.resultLine2 = resultLine2;
    }
    
    /**
     * getListOfLists1
     * @return listOfLists - Collection of point lists
     */
    public ArrayList<ArrayList<Point>> getListOfLists1(){
        return this.listOfLists1;    
    }
    
    /**
     * setListOfLists1
     * @param listOfLists1 - Collection of point lists
     */
    public void setListOfLists1(ArrayList<ArrayList<Point>> listOfLists1){
        this.listOfLists1 = listOfLists1;    
    }
    
    /**
     * getListOfLists2
     * @return listOfLists2 - Collection of point lists
     */
    public ArrayList<ArrayList<Point>> getListOfLists2(){
        return this.listOfLists2;    
    }
    
    /**
     * setListOfLists2
     * @param listOfLists2 - Collection of point lists 
     */
    public void setListOfLists2(ArrayList<ArrayList<Point>> listOfLists2){
        this.listOfLists2 = listOfLists2;    
    }
    
   
    /**
    * get Search Region
    * @return searchRegion - Collection of points representing search region
    */
    public ArrayList<Point> getSearchRegion(){
        return this.searchRegion;
    }
    
    /**
    * set Search Region
    * @param searchRegion - Collection of points representing search region
    */
    public void setSearchRegion(ArrayList<Point> searchRegion){
        this.searchRegion = searchRegion;
    }
    
    /**
     * get Look Ahead
     * @return lookAhead - Value representing size for searchRegion 
     */
    public int getLookAhead(){
        return this.lookAhead;
    }
    
    /**
     * set Look Ahead
     * @param lookAhead - Value representing size for searchRegion
     */
    public void setLookAhead(int lookAhead){
        this.lookAhead = lookAhead;
    }
    
    /**
     * Get EndPoint
     * @return endPoint - Point representing end point of a line
     */
    public int getEndPoint(){
        return this.endPoint;
    }
    
    /**
     * set EndPoint
     * @param endPoint - Point representing end point of a line
     */
    public void setEndPoint(int endPoint){
        this.endPoint = endPoint;
    }
    
    /**
     * Get Maximum Perpendicular Distance
     * @return double - Value representing Maximum Perpendicular Distance
     */
    public double getMaximumPerpendicularDistance(){
        return this.maximumPerpendicularDistance;
    }
    
    
    /**
     * Set Maximum Perpendicular Distance
     * @param maximumPerpendicularDistance - Value representing Maximum 
     * Perpendicular Distance
     */
    public void setMaximumPerpendicularDistance(double 
            maximumPerpendicularDistance){
        this.maximumPerpendicularDistance = maximumPerpendicularDistance;
    }
    
    /**
     * Get KeyPoint
     * @return integer - Value representing index position of Key Point
     */
    public int getKeyPoint(){
        return this.keyPoint;
    }
    
    /**
     * set KeyPoint
     * @param keyPoint - Value representing index position of Key Point
     */
    public void setKeyPoint(int keyPoint){
        this.keyPoint = keyPoint;
    }
    
    /**
     * get PointList1 Distortion Lines
     * @return Liner - Lines representing distortion lines
     */
    public ArrayList<Liner> getPointList1DistortionLines(){
        return this.pointList1DistortionLines;
    }
    
    /**
    * set PointList1DistortionLines
    * @param pointList1DistortionLines - Lines representing distortion lines
    */
    public void setPointList1DistortionLines(ArrayList<Liner> pointList1DistortionLines){
        this.pointList1DistortionLines = pointList1DistortionLines;
    }

    /**
     * get Sleeves List
     * @return Liner - Lines representing the 4 sides of a sleeve
     */
    public ArrayList<Liner> getSleevesList(){   
        return this.sleevesList;
    }

    /**
     * set Sleeves List
     * @param sleevesList - Lines representing the 4 sides of a sleeve
     */
    public void setSleevesList(ArrayList<Liner> sleevesList){
        this.sleevesList = sleevesList;
    }

    /**
     * get Sleeve
     * @return Liner - Lines representing the 4 sides of a sleeve
     */
    public ArrayList<Liner> getSleeve(){
        return this.sleeve;
    }

    /**
     * set Sleeve
     * @param sleeve - Lines representing the 4 sides of a sleeve 
     */
    public void setSleeve(ArrayList<Liner> sleeve){
        this.sleeve = sleeve;
    }
    
    /**
     * get Simplified Line
     * @return simplifiedLine - Points representing a simplified line
     */
    public ArrayList<Point> getSimplifiedLine(){
        return this.simplifiedLine;
    }
    
    /**
     * set Simplified Line
     * @param simplifiedLine - Points representing a simplified line
     */
    public void setSimplifiedLine(ArrayList<Point> simplifiedLine){
        this.simplifiedLine = simplifiedLine;
    }

    /**
     * set Count
     * @param count - Value representing the count
     */
    public void setCount(int count){
        this.count = count;
    }   
    
    /**
     * get Count
     * @return count - Value representing the count
     */
    public int getCount(){
        return this.count;
    }
    
    /**
     * setI
     * @param i - Value representing counter value
     */
    public void setI(int i){
        this.i = i;
    }   
    
    /**
     * getI
     * @return i - Value representing a counter value
     */
    public int getI(){
        return this.i;
    }
    
    /**
     *  Get PerpendicularLines
     *  @return perpendicularLines - Line(s) representing perpendicular line(s)
     */
    public ArrayList<Liner> getPerpendicularLines(){
        return this.perpendicularLines;
    }

    /**
     * Set perpendicularLines
     * @param perpendicularLines - Line(s) representing perpendicular line(s)
     */
    public void setPerpendicularLines(ArrayList<Liner> perpendicularLines){
        this.perpendicularLines = perpendicularLines;
    }

    
     /**
     *  Get SimplifiedLines
     *  @return simplifiedLines - Line(s) representing perpendicular line(s)
     */
    public ArrayList<Liner> getSimplifiedLines(){
        return this.simplifiedLines;
    }

    /**
     * Set SimplflifiedLines
     * @param simplifiedLines - Line(s) representing perpendicular line(s)
     */
    public void setSimplifiedLines(ArrayList<Liner> simplifiedLines){
        this.simplifiedLines = simplifiedLines;
    }
    
    /**
     * get Perpendicular Lines Larger Than Threshold
     * @return liner - Line(s) representing perpendicular line(s)
     */
    public ArrayList<Liner> getPerpendicularLinesLargerThanThreshold(){
        return this.perpendicularLinesLargerThanThreshold;    
    }
    
    /**
     * set Perpendicular Lines Larger Than Threshold
     * @param perpendicularLinesLargerThanThreshold - Lines representing 
     * perpendicular lines greater than the threshold tolerance
     */
     public void setPerpendicularLinesLargerThanThreshold(ArrayList<Liner> 
             perpendicularLinesLargerThanThreshold){
        this.perpendicularLinesLargerThanThreshold = 
                perpendicularLinesLargerThanThreshold;
    }
    
     /**
      * get Effective Area Triangles
      * @return polygon - Polygon(s) representing effective area triangle(s)
      */
    public ArrayList<Polygon> getEffectiveAreaTriangles(){
        return this.effectiveAreaTriangles;
    }
    
    /**
     * set Effective Area Triangles
     * @param effectiveAreaTriangles - Polygon(s) representing effective area 
     * triangle(s)
     */
    public void setEffectiveAreaTriangles(ArrayList<Polygon> effectiveAreaTriangles){
        this.effectiveAreaTriangles = effectiveAreaTriangles; 
    }
    
    /**
     * get Effective area
     * @return double - Value representing the area of the effective area
     */
    public double getEffectiveArea(){
        return this.effectiveArea;
    }
    
    /**
     * set Effective Area
     * @param effectiveArea - Value representing the area of the effective area 
     */
    public void setEffectiveArea(double effectiveArea){
        this.effectiveArea = effectiveArea;
    }
    
    /**
     * get Min Effective Area
     * @return double - Value representing the minimum effective area
     */
    public double getMinEffectiveArea(){
        return this.minEffectiveArea;
    }
    
    /**
     * set Min EFfective Area
     * @param minEffectiveArea - Value representing the minimum effective area
     */
    public void setMinEffectiveArea(double minEffectiveArea){
        this.minEffectiveArea = minEffectiveArea;
    }
    
    /**
     * get Intermediate Point
     * @return intermediatePoint - Point representing an intermediate point
     * of a line (not start or end point of a line).
     */
    public Point getIntermediatePoint(){
        return this.intermediatePoint;
    }
    
    /**
     * set Intermediate Point
     * @param intermediatePoint - Point representing an intermediate 
     * point of a line (not start or end point of a line)
     */
    public void setIntermediatePoint(Point intermediatePoint){
        this.intermediatePoint = intermediatePoint;
    }
    
    
    /**
     * Get Points
     * @return points - Points representing original line points 
     */
    public ArrayList<Point> getPoints(){
        return this.points;
    }

    /**
     * Get Points 2
     * @return points2 - Points representing simplified line points
     */
    public ArrayList<Point> getPoints2(){
        return this.points2;
    }

    /**
     * Get Points 3
     * @return points3 - Points representing a copy of the original line points
     */

    public ArrayList<Point> getPoints3(){
        return this.points3;
    }

    /**
     * Get Points 4
     * @return points4 - Points representing a copy of the simplified line 
     * points
     */

    public ArrayList<Point> getPoints4(){
        return this.points4;
    }
    
    
    /**
     * Get Lines
     * @return lines - Lines representing general lines
     */
    public ArrayList<Liner> getLines(){
        return this.lines;
    }

    /**
     * Set points 1
     * @param points - Points representing original line points
     */
    public void setPoints (ArrayList<Point> points){
        this.points = points;    
    }

    /**
     * Set points 2
     * @param points - Points representing simplified line points 
     */
    public void setPoints2 (ArrayList<Point> points){
        this.points2 = points;    
    }

    /**
     * Set points 3
     * @param points - Points representing a copy of the original line points
     */
    public void setPoints3 (ArrayList<Point> points){
        this.points3 = points;    
    }

    /**
     * Set points 4
     * @param points - Points representing a copy of the simplified line points 
     */
    public void setPoints4 (ArrayList<Point> points){
        this.points4 = points;    
    }
        
    /**
     * Set liner
     * @param lines - Lines representing general lines
     */
    public void setLiners (ArrayList<Liner> lines){
        this.lines = lines;    
    }

     /**
     * get circles
     * @return circles - Points representing the centre point(s)
     *                   of where circle(s) are drawn
     */
    public ArrayList<Point> getCircles(){
        return this.circles;
    }
    
    
     /**
     * Set circles
     * @param circles - Point(s) representing the centre point(s)
     *                  of where circle(s) are drawn
     */
    public void setCircles(ArrayList<Point> circles){
        this.circles = circles;
    }
    
    /**
    * Get area circles
    * @return areacircles - Point(s) representing the centre point(s)
    *                      of where area circle(s) are drawn   
    */
    public ArrayList<Point> getAreaCircles(){
        return this.areacircles;
    }
    
    
    
    /**
    * set area circles
    * @param areacircles - Point(s) representing the centre point(s)
    *                      of where area circle(s) are drawn   
    */
    public void setAreaCircles(ArrayList<Point> areacircles){
        this.areacircles = areacircles;
    }
    
    /**
    * get min area index
    * @return minAreaIndex - Value representing Min Area Index   
    */
    public int getMinAreaIndex(){
        return this.minAreaIndex;
    }
    
    
    /**
    * set min area circles
    * @param minAreaIndex - Value representing Min Area Index
    */
    public void setMinAreaIndex(int minAreaIndex){
        this.minAreaIndex = minAreaIndex;
    }
    
    
    /**
    * set radial distance
    * @param radialDistance - Value representing radial distance
    */
    public void setRadialDistance(int radialDistance){
        this.radialDistance = radialDistance;
    }
    
    /**
    * get radial distance
    * @return radialDistance - Value representing radial distance
    */
    public int getRadialDistance(){
        return this.radialDistance; 
    }
    
    /**
    * set point to delete
    * @param pointToDelete - Point representing point to delete in a line
    */
    public void setPointToDelete(Point pointToDelete){
        this.pointToDelete = pointToDelete;
    }
     
    /**
    * get point to delete
    * @return pointToDelete - Point representing point to delete in a line
    */
    public Point getPointToDelete(){
        return this.pointToDelete;
    }
    
    
    /**
    * get jTextAreaCommentary text
    * @return jTextAreaCommentary - String value representing text in the 
    *                               JTextAreaCommentray control
    */
     public String getJTextAreaCommentary(){
       return this.jTextAreaCommentary.getText();
    }
    
    /**
    * set jTextAreaCommentary text
    * @param string - String value representing text in the 
    *                               JTextAreaCommentray control
    */
    public void setJTextAreaCommentary(String string){
        this.jTextAreaCommentary.setText(string);
    }
    
    
    /**
    * setTxtRadialDistance text
    * @param txtRadialDistance - String value representing Radial Distance
    */
    public void setTxtRadialDistance(String txtRadialDistance){
        this.txtRadialDistance.setText(txtRadialDistance);
    }
    
    
    /**
    * getTxtNthPoint text
    * @return txtNthPoint - String value representing Nth Point Value
    */
    public String getTxtNthPoint(){
        return this.txtNthPoint.getText();
    }
    
    
    
    /**
     * setTxtNthPoint text
     * @param txtNthPoint - String value representing Nth Point Value
     */
    public void setTxtNthPoint(String txtNthPoint){
        this.txtNthPoint.setText(txtNthPoint);
    }
    
   
    /**
    * getTxtNoOfPoints text
    * @return txtNoOfPoints - String value representing No of Points
    */
    public String getTxtNoOfPoints(){
        return this.txtNoOfPoints.getText();
    }
    
    /**
     * setTxtNoOfPoints text
     * @param txtNoOfPoints - String value representing No of Points 
     */
    public void setTxtNoOfPoints(String txtNoOfPoints){
        this.txtNoOfPoints.setText(txtNoOfPoints);
    }
    
    
    /**
    * getTxtPerpendicularDistance text
    * @return txtPerpendicularDistance - String value representing perpendicular
    * distance
    */
    public String getTxtPerpendicularDistance(){
        return this.txtPerpendicularDistance.getText();
    }
    
    /**
    * getTxtPerpendicularDistance text
    * @param txtPerpendicularDistance - String value representing perpendicular
    * distance
    */
    public void setTxtPerpendicularDistance(String txtPerpendicularDistance){
        this.txtPerpendicularDistance.setText(txtPerpendicularDistance);
    }
    
    /**
    * getTxtRadialDistance text
    * @return txtRadialDistance - String value representing radial distance
    */
    public String getTxtRadialDistance(){
        return this.txtRadialDistance.getText();
    }
    
    /**
    * getTxtHeight text
    * @return txtHeight - String value representing height of a Sleeve
    */
    public String getTxtHeight(){
        return this.txtHeight.getText();
    }

    /**
    * setTxtHeight text
    * @param txtHeight - String value representing height of a Sleeve
    */
    public void setTxtHeight(String txtHeight){
        this.txtHeight.setText(txtHeight);
    }
    
    /**
    * getTxtWidth text
    * @return txtWidth - String value representing width of a Sleeve 
    */
    public String getTxtWidth(){
        return this.txtWidth.getText();
    }
    
    /**
     * setTxtWidth text
     * @param txtWidth - String value representing a width of a Sleeve
     */
    public void setTxtWidth(String txtWidth){
        this.txtWidth.setText(txtWidth);
    }
    
    
     /**
     * Capture Points
     * Allows capturedPoints to be captured as pointID, X, Y coords and stored
     * in original line points array list
     * 
     * @param e - Mouse Event object
     * @param count - Value for count
     * @return point - Point presenting where user clicked
     */

    public Point capturePointClicked(MouseEvent e, int count){
        int x = e.getX();
        //int y = 600 - e.getY();
        int y = 640 - e.getY();
        String strCoord = "p" + count + "," + x + "," +  y;
        System.out.println(strCoord);
        Point p = new Point(strCoord);
        return p;
    } 
    

     /**
     * Write To Text Area Commentary
     * 
     * @param string - Value to write to JTextAreaCommentary control
     */

    public void writeToTextAreaCommentary(String string){
        jTextAreaCommentary.append(string);
        jTextAreaCommentary.setLineWrap(true);
        jTextAreaCommentary.setWrapStyleWord(true);
    }
    
    /**
    * Write Start Up Text To Text Area Commentary
    * 
    */
    public void writeStartUpTextToTextAreaCommentary(){
    
    String newLine = "\n";
   
    writeToTextAreaCommentary( 
        "*************************************************************" 
                + newLine);
    writeToTextAreaCommentary(
        "           LINE SIMPLIFICATION LEARNING TOOL V1.0          " 
                + newLine);    
    writeToTextAreaCommentary(
        "                                                           "
                + newLine);
    writeToTextAreaCommentary(
        "                                   By Davison Bullock      "
                + newLine);                      
    writeToTextAreaCommentary("" 
        + "                                             Sept 2016   " 
        + newLine);
    writeToTextAreaCommentary(
        "*************************************************************" 
                + newLine);
    writeToTextAreaCommentary(
        "This tool allows users to learn about Common " + newLine);
    writeToTextAreaCommentary(
        "Point Line Simplification algorithms." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(
        "Users can assess algorithm(s) for their strengths " + 
    "and weaknesses using the given line metrics and " +
    "line performance measures and by interacting " + 
    "with the system during the selected algorithms " + 
    "processing steps to see how the algorithm works. " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("KEY FEATURES:" + newLine);
    writeToTextAreaCommentary("ALGORITHMS" + newLine);
    writeToTextAreaCommentary("-------------------" + newLine);
    writeToTextAreaCommentary("Nth Point " + newLine);
    writeToTextAreaCommentary("Routine of Perpendicular Distance "
        + newLine);
    writeToTextAreaCommentary(
        "Routine of Distance Between Points (Radial Distance)" 
                + newLine);
    writeToTextAreaCommentary("Reumann Witkam (Sleeve)" + newLine);
    writeToTextAreaCommentary("Lang " + newLine);
    writeToTextAreaCommentary("Douglas Peucker " + newLine);
    writeToTextAreaCommentary("Visvalingam Whyatt " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("LINE METRICS " + newLine);
    writeToTextAreaCommentary("--------------------- " + newLine);
    writeToTextAreaCommentary(
        "Ratio of Angular Change between original " + newLine); 
    writeToTextAreaCommentary("and simplified lines " + newLine);
    writeToTextAreaCommentary("Percentage Decrease in Points " + newLine);
    writeToTextAreaCommentary(
        "Percentage Decrease in Line Length " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("PERFORMANCE MEASURES " + newLine);
    writeToTextAreaCommentary("---------------------------------------- "
            + newLine);
    writeToTextAreaCommentary("Vector Displacement Error (Standardized) " 
        + newLine);
    writeToTextAreaCommentary("Maximum Distortion Line Distance " + newLine);
    writeToTextAreaCommentary("Sum of Distortion Line Distances " + newLine);
    writeToTextAreaCommentary("Area Displacement Error " + newLine);
    writeToTextAreaCommentary("Uniform Distance Distortion " + newLine);
    writeToTextAreaCommentary(newLine);   
    writeToTextAreaCommentary(newLine); 
    writeToTextAreaCommentary(newLine); 
    writeToTextAreaCommentary("POINT SIMPLIFICATION ALGORITHM TYPES" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Independent point routines " + newLine); 
    writeToTextAreaCommentary("-----------------------" +
            "--------------" + newLine);
    writeToTextAreaCommentary("Example: nth point " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Independent point routines are the simplest of " +
    "the point reducing algorithms available. They are not deemed as suitable " +
    "for line simplification of lines where high accuracy is required " +
    "such as in large scale mapping. "); 
    writeToTextAreaCommentary("They are far from being computationally " +
            "efficient. " + newLine);
    writeToTextAreaCommentary("These routines do not consider the mathematical " 
          +  " relationship between neighbouring points and have been used mainly "
          +  "in applications where a rapid reduction in the number of " 
          +  "points is required. " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Localized processing routines " + newLine);
    writeToTextAreaCommentary("-----------------------------" + 
            "-------------" + newLine);
    writeToTextAreaCommentary("Examples: Routine of Radial Distance, " +
            " Routine of Perpendicular Distance " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Localized processing routines use the relationship " 
       + " of 2-3 neighbouring original line points to see if a point should be " 
       + " rejected or kept."  + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Relationships between points can include distance " 
       + "between points and angular change to name two." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Points that are inside the specified tolerance are " 
       + "removed from the line and those that are outside are not included in the "  
       + "simplified version of the line. " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Extended local processing routines (without " +
            "constraints) " + newLine);
    writeToTextAreaCommentary("---------------------------------"
            + "-----------------------" +
            "---------------------" + newLine);
    writeToTextAreaCommentary("Example: Reumann Witkam " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("This type of routine creates a range of " +
        "neighbouring points to search using geometric calculations and they "
        + " evaluate sections of the line. " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Extended local processing routines (with " +
            "constraints) " + newLine);  
    writeToTextAreaCommentary("------------------------------------------" +
            "-------------------------------" +
            newLine);
    writeToTextAreaCommentary("Example: Lang " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("These routines in contrast to the previous " +
       "category  divide the original line into search areas and search sections "
       + "of the line by considering points that are beyond the immediate "
       + "neighbouring points. " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("They use criteria found in the local processing " +
       "routines without constraints, and add additional constraints to create " +
       "a search area. " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("The search criteria is constrained by a distance " +
    "tolerance,angle or the number of points to restrict the search. " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Global Routines " + newLine);
    writeToTextAreaCommentary("-----------------------" + newLine);
    writeToTextAreaCommentary("Examples: Douglas Peucker, Visvalingam Whyatt " 
        + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Global routines process the whole line entirely " +
       "rather than a part of the line  sequentially,  from the start of the " +
       "line to the end of the line like in the previous categories." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("**********************************************" +
          "*************" + newLine);
    writeToTextAreaCommentary("COMPARING ALGORITHMS USING COMPARATIVE METRICS "
            + "AND MEASURES COLLECTED FROM THE TOOL" + newLine);
    writeToTextAreaCommentary("**********************************************" +
          "*************" + newLine);
    writeToTextAreaCommentary("**** Comparing One OR More Algorithms For Simplifying "
            + " One Line ***** " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("A good way of seeing the strengths and weaknesses "
           + " of algorithm(s) is to graph the metrics as a line graph. " + 
            " All provided " + 
        "allow comparison of algorithms (Based on McMaster 1986 " + 
        "measures - see for working knowledge)" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("References:" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("McMaster, R.B., (1986). A statistical analysis of " 
            + " mathematical measures for linear simplification. The American " +
            " Cartographer, 13(2), pp.103-116." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("McMaster, R.B., (1987). Automated line " +
            "generalization." + 
            "Cartographica: The International Journal for Geographic " +  
            "Information and Geovisualization, 24(2), pp.74-111. " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("STEPS" + newLine);
    writeToTextAreaCommentary("-----------" + newLine);
    writeToTextAreaCommentary("1. Create a table matrix in a spreadsheet with " +
           "X axis containing Percentage of coordinates removed " +
            "(suggested interval is 0,10,20,30,40,50,60,70,80,90,100)" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("The Y axis contains each of the algorithms " + 
            newLine);
    writeToTextAreaCommentary("2.For each algorithm collect one of the desired " +
        " metrics below and note the tolerances used to obtain each of the " +
        "metric value for each interval of percentage of coordinates " +
        "removed. " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("LINE METRIC & DISPLACEMENT MEASURES" + newLine);
    writeToTextAreaCommentary("------------------------------------" +
            "----------------------------" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("A. By Vector Displacement (Measure of Positional "
            + " Error) - " + newLine); 
    writeToTextAreaCommentary("Use one of the following: " + newLine);
    writeToTextAreaCommentary("(a) standardized vector displacement measure, " +
            newLine);
    writeToTextAreaCommentary("(b) maximum distortion " + newLine);  
    writeToTextAreaCommentary("(c) mean distortion " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("B. By Area Displacement (Measure of Positional "
        + "Error) " + newLine);
    writeToTextAreaCommentary("Use one of the following: " + newLine); 
    writeToTextAreaCommentary("(a) sum polygon areas (area displacement) " + 
            newLine);
    writeToTextAreaCommentary("(b) Uniform distance distortion) " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("C. By Ratio Of Angularity (Measure of Line " +
            "Complexity) " + newLine);
    writeToTextAreaCommentary("Use ratio angular change " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("D. By Line Length Percentage Decrease (Measure " +
        "Of Line Complexity) " + 
        "Use percentage decrease in line length (found at the end " + 
        "of simplification process in commentary window)" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("3. Graph the table using the x column of the table "
        + "for the x axis and  y column for the y axis." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);

    writeToTextAreaCommentary("**** Comparing An Algorithm For Simpliying 1 or " +
        "Multiple Lines *****" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Suggested way (Based on techniques used by "
            + "Shariari 2002) " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Reference: " + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Shahriari, N, Tao V. (2002). Minimizing Positional "
        + "Errors in Line Simplification Using Adaptive Tolerance Values." + 
        " In: D.E. Richardson et al. Advances in Spatial Data Handling." +
        " Berlin: Springer. p153-p166." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("STEPS" + newLine);
    writeToTextAreaCommentary("---------" + newLine);
    writeToTextAreaCommentary("1. Select an algorithm " + newLine);  
    writeToTextAreaCommentary("2. Collect metrics for one of A, B,C,D,E above "
            + newLine);
    writeToTextAreaCommentary("X axis contains tolerance values used " + newLine); 
    writeToTextAreaCommentary("Y axis is the metrics collected at that tolerance "
            + "for the algorithm. " + newLine);
    writeToTextAreaCommentary("3. Collect metrics for a predefined range of " +
        "tolerance values for the x-axis. " + newLine);
    writeToTextAreaCommentary("4. Repeat the above steps above to graph the " +
            " other metrics A, B, C, D or E." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("USE 1 - CARTOGRAPHIC PURPOSE - ASSESS " +
            "CARTOGRAPHIC QUALITY" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Points that define the character of the original " +
        "line are deemed essential and need to be selected to be retained in " +
        "the simplified line when removing excess points." + newLine);
    writeToTextAreaCommentary("These points are known as Characteristic Points " +
        "or Critical Points. In cartography characteristic points represent the "
        + "character of a linear feature, they can also be used to represent "
        + "logical points that form a country boundary or road network. " + 
        "Characteristic points are found at angular changes in the line," +
        "but can be poorly perceived." + newLine); 
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("McMaster's (1986) statistical measures presented in " +
        "this learning tool have been proposed  to aid their perception after "
        + "line simplification. They allow the positional accuracy to be determined"
        + "(via Vector and Area Displacement) or line complexity to be assessed "
        + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Line complexity can be assesed using point " +
            "density, sinousity, and line length. Curvilinearity is also used " 
          + "but has not been implemented in this release and is planned for a "
          + " future release " + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("LINE COMPLEXITY MEASURES" + newLine);
    writeToTextAreaCommentary("Percentage decrease in no of points (Point density)," +       
        "Ratio change in angularity (Sinuosity), " + 
        "Percentage change in line length (Line length)" + newLine);
    writeToTextAreaCommentary("Line simplification algorithms used in cartography "
      +  "are assessed on their ability to select characteristic points from the " 
      +  " original line." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("USE 2 - MODEL GENERALIZATION");
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary ("Model generalization is not concerned with the " +
        "assessment of cartographic quality which is subjective in nature but " +
        "is concerned with non-cartographic generalization. It may be " + 
        "carried out to permanently reduce data volume in a database " + 
        "or to merge databases of different resolutions." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("As part of this line simplification may introduce " +
       " positional error in the database causing length and area measures to be " +
       "inaccurate. Little work has been done in this area with a " +
       "handful of studies attempting to measure positional accuracy " +
        "in model generalization." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Bandwidth tolerances for line simplification " +
            "algorithms are hard to formulate to get a desired level of " +
            "distortion. Tolerances introduce different levels of distortion " +
            "and arriving at the required level of acceptable, maximum distortion" +
            "is through trial and error." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Objective (quantitative) measures have been " +
            "formulated to measure distortion in model generalization. These are " +
            newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("Area Displacement measures" + newLine);
    writeToTextAreaCommentary("Vector Displacement measures" + newLine); 
    writeToTextAreaCommentary("Percentage change in the no of points" + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("The deviation of the simplified line from the " +
        "original line is called model error. This deviation can be measured " +
        "after a line simplification algorithm has been applied. Simplification " +
        "algorithms vary by giving small or large model error." + newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary(newLine);
    writeToTextAreaCommentary("The learning tool can be be used to assess "
            + "Cartographic Quality or Model Generalization where" + newLine);
    }
    
   
    /**
    * Routine of Radial Distance Using Counter
    * 
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    */
    public void routineOfRadialDistanceUsingCounter(LineSimplification ls, 
            int count){
        String newLine = "\n";
        int counter = count; 
                
        int n = Integer.parseInt(txtRadialDistance.getText());
        setRadialDistance(n);
        ls.routineOfDistanceBetweenPoints(getPoints(),n);
            
          
            try{
                if(validateRadialDistanceInput() == false){
            
                }
                else{
                    if (getCircles() == null){
                        setPoints2(new ArrayList<>(getPoints()));
                        setCircles(new ArrayList<>());
                        setAreaCircles(new ArrayList<>());
                        setCount(0);
                        repaint();
                        setI(0);
                    }
                    
                    //setCount(getCount()+1);
                    setCount(counter + 1);
                
                    System.out.println("The count is:" + getCount());
                    
                    //Processing completed
                    if (getCount()-1 == getPoints2().size()-1){
                        setAreaCircles(new ArrayList<>());
                        repaint();
                        jTextAreaCommentary.setText("");
                        writeToTextAreaCommentary("Processing complete - "
                                + "simplified line (blue)" + newLine);
                        writeToTextAreaCommentary("Original Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.sumLineSegmentLengths(getPoints()))) + 
                                newLine);
                        writeToTextAreaCommentary("Simplified Line Length: " + 
                        String.valueOf(String.format( "%.2f",
                                lp.sumLineSegmentLengths(getPoints2()))) + 
                                newLine);
                        lp.percentageChangeInLineLengths(getPoints(), 
                                getPoints2());
                        writeToTextAreaCommentary("Percentage decrease " + 
                                "Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
                    }
                
                    //1.Draw circle at each keyPoint point
                    if (getCount()-1 < getPoints2().size()){
                        int j = getCount()-1;
                        int k = getCount(); //next point index
                        Point keyPoint = getPoints2().get(j);
                        Point nextPoint = getPoints2().get(k);
                     
                        //2.Draw Area Circle
                        setAreaCircles(new ArrayList<>());
                        getAreaCircles().add(keyPoint);
                        setAreaCircles(new ArrayList<>(getAreaCircles()));
                        repaint();
                  
                        ArrayList<Point> pointsInCircle = 
                                ls.getPointsInCircle(getPoints(), n, keyPoint);
                    
                        //FOR DEBUG: Print points in circle
                        for(int w = 0; w < pointsInCircle.size(); w++){
                            Point p = pointsInCircle.get(w);
                            System.out.println("Point in circle: " + p.getID());
                        }

                        //determine and store consecutive points
                        //get rid of any points which are not consecutive
                        //Store only consecutive points that fall in a circle 
                        //starting with the circles key point. Any points before
                        //the circles key point are removed from the pointsInCircle 
                        //arraylist
                        int startPos = pointsInCircle.indexOf(keyPoint);
                        for (int l = 0; l < pointsInCircle.size(); l++){
                            int pointPos = 
                                  pointsInCircle.indexOf(pointsInCircle.get(l));  
                            if (pointPos < startPos){
                                pointsInCircle.remove(pointPos);
                            }
                        }
                    
                        //Determine ONLY consecutive points after sleeve start 
                        //point and only store those in the subpartList           
                
                        ArrayList<Point> pointsInCircle2 = new ArrayList<>();
                        pointsInCircle2.add(keyPoint);
                        for(int d = 0; d < pointsInCircle.size()-1; d++){
                            Point point1 = pointsInCircle.get(d);
                            Point point2 = pointsInCircle.get(d+1);
                            String strPoint1 = point1.getID();
                            String strPoint2 = point2.getID();
                            System.out.println("strPoint1 " + strPoint1);
                            System.out.println("strPoint2 " + strPoint2);
                            strPoint1 = strPoint1.substring(1);
                            strPoint2 = strPoint2.substring(1);
                            int pt1 = Integer.parseInt(strPoint1);
                            int pt2 = Integer.parseInt(strPoint2);
                            System.out.println(""+ pt1);
                            System.out.println(""+ pt2);
                    
                            //Only keeping consecutive points i.e 
                            //determined using difference in point ID = 1
                            if (pt2 - pt1 == 1){
                                pointsInCircle2.add(point1);
                                pointsInCircle2.add(point2);                            
                            }
                            else{
                                break;
                            }
                        }
                            
                    //Getting rid of any duplicate elements (duplicate points from
                    //subpartList2)
                    List<Point> pointsInCircle2WithoutDuplicates = new ArrayList<>();
                    for(int r = 0; r < pointsInCircle2.size(); r++){
                        Point pp = pointsInCircle2.get(r);
                        pointsInCircle2WithoutDuplicates.add(pp);    
                    }
                
                    //Sorting the elements (points)
                    LinkedHashSet<Point> linkedhashset = new LinkedHashSet<>();
                    linkedhashset.addAll(pointsInCircle2WithoutDuplicates);
                    pointsInCircle2WithoutDuplicates.clear();
                    pointsInCircle2WithoutDuplicates.addAll(linkedhashset);
                
                    //Saving elements (points) to arraylist
                    pointsInCircle2 = 
                            new ArrayList<>(pointsInCircle2WithoutDuplicates);
  
                    //For DEBUG: Print sublist
                    for(int y = 0; y < pointsInCircle2.size(); y++){
                        System.out.println("pointsInCircle2 :" + 
                                pointsInCircle2.get(y).getID());
                    }
                    
                    String str = "";
                    String str2 = "";
                    for (int l = 0; l < pointsInCircle2.size(); l++){    
                        //Store first and last points only from sublist to 
                        //simplified line 
                        if(l == 0){//| l == pointsInCircle2.size()-1){
                            
                        }
                        else{
                            //Remove all intermediate points that are not first 
                            //or last point in the pointsInCircle2 sublist
                            System.out.println("Removing " + 
                                    pointsInCircle2.get(l).getID());
                            str = str +  pointsInCircle2.get(l).getID();
                            jTextAreaCommentary.setText("Removed point(s) " + str);
                            Point lastPointInGetPoints2 = 
                                    getPoints2().get(getPoints2().size()-1); 
                        
                            if(pointsInCircle2.get(l).getID().equals(
                                    lastPointInGetPoints2.getID())){
                        
                            }
                            else
                                getPoints2().remove(pointsInCircle2.get(l));
                                lp = new LinePerformance();
                                lblNoOfSimplifiedLinePoints.setText("" + 
                                        getPoints2().size());
                                lblPercentageDecreaseValue.setText("" +
            lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                                lblRatioAngularityChangeValue.setText("" + 
                       lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));  
                                repaint();
                            }
                    }              
                    jTextAreaCommentary.setText("Removed point(s) " + str);
                }
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }                
    }
    
   /**
    * Validate Nth Point Input
    * @return boolean
    */
    public boolean validateNthPointInput(){
        boolean passed = false;
        String nthPoint = txtNthPoint.getText();
        try{
            float floatValue = Float.parseFloat(nthPoint);
            if(Integer.parseInt(nthPoint) > 0 & Integer.parseInt(nthPoint)
                    <= getPoints().size()){               
                passed = true;
                return passed;
            }
            else if(floatValue > 0 & floatValue <= getPoints().size()){
                JOptionPane.showMessageDialog(null, "Please enter a valid "
                        + "integer number between 1 and " + getPoints().size(), 
                        "nth Point", JOptionPane.ERROR_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null, 
                        "Please enter a valid integer number between 1 and " + 
                        getPoints().size(), "nth Point",
                        JOptionPane.ERROR_MESSAGE);
            }
            return passed;
        }
        catch(NumberFormatException e){
           JOptionPane.showMessageDialog(null, 
           "Please enter a valid integer number between 1 and " + getPoints().size(),
           "nth Point", JOptionPane.ERROR_MESSAGE);
        }
        return passed;
    }    
     
    
    /**
    * Validate No of Points Input
    * @return boolean
    */
    public boolean validateNoOfPointsInput(){
        boolean passed = false;
        String noOfPoints = txtNoOfPoints.getText();
        try{
            float floatValue = Float.parseFloat(noOfPoints);
            if(Integer.parseInt(noOfPoints) > 0 & Integer.parseInt(noOfPoints) 
                    <= getPoints().size()){
                passed = true;
            }
            else if(floatValue > 0 & floatValue <= getPoints().size()){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + getPoints().size(), 
                        "Visvalingam Whyatt", JOptionPane.ERROR_MESSAGE );
            } 
            else{
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                         + " number between 1 and " + getPoints().size(), 
                        "Visvalingam Whyatt", JOptionPane.ERROR_MESSAGE );
            }
            return passed;
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                    + " number between 1 and " + getPoints().size(),
                    "Visvalingam Whyatt", JOptionPane.ERROR_MESSAGE);
        }
        return passed;
    }
    
    
    /**
    * Validate Perpendicular Distance Input
     *@param dialogTitle
    * @return boolean
    */
    public boolean validatePerpendicularDistanceInput(String dialogTitle){
        boolean passed = false;
        String perpendicularDistance = txtPerpendicularDistance.getText();
        float floatValue = 0;
        try{
            floatValue = Float.parseFloat(perpendicularDistance);
            if(Integer.parseInt(perpendicularDistance) > 0 & 
                    Integer.parseInt(perpendicularDistance) <= 800){
                passed = true;
            }
            else if(floatValue > 0 & floatValue <= 800){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer "
                + "number between 1 and " + 800, dialogTitle, 
                JOptionPane.ERROR_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                + " number between 1 and " + 800, dialogTitle, 
                JOptionPane.ERROR_MESSAGE);
            }
            return passed;
        }
        catch(NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Please enter a valid integer number "
            + "between 1 and " + 800, dialogTitle, JOptionPane.ERROR_MESSAGE);
        }
        return passed;
}

    
    /**
    * Validate Radial Distance Input
    * @return boolean
    */
    public boolean validateRadialDistanceInput(){
        boolean passed = false;
        String radialDistance = txtRadialDistance.getText();
        float floatValue = 0;
        try{
            if(Integer.parseInt(radialDistance) > 0 & 
                    Integer.parseInt(radialDistance) <= 300){
                passed = true;
            }
            else if(floatValue > 0 & floatValue <= 300){
                 JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                         + " number between 1 and " + 300, "Routine of Radial "
                                 + "Distance", JOptionPane.ERROR_MESSAGE);
            }
            else{
                 JOptionPane.showMessageDialog(null, "Please enter a valid integer "
                         + "number between 1 and " + 300, "Routine of Radial"
                                 + " Distance", JOptionPane.ERROR_MESSAGE);
            }
            return passed;
        }
        catch(NumberFormatException e){
             JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                     + " number between 1 and " + 300, "Routine of Radial Distance", 
                     JOptionPane.ERROR_MESSAGE);
        }
        return passed;
    }    
    
   /**
    * Validate Height Input
    * @return boolean
    */
    public boolean validateHeightInput(){
        boolean passed = false;
        String height = txtHeight.getText();
        float floatValue = 0; 
        try{
            if(Integer.parseInt(height) > 0 & Integer.parseInt(height) <= 600){
                passed = true;
            }
            else if(floatValue > 0 & floatValue <= 600){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + 600, "Reumann Witkam",
                        JOptionPane.ERROR_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + 600, "Reumann Witkam",
                        JOptionPane.ERROR_MESSAGE);
            }
            return passed;
            }
            catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer "
                        + "number between 1 and " + 600, "Reumann Witkam", 
                        JOptionPane.ERROR_MESSAGE);
            }
        return passed;
   }

   /**
    * Validate Width Input
    * @return boolean
    */
    public boolean validateWidthInput(){
        boolean passed = false;
        String width = txtWidth.getText();
        float floatValue = 0;
        try{
            if(Integer.parseInt(width) > 0 & Integer.parseInt(width) <= 800){
                passed = true;
            }   
            else if(floatValue > 0 & floatValue <= 800){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + 800, "Reumann Witkam", 
                        JOptionPane.ERROR_MESSAGE);
            }
            else{
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + 800, "Reumann Witkam", 
                        JOptionPane.ERROR_MESSAGE);
            }
            return passed;
        }
        catch(NumberFormatException e){
                JOptionPane.showMessageDialog(null, "Please enter a valid integer"
                        + " number between 1 and " + 800, "Reumann Witkam",
                        JOptionPane.ERROR_MESSAGE);
        }
        return passed;
    }

    
   /**
    * nthPoint Using Counter
    * 
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    */
   
    public void nthPointUsingCounter(LineSimplification ls, int count){
        try{
            String newLine = "\n";
            int counter = count;
            int n = Integer.parseInt(txtNthPoint.getText());
        
            if(validateNthPointInput() == false){
            
            }
            else{
                ls.nthPoint(getPoints(),n);
        
                if (getPoints2() == null){
                    setPoints2(new ArrayList<>(ls.getOriginalLinePts()));
                    setCircles(new ArrayList<>());
                    setCount(0);
                    repaint();
                    setI(0);
                }
          
                setCount(counter + 1);
                System.out.println("The count is:" + getCount());
                    
                ArrayList<Point> copy = new ArrayList<>();
                           
                for (int h = getCount()-1; getCount() 
                        < ls.getOriginalLinePts().size(); h++){            
                        
                    //1. Show nthpoints using circles (excluding line start and end points)
                    if(getCount()-1 == 0){
                        jTextAreaCommentary.setText("Keep nth points (highlighted "
                                + "by purple circles)");
                        for(int b = 1; b < ls.getSimplifiedLinePts().size()-1; b++){
                            Point p = ls.getSimplifiedLinePts().get(b);
                            copy.add(p);
                        }
                        setCircles(new ArrayList<>(copy));
                        repaint();
                                
                    }
                
                    repaint();
                    //2. Remove OriginalPoints that should not be in the simplified line
                    Point p5 = ls.getOriginalLinePts().get(h);
                    if(ls.isPointInLine(p5, ls.getSimplifiedLinePts())){
                        jTextAreaCommentary.setText("Retained " + p5.getID() + 
                                " which is IN the simplified line");
                    }
                    else{
                        jTextAreaCommentary.setText("Removed " + p5.getID() + 
                                " which is NOT IN the simplified line");
                    
                        if(getCount()> 0){
                            getPoints2().remove(p5);
                        }
                        lp = new LinePerformance();
                        lblNoOfSimplifiedLinePoints.setText("" + 
                                getPoints2().size());
                        lblPercentageDecreaseValue.setText("" + 
                        lp.percentageChangeInNumberOfCoordinates(getPoints(),
                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                        lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));  
                    }
                    break;
                }
            }
            
            if (getCount() == (getPoints().size()-2) + 1) {//12){
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary("Processing complete - simplified line "
                        + "(blue)" + newLine);
                writeToTextAreaCommentary("Original Line Length: " 
                        + String.valueOf(String.format( "%.2f", 
                                lp.sumLineSegmentLengths(getPoints()))) +
                        newLine);
                writeToTextAreaCommentary("Simplified Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.sumLineSegmentLengths(getPoints2()))) + 
                        newLine);
                lp.percentageChangeInLineLengths(getPoints(), getPoints2());
                writeToTextAreaCommentary("Percentage decrease Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
                setCircles(null);
                repaint();
            }
              
        }
        catch (Exception e){
                System.out.println("File not found"); 
        
        }
    }
        
    
    
    /**
    * Routine of Perpendicular Distance Using Counter
    * 
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    * 
    */
    
    public void routineOfPerpendicularDistanceUsingCounter(LineSimplification ls,
            int count){
    String newLine = "\n";
    int counter = count;
    String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
    ArrayList<Liner> perpendicularLines = null;
    ArrayList<Liner> simplifiedLines = null;
    ArrayList<Point> simplifiedLinePts = null;
    ArrayList<Liner> perpendicularLinesLargerThanThreshold = null;
    Polygon effectiveAreaTriangle = null;
    ArrayList<Polygon> effectiveAreaTriangles = null;
    double effectiveArea = 0;
    double minEffectiveArea = 20000000.0;
    int minAreaIndex = 0;
    Point pointToRemove = null;
        
    Liner perpendicularline = null;
    Liner simplifiedLine = null;
                
    Point p1 = null;
    Point p2 = null;
    boolean booleanContinue = false; 
    int i = 0;
    int j = 0;
    int k = 0;
    int n = 0;
    Point keyPoint = null;
    Point prevPoint = null;
    Point nextPoint = null;     
        
        try{
            int t = Integer.parseInt(txtPerpendicularDistance.getText());
            ls.perpendicularDistanceRoutine(getPoints(),t);
            //Set perpendicular lines and simplified lines 
            
            if(validatePerpendicularDistanceInput("Routine of "
                    + "Perpendicular Distance") == false){
                
            }
            else{
            
                //collections to be empty
                if (getPerpendicularLines() == null){
                    perpendicularLinesLargerThanThreshold = new ArrayList<>();
                    setPerpendicularLinesLargerThanThreshold(
                            perpendicularLinesLargerThanThreshold);
                    perpendicularLines = new ArrayList<>();
                    setPerpendicularLines(perpendicularLines);
                    simplifiedLines = new ArrayList<>();
                    setSimplifiedLines(simplifiedLines);
                    simplifiedLinePts = new ArrayList<>(getPoints());
                    setI(0);
                }
                 
                setCount(counter + 1);
                System.out.println("The count is:" + getCount());
                    
                   
                //1. Show construct perpendicular lines and simplified lines 
                //being built up
                if (getCount()-1 < ls.getPerpendicularLines().size()){
                    perpendicularline = 
                            ls.getPerpendicularLines().get(getCount()-1);
                    System.out.println("line length " + 
                            perpendicularline.getLength());
                    getPerpendicularLines().add(perpendicularline);
                    setPerpendicularLines(getPerpendicularLines());
                    simplifiedLine = ls.getSimplifiedLines().get(getCount()-1);
                    getSimplifiedLines().add(simplifiedLine);
                    setSimplifiedLines(getSimplifiedLines());
                       
                    String strPerpendicularline = String.format("%.2f", 
                            perpendicularline.getLength());

                    if(perpendicularline.getLength() <= 
                            ls.getPerpendicularDistanceTolerance()){    
                        System.out.println("tolerance: " + 
                                ls.getPerpendicularDistanceTolerance());
                        jTextAreaCommentary.setText("" + 
                                perpendicularline.getLinerPoint1().getID() + 
                                " has perpendicular distance " + 
                                strPerpendicularline +  
                                " SMALLER than threshold tolerance " + 
                                ls.getPerpendicularDistanceTolerance() + ". "  
                                + perpendicularline.getLinerPoint1().getID() +
                                " to be removed");
                    }
                    
                    if(perpendicularline.getLength() > 
                            ls.getPerpendicularDistanceTolerance()){
                        System.out.println("The point:" + 
                                perpendicularline.getLinerPoint1().getID());
                        getPerpendicularLinesLargerThanThreshold().add(
                                perpendicularline);
                        jTextAreaCommentary.setText("" + 
                                perpendicularline.getLinerPoint1().getID() + 
                                " has perpendicular distance " +
                                strPerpendicularline +
                                " LARGER than threshold tolerance " +
                                ls.getPerpendicularDistanceTolerance() + ". " 
                                + perpendicularline.getLinerPoint1().getID() +
                                " to be retained");
                    }
                    repaint(); 
                }   
                
                ArrayList<Point> copy = new ArrayList<>();
                    
                //2. Show perpendicularlines larger than the tolerance (Green)
                if (getCount() == getPoints().size()-2)   { 
                    setPerpendicularLinesLargerThanThreshold(
                            getPerpendicularLinesLargerThanThreshold());
                    repaint();
                        
                    for(int b = 1; b < ls.getSimplifiedLinePts().size()-1; b++){
                        Point p = ls.getSimplifiedLinePts().get(b);
                        copy.add(p);
                    }
                    //Show circles for points to keep (mauve)
                    setCircles(copy);
                    repaint();
                }
                    
                if(getCount() > ((getPoints().size() - 2) + 
                        (getPoints().size() - 2))) { 
                    writeToTextAreaCommentary("Processing complete - "
                            + "simplified line (blue)" + newLine);
                    writeToTextAreaCommentary("Original Line Length: " +
                            String.valueOf(String.format( "%.2f", 
                                    lp.sumLineSegmentLengths(getPoints())))
                            + newLine);
                    writeToTextAreaCommentary("Simplified Line Length: " + 
                            String.valueOf(String.format( "%.2f", 
                                    lp.sumLineSegmentLengths(getPoints2())))
                            + newLine);
                    lp.percentageChangeInLineLengths(getPoints(), getPoints2());
                    writeToTextAreaCommentary("Percentage decrease Line Length: " 
                      +  String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
                    setCircles(null);
                    setPerpendicularLinesLargerThanThreshold(null);
                    setPerpendicularLines(null);
                    setSimplifiedLines(null);
                    repaint();
                }
                    
                    
                //3. Remove original points for perpendicular lines smaller than 
                //   perpendicular distance tolerance after all simplified and 
                //   perpendicular lines have been displayed
                //   Remove perpendicular lines smaller than tolerance
                //   Remove simplified line for the perpendicular line removed
                    
                if(getCount() > (getPoints().size() - 2)){ 
                    
                    lines = null;
                    perpendicularline = ls.getPerpendicularLines().get(getI());
                    simplifiedLine = ls.getSimplifiedLines().get(getI());
                    System.out.println("perpendicularline" + 
                            perpendicularline.getLength());
                    System.out.println("simplified line" + 
                            simplifiedLine.getLength());
                    setI(getI() + 1);
                    if (perpendicularline.getLength() <
                            ls.getPerpendicularDistanceTolerance())    
                        p1 = perpendicularline.getLinerPoint1();
                        getPoints2().remove(p1);
                        jTextAreaCommentary.setText("" + 
                                perpendicularline.getLinerPoint1().getID() +
                                " removed");                        
                        lp = new LinePerformance();
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" + 
                            lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                    getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(), 
                                        getPoints2()));  
                        repaint();                    
                    }
                    
                }
            }
        catch (Exception e){
            System.out.println("File not found"); 
        }
    }
    
   
    /**
    * Reumann Witkam Using Counter
    * 
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    * 
    */  
      
    public void reumannWitkamUsingCounter(LineSimplification ls, int count){         
        try{
            
            if(validateHeightInput() == false | validateWidthInput() == false){
            }
            else{
                String newLine = "\n";
                ArrayList<Point> simplifiedLinePts = null;
                ArrayList<Point> simplifiedPts = new ArrayList<>();
                simplifiedLinePts = ls.getSimplifiedLinePts();     
                ArrayList<Point> subpartList = new ArrayList<>();
                Point startPoint = null;
                           
                if(sleeve == null){                    
                    simplifiedPts = new ArrayList<>(); 
                }
                
                int counter = 0;
                int counters = count;
                int sleeveCounter = 0;
                java.util.List<Point> subList = null;
                    
                int h = Integer.parseInt(txtHeight.getText());
                int w = Integer.parseInt(txtWidth.getText());
                ls = new LineSimplification();
                //ls.reumannWitkam(getPoints2(),w,h);
                    
                setCount(counters + 1);
                System.out.println("The count is:" + getCount());
                            
                if(getCount() == getPoints2().size()){
                    setSleeve(null);
                    jTextAreaCommentary.setText("");
                    writeToTextAreaCommentary("Processing complete -"
                            + " simplified line (blue)" + newLine);
                    writeToTextAreaCommentary("Original Line Length: " + 
                            String.valueOf(String.format( "%.2f", 
                                    lp.sumLineSegmentLengths(getPoints()))) 
                            + newLine);
                    writeToTextAreaCommentary("Simplified Line Length: " + 
                            String.valueOf(String.format( "%.2f",
                                    lp.sumLineSegmentLengths(getPoints2()))) 
                            + newLine);
                    lp.percentageChangeInLineLengths(getPoints(), getPoints2());
                    writeToTextAreaCommentary("Percentage decrease Line Length: "
                    + String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
                    repaint();
                }
                    
                for (int f = getCount()-1; f < getPoints2().size(); f++){
                    startPoint = getPoints2().get(getCount() - 1);
                    Point endPoint = getPoints2().get(getCount());
                        
                    //Reset point sublist
                    subpartList = new ArrayList<>();                                
                    //Get bearing in radians for tangent line
                    lp = new LinePerformance();
                    Liner liner2 = new Liner(startPoint, endPoint);
                    double bearingOfTangent = liner2.calculateBearingofLine(startPoint,
                            endPoint);
                    double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);

                    //Adjust tangent length to be same length (width) as user input
                    //length (width) by creating new endPoint for line 
                    long newEndPointX = Math.round(startPoint.getX()+ 
                            (w * Math.sin(bearingOfTangentInRadians)));
                    long newEndPointY = Math.round(startPoint.getY()+
                            (w * Math.cos(bearingOfTangentInRadians)));
                    endPoint = new Point("p" + i + "," + newEndPointX + "," + 
                            newEndPointY);

                    //Create and store rectangle strip (sleeve) in SLEEVELINES 
                    //aligned to intitial line tangent so they can be drawn 
                    Sleeve sleeve = new Sleeve(h, w);
                    ArrayList<Liner> sleeveLines =
                       new ArrayList<>(sleeve.createSleeve(startPoint, endPoint,
                               bearingOfTangent));
                    setSleeve(sleeveLines);
                    sleeveCounter++;
                    repaint();
                                
                    //Initially determine and store the points inside sleeve 
                    //(sleeveLines) into subpartList
                    for (int y = 0; y < getPoints2().size(); y++){  
                        if (ls.isPointInConvexPolygon(getPoints2().get(y), 
                                sleeveLines)){
                            System.out.println("Point " + (y+1) + " is inside "
                                    + "sleeve:"
                                    + sleeveCounter);
                            subpartList.add(getPoints2().get(y));
                        }
                    else{
                        System.out.println("Point " + (y+1) + " is NOT inside "
                                + "sleeve:"
                                + sleeveCounter);
                        }
                    }        
                }                    
                        
                //Store only consecutive points that fall in a sleeve starting
                //with the sleeves start point. 
                //1. Any points before the sleeve's start point are removed
                //from the subpartList
                int startPos = subpartList.indexOf(startPoint);
                System.out.println("StartPosition:" + startPos);
                System.out.println("Start Point ID:" + startPoint.getID());
                
                for (int l = 0; l < startPos; l++){
                int pointPos = subpartList.indexOf(subpartList.get(l));  
                    if (pointPos < startPos + 1){
                        subpartList.remove(pointPos);
                    }
                }
               
                //Determine ONLY consecutive points after sleeve start point
                //and only store those in the subpartList           
                ArrayList<Point> subpartList2 = new ArrayList<>();
                for(int d = 0; d < subpartList.size()-1; d++){
                    Point point1 = subpartList.get(d);
                    Point point2 = subpartList.get(d+1);            
                    String strPoint1 = point1.getID();
                    String strPoint2 = point2.getID();
                    System.out.println("strPoint1 " + strPoint1);
                    System.out.println("strPoint2 " + strPoint2);
                    strPoint1 = strPoint1.substring(1);
                    strPoint2 = strPoint2.substring(1);
                    int pt1 = Integer.parseInt(strPoint1);
                    int pt2 = Integer.parseInt(strPoint2);
                    System.out.println(""+ pt1);
                    System.out.println(""+ pt2);
                    
                    //Only keeping consecutive points i.e 
                    //determined using difference in point ID = 1
                    if (pt1 + 1 == pt2){
                        subpartList2.add(point1);
                        subpartList2.add(point2);
                    }
                    else{
                        break;
                    }
                }
    
                
                //Getting rid of any duplicate elements (duplicate points from 
                //subpartList2)
                List<Point> subpartList2WithoutDuplicates = new ArrayList<>();
                for(int r = 0; r < subpartList2.size(); r++){
                    Point pp = subpartList2.get(r);
                    subpartList2WithoutDuplicates.add(pp);    
                }
                
                //Sorting the elements (points)
                LinkedHashSet<Point> linkedhashset = new LinkedHashSet<>();
                linkedhashset.addAll(subpartList2WithoutDuplicates);
                subpartList2WithoutDuplicates.clear();
                subpartList2WithoutDuplicates.addAll(linkedhashset);
                
                //Saving elements (points) to arraylist
                subpartList2 = new ArrayList<>(subpartList2WithoutDuplicates);
  
                //For DEBUG: Print sublist
                for(int y = 0; y < subpartList2.size(); y++){
                    System.out.println("subpartList2 :" 
                            + subpartList2.get(y).getID());
                }
                
                
                String str = "";
                for (int l = 0; l < subpartList2.size(); l++){    
                    //Store first and last points only from sublist to 
                    //simplified line 
                    if(l == 0 || l == subpartList2.size()-1){
                       
                    }
                    else{
                        //Remove all intermediate points that are not first or
                        //last point in the sublist
                        System.out.println("Removing " + subpartList2.get(l).getID());
                        str = str +  subpartList2.get(l).getID();
                        getPoints2().remove(subpartList2.get(l));
                        lp = new LinePerformance();
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" + 
                            lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                    getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(),
                                        getPoints2()));  
                        repaint();
                        }
                    }              
                    jTextAreaCommentary.setText("Removed point(s) " + str);
                }
            } 
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }
    
    
    /**
    * Lang Using Counter
    * 
    * Definition of how Lang works was required as journal articles did not
    * go into required depth. Implementation is based on tolerances
    * perpendicular distance AND the LookAhead value used to define the
    * extent of a moving search area during line simplification until the entire
    * line has been simplified.
    * 
    * REF:http://psimpl.sourceforge.net/lang.html
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    * @return simplifiedLinePts - Points representing the simplified line points
    * 
    */
   public ArrayList<Point> langUsingCounter(LineSimplification ls, int count){
            String newLine = "\n";
            Point pointToDelete = null;
            double maximumPerpendicularDistance = 0;
            int counter = count;
            int tolerance = Integer.parseInt(txtPerpendicularDistance.getText());    
            int lookAhead = Integer.parseInt(txtNoOfPoints.getText());
            Liner simplifiedLine = null;
            Point intermediatePoint = null;
            Point prevPoint = null;
            Point nextPoint = null;    
            boolean isFinish = false;
            
            ArrayList<Point> simplifiedLinePts = new ArrayList<>(getPoints());
            ArrayList<Liner> simplifiedLines = new ArrayList<>();
            ArrayList<Liner> toleranceLines = new ArrayList<>();
            ArrayList<Point> searchRegion = new ArrayList<>();
            ArrayList<Liner> perpendicularLines = new ArrayList<>();
            repaint();   
            
            int endPoint = 0;
            setCount(getCount() + 1);
            System.out.println("The count is:" + getCount());
                            
        if (getCount()-1 < 200){
            
            if(getCount()-1 == 0){
                int keyPoint = 0;   
                setKeyPoint(0);
                setEndPoint(lookAhead); //Defines search region
            }
                 
            //Sub partition simplifiedlinepts using heyPoint and EndPoint
            if (getKeyPoint() < getEndPoint()){
                searchRegion = new ArrayList<>();
                for (int j = getKeyPoint(); j < getEndPoint(); j++){
                    Point p = getPoints().get(j);
                    searchRegion.add(p);
                }
                setSearchRegion(new ArrayList<>(searchRegion)); 
                
                //Draw Simplified Line
                simplifiedLine = new Liner(searchRegion.get(0),
                        searchRegion.get(searchRegion.size()-1));        
                simplifiedLines = new ArrayList<>();
                simplifiedLines.add(simplifiedLine);
                setSimplifiedLines(simplifiedLines);
                perpendicularLines = new ArrayList<>();
                repaint();
               
                setMaximumPerpendicularDistance(0);
                
                boolean isRightOfLine = false;
                boolean isLeftOfLine = false;
                //Draw Perpendicular Line
                for(int m = getKeyPoint()+1; m < getEndPoint(); m++){
                    intermediatePoint = getPoints().get(m);
                    prevPoint = simplifiedLine.getLinerPoint1();
                    nextPoint = simplifiedLine.getLinerPoint2();       
                    
                    double perpendicularDistance = 
                            ls.distanceOfPointPerpendicularToLine(
                                    getPoints().get(m),
                                    simplifiedLine);
                    
                 
                    String coord = "";
                    try{
                        coord = "p" + m + "," + lp.createPerpendicularPoint(intermediatePoint,prevPoint,nextPoint);  
                    }
                    catch(Exception e){
                        return simplifiedLinePts;
                    }
                    
                    System.out.println("Intermediate point" +
                            intermediatePoint.getID()); //FOR DEBUG
                    System.out.println("prevPoint" + prevPoint.getID()); //FOR DEBUG
                    System.out.println("nextPoint" + nextPoint.getID()); //FOR DEBUG
                    
                    Point p2 = new Point(coord);
                    System.out.println("PerpendicularDistance: " + 
                            perpendicularDistance);
                    Liner perpendicularLine = new Liner(intermediatePoint,p2);    
                   
                    perpendicularLines.add(perpendicularLine);
                    setPerpendicularLines(perpendicularLines);
                    repaint();
                    if (perpendicularDistance > maximumPerpendicularDistance){
                        maximumPerpendicularDistance = perpendicularDistance;
                        setMaximumPerpendicularDistance(maximumPerpendicularDistance);
                    }
                    System.out.println("Maximum perpendicular Distance: " +
                            getMaximumPerpendicularDistance());
              
                    if(!(lp.isPointRightOfLine(intermediatePoint, simplifiedLine))){
                        isRightOfLine = true;
                    }
                    else{
                        isLeftOfLine = true;
                    }
                }  
                
                //Create and draw green tolerance line for search area
                Sleeve sleeve1 = new Sleeve(tolerance * 2, 
                        simplifiedLine.getLength());
                Liner liner = new Liner(prevPoint,nextPoint);
                double bearingOfTangent = liner.calculateBearingofLine(prevPoint, 
                        nextPoint);
                ArrayList<Liner> sleeveLines = 
                        new ArrayList<>(sleeve1.createSleeve(prevPoint, nextPoint,
                                bearingOfTangent));
                
                if(isRightOfLine == true & isLeftOfLine == true){
                    toleranceLines.add(sleeveLines.get(0));
                    toleranceLines.add(sleeveLines.get(2));
                }
                else if(isRightOfLine == true & isLeftOfLine == false){
                    toleranceLines.add(sleeveLines.get(0));
                }
                else if(isRightOfLine == false & isLeftOfLine == true){
                    toleranceLines.add(sleeveLines.get(2));   
                }
                setPerpendicularLinesLargerThanThreshold(
                        new ArrayList<>(toleranceLines));
                repaint();
                
                System.out.println("Maximum Perpendicular Distance Tolerance: " +
                        getMaximumPerpendicularDistance());
                System.out.println("tolerance: " + tolerance);

                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary("Initial Search area (Look Ahead) is " +
                        lookAhead + "" + newLine);
                writeToTextAreaCommentary("Current Search area " + getEndPoint() +
                        "" + newLine);
                writeToTextAreaCommentary("Maximum Distortion "
                        + "(Max Perpendicular Distance) is: " + 
                        getMaximumPerpendicularDistance() + newLine);
                writeToTextAreaCommentary("Maximum Distortion (" + 
                        getMaximumPerpendicularDistance() + 
                        ") is greater than the threshold perpendicular distance"
                        + " tolerance (" + tolerance + ")" + newLine);
                writeToTextAreaCommentary("Reducing search area size by 1 " + 
                        newLine);
                
                String str = "";
                //Delete all intermediate points if they below the search area
                //Where the maximum perpendicular distance is less than the
                //threshold tolerance distance
                if (getMaximumPerpendicularDistance() < tolerance){
                    jTextAreaCommentary.setText("");
                    writeToTextAreaCommentary("Initial Search area (Look Ahead) "
                            + "is " + lookAhead + "" + newLine);
                    writeToTextAreaCommentary("Current Search area " +
                            getEndPoint() + "" + newLine);
                    writeToTextAreaCommentary("Maximum Distortion (Max "
                            + "Perpendicular Distance) is: " 
                            + getMaximumPerpendicularDistance() + newLine);
                    writeToTextAreaCommentary("Maximum Distortion (" +
                            getMaximumPerpendicularDistance() + ") is less than the"
                            + " threshold perpendicular distance tolerance (" + 
                            tolerance + ")" + newLine);
         
                    for (int n = getKeyPoint()+1; n < getEndPoint()-1; n++){
                        setPointToDelete(getPoints().get(n));
                        getPoints2().remove(getPointToDelete());
                        System.out.println("Removing " + getPoints().get(n).getID());
                        str = str + ", " +  getPoints().get(n).getID();           
                        lp = new LinePerformance();
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" + 
                                lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(), 
                                        getPoints2()));  
                        setPoints2(getPoints2());
                        repaint();    
                    }
              
                    writeToTextAreaCommentary("Removed point(s) " + str + "" 
                            + newLine);     
                    
                    setKeyPoint(getEndPoint()-1);
                    
                    if (getKeyPoint() + lookAhead < getPoints().size()){
                        setEndPoint(getKeyPoint() + lookAhead);                        
                        System.out.println("keyPoint = " + getKeyPoint());                       
                        System.out.println("endPoint = " + getEndPoint());
                    }
                    else{
                        setEndPoint(getPoints().size());
                        System.out.println("keyPoint = " + getKeyPoint());  
                        System.out.println("ENDPOINT:" + getEndPoint());
                    }
                }
                else{
                     setEndPoint(getEndPoint() - 1); 
                }   
            }
         
            if(getKeyPoint() == getEndPoint() - 1){
                 jTextAreaCommentary.setText("");
                    writeToTextAreaCommentary("Processing complete -"
                            + " simplified line (blue)" + newLine);
                    writeToTextAreaCommentary("Original Line Length: " + 
                            String.valueOf(String.format( "%.2f", 
                                    lp.sumLineSegmentLengths(getPoints()))) 
                            + newLine);
                    writeToTextAreaCommentary("Simplified Line Length: " + 
                            String.valueOf(String.format( "%.2f",
                                    lp.sumLineSegmentLengths(getPoints2()))) 
                            + newLine);
                    lp.percentageChangeInLineLengths(getPoints(), getPoints2());
                    writeToTextAreaCommentary("Percentage decrease Line Length: " 
                    + String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
            }
          
        }   
        return simplifiedLinePts;  
    }
    
   
   /**
    * RDP
    * 
    * This method is not working, but is an attempt to incorporate
    * a step counter with the use of RamerDouglasPeucker method with step
    * counter method
    * 
    * @param pts
    * @param perpendicularDistanceTolerance
    * @param count
    * @return points - Collection of points representing simplified line
    */
   
    public ArrayList<Point> rdp(ArrayList<Point> pts, int perpendicularDistanceTolerance, int count){
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();

        System.out.println("COUNT IS:" + getCount());
        setCount(getCount() + 1);
        System.out.println("The count is:" + getCount());
        
        //Run Douglas Peucker Completely
       // if (getCount()-1 == 0){
            ramerDouglasPeucker(getPoints2(),perpendicularDistanceTolerance);
            System.out.println("This was executed!");
        //}
        //Step through output of the Douglas Peucker
        if (getCount()-1 == 1){
            for (int i = getCount()-1; i < getIndividualDPSteps().size(); i++){
                ArrayList<Point> linePts = getIndividualDPSteps().get(i);
                //for(int j = 0; j < linePts.size(); j++){
                //    simplifiedLinePts.add(linePts.get(j));
                //}
                
                
            }
        }
        setPoints2(simplifiedLinePts);
        repaint();
        return simplifiedLinePts;
    }
   
   
    /**
     * 6. Ramer Douglas Peucker Line Simplification
     * 
     * Version of algorithm without step counter taken from Line Simplification
     * Class and a copy of the input points (individualDPSteps) is taken when the
     * algorithm is called so processing steps can be traced/recorded
     * Not working properly. Tool is configured to use the version in
     * LineSimplifcation class
     * 
     * Type: Global Routine
     * 
     * Taken from project proposal:
     * 
     * Step 1 - User specifies a maximum perpendicular distance
     * Step 2 - Draw the original line
     * Step 3 - Create the initial simplified line between start and 
     *          end point of original line
     * Step 4 - For each point (excluding start and end point)
     * Step 5 - Create a perpendicular distance from point to simplified line
     * Step 6 - If perpendicular distance is larger than maximum perpendicular 
     *          distance tolerance
     * Step 7 - Point with this distance is used to partition line into 
     *          point subsets
     * Step 8 - Remove points with perpendicular distances in each subset smaller
     *          than the maximum perpendicular distance
     * Step 9 - Draw simplified line from start to end points of each point subset
     * Step 10 - Repeat steps 4-9 until all perpendicular distances are smaller
     *           than the maximum perpendicular distance tolerance
     * Step 11 - Display the simplified line and label
     * Step 12 - Remove the original line and label
     * 
     * Two parts to algorithm
     * First part of algorithm looks through input one dimension array and finds
     * point which is furthest away using (a) maxDistance and records its 
     * (b) points index position.
     * These are both needed for second part of algorithm
     * 
     * Second part of algorithm removes any points that are within epsilon 
     * (user specified threshold in display units), hence simplifying line
     * 
     * ref: http://web.cs.sunyit.edu/~poissad/projects/Curve/about_algorithms
     * /douglas.php
     * ref: https://en.wikipedia.org/wiki/Ramer%E2%80%93Douglas%E2%80%93Peucker_
     * algorithm
     * 
     * @param pts - Points representing original line points
     * @param perpendicularDistanceTolerance - Value representing the 
     *                                  perpendicular distance tolerance
     * @return  ArrayList of points after line simplification  
     */
     public ArrayList<Point> ramerDouglasPeucker(ArrayList<Point> pts,
             double perpendicularDistanceTolerance){
        
        ArrayList<ArrayList<Point>> individualDPSteps = new ArrayList<>();
        individualDPSteps.add(new ArrayList<>(pts));
        setIndividualDPSteps(individualDPSteps);
        
        ArrayList<Point> originalPtsList = pts;
        ArrayList<Point> simplifiedPtsList = new ArrayList<>();
        ArrayList<Point> pointList1 = new ArrayList<>();
        ArrayList<Point> pointList2 = new ArrayList<>();
        ArrayList<Point> results1 = new ArrayList<>();
        ArrayList<Point> results2 = new ArrayList<>();
        ArrayList<Point> lineSegment = new ArrayList<>();
        ArrayList<ArrayList<Point>> lineSegments = new ArrayList<>();
        ArrayList<Point> pointsToKeep = new ArrayList<>();
        Point startPoint = null;
        Point endPoint = null;
        
        //Find the intermediate point with the max perpendicular 
        //distance from simplified line
	//double perpendicularDistance = 0;
        double maxPerpendicularDistance = 0;
        int pointIndexPosition = 0;
        String strStart = "";
        String strEnd = "";
        String strIntermediatePoint = "";

        //Iterate through each of the original points and find the intermediate 
        //point with the maximum perpendicular distance from the simplfied line
        for (int i = 1; i < originalPtsList.size()-1; i++){
            startPoint = originalPtsList.get(0);
            endPoint = originalPtsList.get(originalPtsList.size()-1);
            Point intermediatePoint = originalPtsList.get(i);
            Liner simplifiedLine = new Liner(startPoint, endPoint); 
            double perpendicularDistance = 
             ls.distanceOfPointPerpendicularToLine(originalPtsList.get(i), 
                     simplifiedLine);
            
          
            //Determine intermediate point to keep
            if (perpendicularDistance >= maxPerpendicularDistance){
                maxPerpendicularDistance = perpendicularDistance;
                pointIndexPosition = i;
                strStart = startPoint.getID();
                strEnd = endPoint.getID();
                strIntermediatePoint = intermediatePoint.getID();
            }
        }
    

        System.out.println("Start of simplified line: " + strStart + ", "
                + "End of simplified line: " + strEnd); 
        
       // if(startPoint.getID().equals(strStart) & endPoint.getID().equals(strEnd)){
           
            lineSegment.add(startPoint); //
            lineSegment.add(endPoint); //
            lineSegments.add(new ArrayList<>(lineSegment));//
            pointsToKeep.add(intermediatePoint); //
            setLineSegments(lineSegments); //
       // }
       
        if (maxPerpendicularDistance >= perpendicularDistanceTolerance){
            System.out.println("Point " + strIntermediatePoint +
                    " has Maximum Distance " + maxPerpendicularDistance + 
                " greater than " + perpendicularDistanceTolerance + " threshold");
            System.out.println("Keep " + strIntermediatePoint); 
        }
        else{
            System.out.println("Point " + strIntermediatePoint + 
                    " has Maximum Distance " + maxPerpendicularDistance + 
                " smaller than " + perpendicularDistanceTolerance + " threshold");
            System.out.println("Remove " + strIntermediatePoint); 
        }
        
        //Build 2 lists of points to process:
        //First list (first point to point with max perpendicular distance)      
        for (int j = 0; j < pointIndexPosition + 1; j++){
            pointList1.add(originalPtsList.get(j));
        }
        //Second list (point with max perpendicular distance to last point)
        for (int k = pointIndexPosition; k < originalPtsList.size(); k++){
            pointList2.add(originalPtsList.get(k));
        }
        
        
        ArrayList<Liner> pointList1DistortionLines = new ArrayList<>();
      
        //Process each half of partitioned list
        if (maxPerpendicularDistance > perpendicularDistanceTolerance){
            results1 = ramerDouglasPeucker(pointList1,
                    perpendicularDistanceTolerance); 
            results2 = ramerDouglasPeucker(pointList2, 
                    perpendicularDistanceTolerance); 
            
                
                //Draw perpendicular distances from each point in pointList1
                for (int f = 0; f < pointList1.size(); f++){ 
                    LinePerformance lp = new LinePerformance();
                    Point p = pointList1.get(f);
                    Point startPoint1 = results1.get(0);
                    Point endPoint1 = results1.get(results1.size()-1);
                    //Create Point (p2) where distortion distance intersects
                    //simplified line
                    String coord =  "p" + f + "," +
                            lp.createPerpendicularPoint(p, startPoint1, endPoint1);
                    Point p2 = new Point(coord);
                    Liner pointList1DistortionLine = new Liner(p,p2);
                    //System.out.println("PointList1:" + 
                    //        pointList1DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList1DistortionLine);            
                }
                setPointList1DistortionLines(new ArrayList<>(
                        pointList1DistortionLines));
                 
                //Result of simplified line
                for (int n = 0; n < results2.size(); n++){
                    simplifiedPtsList.add(results2.get(n));
                }
                
                //Draw perpendicular distances from each point in pointList1
                for (int g = 0; g < pointList2.size(); g++){ 
                    LinePerformance lp = new LinePerformance();
                    Point p = pointList2.get(g);
                    Point startPoint2 = results2.get(0);
                    Point endPoint2 = results2.get(results2.size()-1);
                    //Create Point (p2) where distortion distance intersects 
                    //simplified line
                    String coord =  "p" + g + "," + 
                            lp.createPerpendicularPoint(p, startPoint2, endPoint2);
                    Point p2 = new Point(coord);
                    Liner pointList2DistortionLine = new Liner(p,p2);
                    //System.out.println("PointList2:" + 
                    //        pointList2DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList2DistortionLine);            
                }
                setPointList1DistortionLines(new ArrayList<>(
                        pointList1DistortionLines));
                
        }
        else{
            //Add start and end points to simplifiedPtsList
            simplifiedPtsList.add(originalPtsList.get(0));                         
            simplifiedPtsList.add(originalPtsList.get(originalPtsList.size()-1));   
        }
        
        //Print out contents of lineSegments to screen
        System.out.println("Contents of lineSegments");
        for(int i = 0; i < getLineSegments().size(); i++){
            ArrayList<Point> points = getLineSegments().get(i);
            System.out.println("List " + (i+1));
            for(int j = 0; j < points.size(); j++){
                System.out.println(points.get(j).getID());
            }
        }
        
         //Print out contents of lineSegments to screen
        System.out.println("Contents of individualDPSteps");
        for(int i = 0; i < getIndividualDPSteps().size(); i++){
            ArrayList<Point> points = getIndividualDPSteps().get(i);
            System.out.println("List " + (i+1));
            for(int j = 0; j < points.size(); j++){
                System.out.println(points.get(j).getID());
            }
        }
        
        return simplifiedPtsList;
     }
     
//    /**
//    * Ramer Douglas Peucker Using Counter  (Not working)
//    *  
//    * One of a couple of attempts ti implement Ramer Douglas Peucker with Counter
//    *
//    * @param pts - Points representing the original line points
//    * @param perpendicularDistanceTolerance - Value representing the 
//    *                                         perpendicular tolerance
//    * @param count - Value representing a counter value. Set by the calling 
//    *                method
//    * @return simplifiedLinePts - Points representing the simplified line points
//    */
//        
//    public ArrayList<Point> ramerDouglasPeuckerUsingCounter(ArrayList<Point> pts, 
//        double perpendicularDistanceTolerance, int count){    
//        
//        int tolerance = Integer.parseInt(txtPerpendicularDistance.getText()); 
//        double maxPerpendicularDistance = 0;
//        int pointIndexPosition = 0;
//        Point maxPointToKeep = null;
//        //LinerItem lineWithMaxDistance = null;
//        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
//        ArrayList<Liner> simplifiedLineAsLineSegments = new ArrayList<>();
//        Point startPoint = null;
//        Point endPoint = null;
//        double perpendicularDistance = 0;
//        ArrayList<Point> list1 = new ArrayList<>();
//        ArrayList<Point> list2 = new ArrayList<>();
//        
//        Liner resultLine1 = null;
//        Liner resultLine2 = null;
//        
//        setCount(getCount()+1);
//        System.out.println("The count is:" + getCount());
//        
//        //Initial line
//        if(getCount()-1 == 0){
//            simplifiedLinePts.add(pts.get(0));
//            simplifiedLinePts.add(pts.get(pts.size()-1));
//            ArrayList<ArrayList<Point>> listOfLists1 =
//                    new ArrayList<ArrayList<Point>>();
//            ArrayList<ArrayList<Point>> listOfLists2 = 
//                    new ArrayList<ArrayList<Point>>();
//        }
//
//        if (getCount()-1 > 0){     
//            //Get start and end points of the simplified line
//            startPoint = pts.get(0);
//            endPoint = pts.get(pts.size()-1);
//            Liner simplifiedLine = new Liner(startPoint, endPoint);
//        
//            //4. Calculate point with the maximum distance of all 
//            //Simplified Line Pts to the simplified Line
//            for(int j = 1; j < pts.size()-1; j++){
//                Point intermediatePoint = pts.get(j);
//                perpendicularDistance =
//                ls.distanceOfPointPerpendicularToLine(intermediatePoint, 
//                        simplifiedLine);
//                System.out.println(perpendicularDistance);
//                //Determine intermediate point to keep
//                if (perpendicularDistance > getMaximumPerpendicularDistance()){
//                    setMaximumPerpendicularDistance(perpendicularDistance);
//                    pointIndexPosition = j;
//                    maxPointToKeep = pts.get(j);
//                }
//            }
//        
//            if (getMaximumPerpendicularDistance() < tolerance){
//                System.out.println("Davison");
//            }
//            
//            if (getMaximumPerpendicularDistance() > tolerance)
//                resultLine1 = new Liner(startPoint, maxPointToKeep);
//                //setResultLine1(resultLine1);
//                simplifiedLineAsLineSegments.add(resultLine1);
//                resultLine2 = new Liner(maxPointToKeep, endPoint);
//                //setResultLine2(resultLine2);
//                simplifiedLineAsLineSegments.add(resultLine2);
//                               
//                //Add segments to collection for later retrieval
//                list1.add(startPoint);
//                list1.add(maxPointToKeep);
//        
//                list2.add(maxPointToKeep);
//                list2.add(endPoint);
//                
//                listOfLists1.add(new ArrayList<>(list1));  //Collection 1
//                listOfLists2.add(new ArrayList<>(list2));  //Collection 2
//                
//                setListOfLists1(listOfLists1);
//                  ramerDouglasPeuckerUsingCounter(list1,tolerance,getCount());
//               
//                setListOfLists2(listOfLists2);
//                  ramerDouglasPeuckerUsingCounter(list2,tolerance,getCount());
//                
//                //Use each segment to create version of the line
//                for(int f = 0; f < simplifiedLineAsLineSegments.size(); f++){
//                    Liner line = simplifiedLineAsLineSegments.get(f);
//                    Point p = line.getLinerPoint1();
//                    Point p2 = line.getLinerPoint2();
//                    
//                    if(!(ls.isPointInLine(p, simplifiedLinePts))){
//                        simplifiedLinePts.add(p);
//                    }
//                    if(!(ls.isPointInLine(p2, simplifiedLinePts))){ 
//                        simplifiedLinePts.add(p2);
//                    }
//                }
//            } 
//        
//        return simplifiedLinePts;
//      }
    
//    /**
//    * Ramer Douglas Peucker Using Counter 2  (Not working)
//    *  
//    * One of four attempts to implement Ramer Douglas Peucker with Counter
//    *
//    * @param pts - Points representing the original line points
//    * @param perpendicularDistanceTolerance - Value representing the 
//    *                                         perpendicular tolerance
//    * @param count - Value representing a counter value. Set by the calling 
//    *                method
//    * @return simplifiedLinePts - Points representing the simplified line points
//    */
//           
//    private ArrayList<Point> ramerDouglasPeuckerUsingCounter2(ArrayList<Point> pts, 
//        double perpendicularDistanceTolerance, int count){
//        //Find the intermediate point with the max perpendicular distance from simplified line
//	double perpendicularDistance = 0;
//        double maxPerpendicularDistance = 0;
//        int pointIndexPosition = 0;
//        String strStart = "";
//        String strEnd = "";
//        String strIntermediatePoint = "";
//
//        ArrayList<Point> originalPtsList = pts;
//        ArrayList<Point> simplifiedPtsList = new ArrayList<>();
//        ArrayList<Point> pointList1 = new ArrayList<>();
//        ArrayList<Point> pointList2 = new ArrayList<>();
//        ArrayList<Point> results1 = new ArrayList<>();
//        ArrayList<Point> results2 = new ArrayList<>();
//        LineSimplification ls = new LineSimplification();
//        LinePerformance lp = new LinePerformance();
//        Point startPoint = null;
//        Point endPoint = null;
//        Point intermediatePoint = null;
//        Point maxPointToKeep = null;
//        ArrayList<Point> circles = new ArrayList<>();
//        int count2 = 0;
//        int count3 = 0;
// 
//        setCount(getCount()+1);
//        System.out.println("The count is:" + getCount());
//        
//        if (getCount()-1 == 0){
//            //1.Reset (clear) Distortion Lines
//            setPointList1DistortionLines(new ArrayList<>());
//            
//            for (int i = 1; i < originalPtsList.size()-1; i++){
//                startPoint = originalPtsList.get(0);
//                endPoint = originalPtsList.get(originalPtsList.size()-1);
//                intermediatePoint = originalPtsList.get(i);
//                Liner simplifiedLine = new Liner(startPoint, endPoint); 
//                perpendicularDistance = 
//                        ls.distanceOfPointPerpendicularToLine(originalPtsList.get(i),
//                                simplifiedLine);
//
//                //Determine intermediate point to keep
//                if (perpendicularDistance >= maxPerpendicularDistance){
//                    maxPerpendicularDistance = perpendicularDistance;
//                    pointIndexPosition = i;
//                    strStart = startPoint.getID();
//                    strEnd = endPoint.getID();
//                    strIntermediatePoint = intermediatePoint.getID();
//                    maxPointToKeep = intermediatePoint; 
//                }
//                
//                //2.Create initial simplified line between original line start and end points
//                simplifiedPtsList.add(startPoint);
//                simplifiedPtsList.add(endPoint);
//              
//                //3. Create and store distortion line(s) between each original Line pt (intermediate pt) 
//                String coord =  "p" + i + "," + lp.createPerpendicularPoint(intermediatePoint, startPoint, endPoint);
//                Point p2 = new Point(coord);
//                Liner pointList1DistortionLine = new Liner(intermediatePoint,p2);
//                System.out.println("PointList:" + intermediatePoint.getID() + "," + pointList1DistortionLine.getLength());
//                getPointList1DistortionLines().add(pointList1DistortionLine);    
//            }    
//            setLiners(getPointList1DistortionLines());
//            circles.add(maxPointToKeep);
//            setCircles(circles);
//            repaint();
//        }
//        
//        if (getCount()-1 == 1){
//            //Reset (clear) Circles and Distortion Lines
//            setCircles(null);
//            setPointList1DistortionLines(new ArrayList<>());
//            setLiners(new ArrayList<>());
//            simplifiedPtsList = new ArrayList<>();
//            
//            //Iterate through each of the original points and find the intermediate point with the maximum perpendicular distance from the simplfied line
//            for (int p = 1; p < originalPtsList.size()-1; p++){
//                Point startPoint1 = originalPtsList.get(0);
//                Point endPoint1 = originalPtsList.get(originalPtsList.size()-1);
//                Point intermediatePoint1 = originalPtsList.get(p);
//                Liner simplifiedLine1 = new Liner(startPoint1, endPoint1); 
//                perpendicularDistance = ls.distanceOfPointPerpendicularToLine(originalPtsList.get(p), simplifiedLine1);
//            
//                //Determine intermediate point to keep
//                if (perpendicularDistance >= maxPerpendicularDistance){
//                    maxPerpendicularDistance = perpendicularDistance;
//                    pointIndexPosition = p;
//                    strStart = startPoint1.getID();
//                    strEnd = endPoint1.getID();
//                    strIntermediatePoint = intermediatePoint1.getID();
//                }
//            }    
//        
//            //Partition list into two lists (using maxPoint position (pointIndexPosition)
//            //First list (first point to point with max perpendicular distance)
//            for (int j = 0; j < pointIndexPosition + 1; j++){
//                pointList1.add(originalPtsList.get(j));
//            }
//            //Second list (point with max perpendicular distance to last point)
//            for (int k = pointIndexPosition; k < originalPtsList.size(); k++){
//                pointList2.add(originalPtsList.get(k));
//            }
//
//            setPointList1DistortionLines(new ArrayList<>());
//             
//            //Process each half of partitioned list
//            if (maxPerpendicularDistance > perpendicularDistanceTolerance){
//               
//                    results1 = ramerDouglasPeuckerUsingCounter(pointList1, perpendicularDistanceTolerance, count);  //recursive call
//                
//                    //for (int m = 0; m < results1.size()-1; m++){
//                        simplifiedPtsList.add(results1.get(0));
//                        simplifiedPtsList.add(intermediatePoint);
//                        simplifiedPtsList.add(results1.get(results1.size()-1));
//                       
//                    //}
//                   
//                    //Draw perpendicular distances from each point in pointList1
//                    for (int f = 0; f < pointList1.size(); f++){ 
//                        Point p = pointList1.get(f);
//                        Point startPoint1 = results1.get(0);
//                        Point endPoint1 = results1.get(results1.size()-1);
//                        String coord =  "p" + f + "," + lp.createPerpendicularPoint(p, startPoint1, endPoint1);
//                        Point p2 = new Point(coord);
//                        Liner pointList1DistortionLine = new Liner(p,p2);
//                        System.out.println("PointList1:" + p.getID() + "," + pointList1DistortionLine.getLength());
//                        getPointList1DistortionLines().add(pointList1DistortionLine); 
//                    }
//                    setLiners(new ArrayList<>(getPointList1DistortionLines()));
//                    
//                    results2 = ramerDouglasPeuckerUsingCounter(pointList2, perpendicularDistanceTolerance, count);  //recursive call
//                    //setPointList1DistortionLines(new ArrayList<>());
//                    for (int n = 0; n < results2.size(); n++){
//                        simplifiedPtsList.add(results2.get(0));
//                        simplifiedPtsList.add(results2.get(results2.size()-1));
//                    }
//
////                   //Draw perpendicular distortion distances from each point in pointList2
//                    for (int g = 0; g < pointList2.size(); g++){ 
//                        Point p = pointList2.get(g);
//                        Point startPoint2 = results2.get(0);
//                        Point endPoint2 = results2.get(results2.size()-1);
//                        String coord =  "p" + g + "," + lp.createPerpendicularPoint(p, startPoint2, endPoint2);
//                        Point p2 = new Point(coord);
//                        Liner pointList2DistortionLine = new Liner(p,p2);
//                        System.out.println("PointList2:" + p.getID() + "," +  pointList2DistortionLine.getLength());
//                        getPointList1DistortionLines().add(pointList2DistortionLine);    //05/07/2016 to Turn of lines           
//                    }
////                    setPointList1DistortionLines(getPointList1DistortionLines());
//                    setLiners(new ArrayList<>(getPointList1DistortionLines()));
//                
////                //Draw circles for original line points that have been(to be) removed
////                for(int y = 1; y < results1.size(); y++){
////                    circles.add(results1.get(y));                   
////                }
////                for(int h = 0; h < results2.size()-1; h++){
////                    circles.add(results2.get(h));                   
////                }
////                setCircles(circles);
////                repaint();                
//            }   
//            else{
//                //System.out.println("Removed all intermediate points between " + strStart + " and " + strEnd);  //DEBUG
//                 //Add start and end points to simplifiedPtsList
//                simplifiedPtsList.add(originalPtsList.get(0));                         
//                simplifiedPtsList.add(originalPtsList.get(originalPtsList.size()-1)); 
//            }
//        
//            // jTextAreaCommentary.setText("" + getPointToDelete().getID() + " Removed");
//            setPoints2(simplifiedPtsList);
//            lp = new LinePerformance();
//            lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
//            lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
//            lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));  
//            repaint();
//        } 
//        return simplifiedPtsList;
//    }   
     
//    /**
//    * Ramer Douglas Peucker Using Counter 3  
//    *  
//    * Shows some graphics for early steps but not (fully working)
//    *          
//    * One of four attempts to implement Ramer Douglas Peucker with Counter
//    *
//    * @param pts - Points representing the original line points
//    * @param perpendicularDistanceTolerance - Value representing the 
//    *                                         perpendicular tolerance
//    * @param count - Value representing a counter value. Set by the calling 
//    *                method
//    * @return simplifiedLinePts - Points representing the simplified line points
//    */
//              
//  public ArrayList<Point> ramerDouglasPeuckerUsingCounter(ArrayList<Point> pts, 
//        double perpendicularDistanceTolerance, int count){    
//        
//        int tolerance = Integer.parseInt(txtPerpendicularDistance.getText()); 
//        double maxPerpendicularDistance = 0;
//        int pointIndexPosition = 0;
//        Point maxPointToKeep = null;
//        //LinerItem lineWithMaxDistance = null;
//        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
//        ArrayList<Liner> simplifiedLineAsLineSegments = new ArrayList<>();
//        Point startPoint = null;
//        Point endPoint = null;
//        double perpendicularDistance = 0;
//        ArrayList<Point> list1 = new ArrayList<>();
//        ArrayList<Point> list2 = new ArrayList<>();
//        
//        Liner resultLine1 = null;
//        Liner resultLine2 = null;
//        
//        setCount(getCount()+1);
//        System.out.println("The count is:" + getCount());
//        
//        //Initial line
//        if(getCount() == 1){
//            //1.Reset (clear) Distortion Lines
//            setPointList1DistortionLines(new ArrayList<>());
//  
//            simplifiedLinePts.add(pts.get(0));
//            simplifiedLinePts.add(pts.get(pts.size()-1));
//            ArrayList<ArrayList<Point>> listOfLists1 = new ArrayList<ArrayList<Point>>();
//            ArrayList<ArrayList<Point>> listOfLists2 = new ArrayList<ArrayList<Point>>();
//            
//            
//            for (int i = 1; i < pts.size()-1; i++){
//                startPoint = pts.get(0);
//                endPoint = pts.get(pts.size()-1);
//                intermediatePoint = pts.get(i);
//                Liner simplifiedLine = new Liner(startPoint, endPoint); 
//                perpendicularDistance = ls.distanceOfPointPerpendicularToLine(pts.get(i), simplifiedLine);
//                //3. Create and store distortion line(s) between each original Line pt (intermediate pt) 
//                String coord =  "p" + i + "," + lp.createPerpendicularPoint(intermediatePoint, startPoint, endPoint);
//                Point p2 = new Point(coord);
//                Liner pointList1DistortionLine = new Liner(intermediatePoint,p2);
//                System.out.println("PointList:" + intermediatePoint.getID() + "," + pointList1DistortionLine.getLength());
//                getPointList1DistortionLines().add(pointList1DistortionLine); 
//            }    
//            setLiners(getPointList1DistortionLines());
//            //circles.add(maxPointToKeep);
//            //setCircles(new ArrayList<Point>(circles));
//            repaint();
//        }
//
//        if (getCount() > 1){     
//            //1.Reset (clear) Distortion Lines
//            setLiners(new ArrayList<>());
//            repaint();
//            //Get start and end points of the simplified line
//            startPoint = pts.get(0);
//            endPoint = pts.get(pts.size()-1);
//            Liner simplifiedLine = new Liner(startPoint, endPoint);
//        
//            //4. Calculate point with the maximum distance of all 
//            //Simplified Line Pts to the simplified Line
//            for(int j = 1; j < pts.size()-1; j++){
//                startPoint = pts.get(0);
//                endPoint = pts.get(pts.size()-1);
//                intermediatePoint = pts.get(j);
//
//                //Point intermediatePoint = pts.get(j);
//                perpendicularDistance =
//                ls.distanceOfPointPerpendicularToLine(intermediatePoint, 
//                        simplifiedLine);
//                System.out.println(perpendicularDistance);
//                //Determine intermediate point to keep
//                if (perpendicularDistance > getMaximumPerpendicularDistance()){
//                    setMaximumPerpendicularDistance(perpendicularDistance);
//                    pointIndexPosition = j;
//                    maxPointToKeep = pts.get(j);
//                }
//                
//                //3. Create and store distortion line(s) between each original Line pt (intermediate pt) 
//                String coord =  "p" + i + "," + lp.createPerpendicularPoint(intermediatePoint, startPoint, endPoint);
//                Point p2 = new Point(coord);
//                Liner pointList1DistortionLine = new Liner(intermediatePoint,p2);
//                System.out.println("PointList:" + intermediatePoint.getID() + "," + pointList1DistortionLine.getLength());
//                getPointList1DistortionLines().add(pointList1DistortionLine);    
//            }
//             setLiners(getPointList1DistortionLines());
////           circles.add(maxPointToKeep);
////           setCircles(new ArrayList<Point>(circles));
//            repaint();
//            
//            
//        
//            if (getMaximumPerpendicularDistance() < tolerance){
//                System.out.println("Davison");
//            }
//            
//            setLiners(getPointList1DistortionLines());
//            //circles.add(maxPointToKeep);
//            //setCircles(circles);
//            repaint();
//            
//            if (getMaximumPerpendicularDistance() > tolerance)
//                resultLine1 = new Liner(startPoint, maxPointToKeep);
//                //setResultLine1(resultLine1);
//                simplifiedLineAsLineSegments.add(resultLine1);
//                resultLine2 = new Liner(maxPointToKeep, endPoint);
//                //setResultLine2(resultLine2);
//                simplifiedLineAsLineSegments.add(resultLine2);
//                               
////                //Add segments to collection for later retrieval
////                list1.add(startPoint);
////                list1.add(maxPointToKeep);
////        
////                list2.add(maxPointToKeep);
////                list2.add(endPoint);
////                
////                listOfLists1.add(new ArrayList<>(list1));  //Collection 1
////                listOfLists2.add(new ArrayList<>(list2));  //Collection 2
////                
////                setListOfLists1(listOfLists1);
//                  //ramerDouglasPeuckerUsingCounter(list1,tolerance,getCount());
////               
////                setListOfLists2(listOfLists2);
//                  //ramerDouglasPeuckerUsingCounter(list2,tolerance,getCount());
//                
//                //Use each segment to create version of the line
//                for(int f = 0; f < simplifiedLineAsLineSegments.size(); f++){
//                    Liner line = simplifiedLineAsLineSegments.get(f);
//                    Point p = line.getLinerPoint1();
//                    Point p2 = line.getLinerPoint2();
//                    
//                    if(!(ls.isPointInLine(p, simplifiedLinePts))){
//                        simplifiedLinePts.add(p);
//                    }
//                    if(!(ls.isPointInLine(p2, simplifiedLinePts))){ 
//                        simplifiedLinePts.add(p2);
//                    }
//                }
//            } 
//        
//        return simplifiedLinePts;
//      }    
     
    
    /**
    * Ramer Douglas Peucker Using Counter 4  
    *  
    * Shows some graphics for early steps but not (fully working)
    *          
    * One of a four attempts to implement Ramer Douglas Peucker with Counter
    *
    * @param pts - Points representing the original line points
    * @param perpendicularDistanceTolerance - Value representing the 
    *                                         perpendicular tolerance
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    * @return simplifiedLinePts - Points representing the simplified line points
    */
            
    public ArrayList<Point> ramerDouglasPeuckerUsingCounter(ArrayList<Point> pts, double perpendicularDistanceTolerance, int count){
        //Find the intermediate point with the max perpendicular distance from simplified line
	double perpendicularDistance = 0;
        double maxPerpendicularDistance = 0;
        int pointIndexPosition = 0;
        String strStart = "";
        String strEnd = "";
        String strIntermediatePoint = "";

        ArrayList<Point> originalPtsList = pts;
        ArrayList<Point> simplifiedPtsList = new ArrayList<>();
        ArrayList<Point> pointList1 = new ArrayList<>();
        ArrayList<Point> pointList2 = new ArrayList<>();
        ArrayList<Point> results1 = new ArrayList<>();
        ArrayList<Point> results2 = new ArrayList<>();
        LineSimplification ls = new LineSimplification();
        LinePerformance lp = new LinePerformance();
        Point startPoint = null;
        Point endPoint = null;
        Point intermediatePoint = null;
        Point maxPointToKeep = null;
        ArrayList<Point> circles = new ArrayList<>();
        int count2 = 0;
        
        setCount(getCount() + 1);
        
        if (getCount() == 1){
            //1.Reset (clear) Distortion Lines
            setPointList1DistortionLines(new ArrayList<>());
            
            for (int i = 1; i < originalPtsList.size()-1; i++){
                startPoint = originalPtsList.get(0);
                endPoint = originalPtsList.get(originalPtsList.size()-1);
                intermediatePoint = originalPtsList.get(i);
                Liner simplifiedLine = new Liner(startPoint, endPoint); 
                perpendicularDistance = ls.distanceOfPointPerpendicularToLine(originalPtsList.get(i), simplifiedLine);

                //Determine intermediate point to keep
                if (perpendicularDistance >= maxPerpendicularDistance){
                    maxPerpendicularDistance = perpendicularDistance;
                    pointIndexPosition = i;
                    strStart = startPoint.getID();
                    strEnd = endPoint.getID();
                    strIntermediatePoint = intermediatePoint.getID();
                    maxPointToKeep = intermediatePoint; 
                }
                
                //2.Create initial simplified line between original line start and end points
                simplifiedPtsList.add(startPoint);
                simplifiedPtsList.add(endPoint);
              
                //3. Create and store distortion line(s) between each original Line pt (intermediate pt) 
                String coord =  "p" + i + "," + lp.createPerpendicularPoint(intermediatePoint, startPoint, endPoint);
                Point p2 = new Point(coord);
                Liner pointList1DistortionLine = new Liner(intermediatePoint,p2);
                System.out.println("PointList:" + intermediatePoint.getID() + "," + pointList1DistortionLine.getLength());
                getPointList1DistortionLines().add(pointList1DistortionLine);    
            }    
            setLiners(getPointList1DistortionLines());
            circles.add(maxPointToKeep);
            setCircles(circles);
            repaint();
        }
        
        if (getCount() > 1){
            //Reset (clear) Circles and Distortion Lines
            setCircles(null);
            setPointList1DistortionLines(new ArrayList<>());
            setLiners(new ArrayList<>());
            simplifiedPtsList = new ArrayList<>();
            
            //Iterate through each of the original points and find the intermediate point with the maximum perpendicular distance from the simplfied line
            for (int p = 1; p < originalPtsList.size()-1; p++){
                Point startPoint1 = originalPtsList.get(0);
                Point endPoint1 = originalPtsList.get(originalPtsList.size()-1);
                Point intermediatePoint1 = originalPtsList.get(p);
                Liner simplifiedLine1 = new Liner(startPoint1, endPoint1); 
                perpendicularDistance = ls.distanceOfPointPerpendicularToLine(originalPtsList.get(p), simplifiedLine1);
            
                //Determine intermediate point to keep
                if (perpendicularDistance >= maxPerpendicularDistance){
                    maxPerpendicularDistance = perpendicularDistance;
                    pointIndexPosition = p;
                    strStart = startPoint1.getID();
                    strEnd = endPoint1.getID();
                    strIntermediatePoint = intermediatePoint1.getID();
                }
            }    
        
            //System.out.println("PointPositionIndex:" + pointIndexPosition);  //DEBUG
            System.out.println("Start of simplified line: " + strStart + ", End of simplified line: " + strEnd); 

            if (maxPerpendicularDistance >= perpendicularDistanceTolerance){
                System.out.println("Point " + strIntermediatePoint + " has Maximum Distance " + maxPerpendicularDistance + 
                " greater than " + perpendicularDistanceTolerance + " threshold");
                System.out.println("Keep " + strIntermediatePoint); 
            }
            else{
                System.out.println("Point " + strIntermediatePoint + " has Maximum Distance " + maxPerpendicularDistance + 
                " smaller than " + perpendicularDistanceTolerance + " threshold");
                System.out.println("Remove " + strIntermediatePoint); 
            }

            //Partition list into two lists (using maxPoint position (pointIndexPosition)
            //First list (first point to point with max perpendicular distance)
            for (int j = 0; j < pointIndexPosition + 1; j++){
                pointList1.add(originalPtsList.get(j));
            }
            //Second list (point with max perpendicular distance to last point)
            for (int k = pointIndexPosition; k < originalPtsList.size(); k++){
                pointList2.add(originalPtsList.get(k));
            }

            //Process each half of partitioned list
            if (maxPerpendicularDistance > perpendicularDistanceTolerance){
                results1 = ramerDouglasPeuckerUsingCounter(pointList1, perpendicularDistanceTolerance, count);  //recursive call
                results2 = ramerDouglasPeuckerUsingCounter(pointList2, perpendicularDistanceTolerance, count);  //recursive call
               
                for (int m = 0; m < results1.size()-1; m++){
                    simplifiedPtsList.add(results1.get(m));
                }
                
                setPointList1DistortionLines(new ArrayList<>());
                //Draw perpendicular distances from each point in pointList1
                for (int f = 0; f < pointList1.size(); f++){ 
                    Point p = pointList1.get(f);
                    Point startPoint1 = pointList1.get(0); //results1.get(0);
                    Point endPoint1 = pointList2.get(0); //results1.get(results1.size()-1);
                    //Create Point (p2) where distortion distance intersects simplified line
                    String coord =  "p" + f + "," + lp.createPerpendicularPoint(p, startPoint1, endPoint1);
                    Point p2 = new Point(coord);
                    Liner pointList1DistortionLine = new Liner(p,p2);
                    System.out.println("PointList1:" + p.getID() + "," + pointList1DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList1DistortionLine);  //05/07/2016 to Turn of lines           
                }
                setLiners(new ArrayList<>(pointList1DistortionLines));
                
                //setPointList1DistortionLines(new ArrayList<>());
                for (int n = 0; n < results2.size(); n++){
                    //simplifiedPtsList.add(results2.get(n));
                    simplifiedPtsList.add(results2.get(n));
                    simplifiedPtsList.add(results2.get(results2.size()-1));
                    
                }
                
               //Draw perpendicular distortion distances from each point in pointList2
                for (int g = 0; g < pointList2.size(); g++){ 
                    Point p = pointList2.get(g);
                    Point startPoint2 = results2.get(0);
                    Point endPoint2 = results2.get(results2.size()-1);
                    //Create Point (p2) where distortion distance intersects simplified line
                    String coord =  "p" + g + "," + lp.createPerpendicularPoint(p, startPoint2, endPoint2);
                    Point p2 = new Point(coord);
                    Liner pointList2DistortionLine = new Liner(p,p2);
                    System.out.println("PointList2:" + p.getID() + "," +  pointList2DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList2DistortionLine);    //05/07/2016 to Turn of lines           
                }
                setLiners(new ArrayList<>(pointList1DistortionLines));
                
                //Draw circles for original line points that have been(to be) removed
                for(int y = 1; y < results1.size(); y++){
                    circles.add(results1.get(y));                   
                }
                for(int h = 0; h < results2.size()-1; h++){
                    circles.add(results2.get(h));                   
                }
                setCircles(circles);
                repaint();
                
                
            }   
            else{
                //System.out.println("Removed all intermediate points between " + strStart + " and " + strEnd);  //DEBUG
                 //Add start and end points to simplifiedPtsList
                simplifiedPtsList.add(originalPtsList.get(0));                         
                simplifiedPtsList.add(originalPtsList.get(originalPtsList.size()-1)); 
            }
        
            // jTextAreaCommentary.setText("" + getPointToDelete().getID() + " Removed");
            setPoints2(simplifiedPtsList);
            lp = new LinePerformance();
            lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
            lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
            lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));  
            repaint();
        } 
        return simplifiedPtsList;
    }   
 
     
   
    /**
    * VisvalingamWhyatt Using Counter
    * 
    * @param ls - Instance of Line Simplification object
    * @param count - Value representing a counter value. Set by the calling 
    *                method
    * 
    */
    public void visvalingamWhyattUsingCounter(LineSimplification ls, int count){
        String newLine = "\n";
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        ArrayList<Liner> perpendicularLines = null;
        ArrayList<Liner> simplifiedLines = null;
        ArrayList<Point> simplifiedLinePts = null;
        ArrayList<Liner> perpendicularLinesLargerThanThreshold = null;
        Polygon effectiveAreaTriangle = null;
        ArrayList<Polygon> effectiveAreaTriangles = null;
        double effectiveArea = 0;
        double minEffectiveArea = 20000000.0;
        int minAreaIndex = 0;
        Point pointToRemove = null;
        
        Liner perpendicularline = null;
        Liner simplifiedLine = null;
                
        Point p1 = null;
        Point p2 = null;
        boolean booleanContinue = false; 
        int i = 0;
        int j = 0;
        int k = 0;
        int n = 0;
        Point keyPoint = null;
        Point prevPoint = null;
        Point nextPoint = null; 
        int counter = count;
        
        try{
            n = Integer.parseInt(txtNoOfPoints.getText());
            ls.visvalingamWhyattSimplified(getPoints(),n);
                    
            if(validateNoOfPointsInput() == false){
            
            }
            else{
                ls.visvalingamWhyattSimplified(getPoints(),n);
                     if (getSimplifiedLines() == null){
                        setCircles(new ArrayList<>());
                        simplifiedLines = new ArrayList<>();
                        setSimplifiedLines(simplifiedLines);
                        simplifiedLinePts = new ArrayList<>(getPoints());
                        effectiveAreaTriangles = new ArrayList<>();
                        setEffectiveAreaTriangles(effectiveAreaTriangles);
                        setMinEffectiveArea(200000000);
                        setI(0);
                    }
                    
                    //setCount(getCount()+1);
                    setCount(counter + 1);
                    System.out.println("The count is:" + getCount());
                    
                    
                    if (getPoints2().size() == n){
                        jTextAreaCommentary.setText("");
                        writeToTextAreaCommentary("Processing complete - simplified"
                                + " line (blue)" + newLine);
                        writeToTextAreaCommentary("Original Line Length: " + 
                                String.valueOf(String.format( "%.2f", 
                                        lp.sumLineSegmentLengths(getPoints()))) 
                                + newLine);
                        writeToTextAreaCommentary("Simplified Line Length: " + 
                                String.valueOf(String.format( "%.2f", 
                                        lp.sumLineSegmentLengths(getPoints2()))) 
                                + newLine);
                        lp.percentageChangeInLineLengths(getPoints(), 
                                getPoints2());
                        writeToTextAreaCommentary("Percentage decrease " +
                                "Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.getPercentageDecreaseInLineLengths())));
                        setCircles(null);
                        repaint();
                    }
                    
                    //1. Show construct perpendicular lines and simplified lines
                    //   being built up by processing whole line and then removing 
                    //   the smallest effective area
                                         
                    if (getPoints2().size() > n){
                       //Remove intermediate point with smallest effective area            
                        if(getCount() == 1){
                            setSimplifiedLines(new ArrayList<>());
                            repaint();
                            //Process all points in whole line intermediate points 
                            //Create effective areas for each intermediate point in 
                            //the line. Draw a circle for the point which has the 
                            //smallest effective area
                            for (int v = getCount(); v < getPoints2().size()-1; v++){
                                j = v - 1;
                                k = v + 1;
                        
                                //Get points to create effective area                                
                                intermediatePoint = getPoints2().get(v);
                                prevPoint = getPoints2().get(j);
                                nextPoint = getPoints2().get(k);
                                   
                                //Get effectiveArea (Geometry) triangle for intermediate
                                //point
                                effectiveAreaTriangle = 
                                 ls.drawTriangle(intermediatePoint, prevPoint, 
                                         nextPoint, 3, 3);
                       
                                //Get effectiveArea (Area measure)
                                effectiveArea = 
                                        ls.calcTriangleArea(intermediatePoint, 
                                                prevPoint, nextPoint);
                           
                                //Store and draw effective area triangle geometry
                                //for intermediate point 
                                getEffectiveAreaTriangles().add(effectiveAreaTriangle);                           
                                repaint();
                        
                                //Get and store smallest triangle area measure value 
                                //for intermediate point
                                if(effectiveArea < minEffectiveArea){
                                    minEffectiveArea = effectiveArea;
                                    System.out.println("effectiveArea" +
                                            effectiveArea);
                                    System.out.println("getMinEffectiveArea()"
                                            + minEffectiveArea);
                                    System.out.println("Min Area Pt ID:" +
                                            intermediatePoint.getID());
                                    jTextAreaCommentary.setText("" + 
                                            intermediatePoint.getID() + 
                                            " has Min Effective Area (Triangle) " + 
                                            minEffectiveArea + ". Removing " + 
                                            intermediatePoint.getID());
                                    setPointToDelete(intermediatePoint); 
                                }               
                            }
                           //Display point to remove (via circle). 
                            lp = new LinePerformance();
                            ArrayList<Point> test = new ArrayList<>();
                            test.add(getPointToDelete());
                            setCircles(new ArrayList<>(test));
                            repaint();
                     
                        }
                        
                        
                        if(getCount() == 2 ){            
                            getPoints2().remove(getPointToDelete());
                            jTextAreaCommentary.setText("" +
                                    getPointToDelete().getID() + " Removed");
                            setEffectiveAreaTriangles(new ArrayList<>());
                            setPoints2(getPoints2());
                            lblNoOfSimplifiedLinePoints.setText("" + 
                                    getPoints2().size());
                            lblPercentageDecreaseValue.setText("" + 
                             lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                            getPoints2()));
                            lblRatioAngularityChangeValue.setText("" + 
                                    lp.ratioInChangeOfAngularity(getPoints(), 
                                            getPoints2()));  
                            setCount(0); //Reset for next version of line
                            repaint();
                           
                        } 
                    }
                } 
            }
        catch (Exception e){
            System.out.println("File not found"); 
        }
        
    }
        
       
    /** This method is called from within the constructor to
     * initialise the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        javax.swing.JPanel jPanel1 = new javax.swing.JPanel()

        {

            @Override
            public void paintComponent(Graphics g)
            {

                Point midpoint = null;
                //display all lines first (so that junctions are placed on top)

                if (lines != null){
                    //g.setColor(Color.GREEN);
                    displayLines2(g, lines); //Display input lines
                    repaint();
                }

                //display original line
                if (points != null){
                    // midpoint = null;
                    for(int ct1=0; ct1< points.size(); ct1++){
                        //int noOfPoints = points.size();
                        //int midPointIndex = noOfPoints / 2;
                        //midpoint = points.get(midPointIndex);
                        points.get(ct1).DisplayPoint(g);
                    }

                    displayLines(points, g);  //Display original line (RED)
                    //midpoint.setY(100);
                    Point labelPt = new Point("p100" + "," + 150 + "," + 600);
                    createText(g, labelPt, "Original Line");
                    repaint();
                }

                //display simplified line
                if (points2 != null){
                    for(int ct=0; ct< points2.size(); ct++){
                        //int noOfPoints = points.size();
                        //int midPointIndex = noOfPoints / 2;
                        //midpoint = points.get(midPointIndex);
                        points2.get(ct).DisplayPoint(g);
                        /////////////////////////////////////drawCircle(g, points2.get(ct), 100);   //Used of other simplifcation algorithms
                        repaint();
                    }
                    g.setColor(Color.BLUE);
                    displayLines3(points2, g); //Display simplified line (BLUE)
                    // midpoint.setY(50);
                    //////////////////////////////////////////createText(g, midpoint, "Simplified Line");  //COMMENTED OUT DBULLOCK 08/04/2016

                    //Display all lines  //Added D Bullock
                    // int j = 0;
                    // for(int i = 0; i < points.size() - 1; i++){
                        //     j = i + 1;
                        //     Point p1 = points.get(i);
                        //     Point p2 = points.get(j);
                        //     Graphics2D g2 = (Graphics2D) g;

                        //g2.drawLine(p1.getX()+20,p1.getY()+10,p2.getX()+20,p2.getY()+10) ;
                        //    g2.drawLine(p1.getX(),500 - p1.getY(),p2.getX(),500 - p2.getY()) ;

                    }

                    if (perpendicularLines != null){
                        //g.setColor(Color.GREEN);
                        displayLines2(g, perpendicularLines); //Display perpendicular lines
                        revalidate();
                        repaint();
                    }

                    if (simplifiedLines != null){
                        //g.setColor(Color.GREEN);
                        displayLines2(g, simplifiedLines); //Display simplified lines
                        revalidate();
                        repaint();
                    }

                    if (perpendicularLinesLargerThanThreshold != null){
                        displayLines4(g, perpendicularLinesLargerThanThreshold); //Display simplified lines
                        revalidate();
                        repaint();
                    }

                    if (effectiveAreaTriangles != null){
                        drawTrianglePolygon(g, effectiveAreaTriangles);
                        revalidate();
                        repaint();

                    }

                    if (circles != null){
                        drawCircles(g, circles);
                        drawCircle(g,circles);
                        revalidate();
                        repaint();
                    }

                    if (areacircles != null){
                        drawAreaCircles(g, areacircles, radialDistance);
                        revalidate();
                        repaint();
                    }

                    if (smallestEffectiveAreaTriangles != null){
                        drawTrianglePolygon2(g, smallestEffectiveAreaTriangles);
                        revalidate();
                        repaint();
                    }

                    if (sleeve != null){
                        //displayLines2(g, sleeve); //Display input lines
                        //    //drawTrianglePolygon2(g, sleeve);
                        //    //drawPolygon(g, sleeve, 4, 4);
                        displayLines4(g, sleeve);
                        repaint();
                    }

                    //if (sleevePolygons != null){
                        //    //displayLines2(g, sleeve); //Display input lines
                        //    //drawTrianglePolygon2(g, sleeve);
                        //    //drawPolygon(g, sleevePolygons, 4, 4);
                        //    drawPolygon2(g, sleevePolygons);
                        //    //displayLines4(g, sleeve); COMMENTED OU 15/06/2016
                        //    repaint();
                        //}

                    if (simplifiedLine != null){
                        g.setColor(Color.BLUE);
                        displayLines3(simplifiedLine, g);
                    }

                }

            };
            jPanel2 = new javax.swing.JPanel();
            lblPerpendicularDistance = new javax.swing.JLabel();
            lblSimplificationAlgorithm = new javax.swing.JLabel();
            lblNthPoint = new javax.swing.JLabel();
            lblRadialDistance = new javax.swing.JLabel();
            txtPerpendicularDistance = new javax.swing.JTextField();
            CboSimplificationAlgorithm = new javax.swing.JComboBox();
            txtNthPoint = new javax.swing.JTextField();
            txtRadialDistance = new javax.swing.JTextField();
            lblWidth = new javax.swing.JLabel();
            lblHeight = new javax.swing.JLabel();
            loadCSVButton = new javax.swing.JButton();
            loadSaveCSVFileButton = new javax.swing.JButton();
            loadSimplifyButton = new javax.swing.JButton();
            txtWidth = new javax.swing.JTextField();
            txtHeight = new javax.swing.JTextField();
            lblPercentageDecrease = new javax.swing.JLabel();
            lblNoOfOriginalLinePts = new javax.swing.JLabel();
            lblNoOfSimplifiedLinePts = new javax.swing.JLabel();
            loadStepButton = new javax.swing.JButton();
            loadResetButton = new javax.swing.JButton();
            loadExitButton = new javax.swing.JButton();
            lblNoOfPoints = new javax.swing.JLabel();
            txtNoOfPoints = new javax.swing.JTextField();
            lblNoOfOriginalLinePtsValue = new javax.swing.JLabel();
            lblNoOfSimplifiedLinePoints = new javax.swing.JLabel();
            lblPercentageDecreaseValue = new javax.swing.JLabel();
            lblVectorDisplacement = new javax.swing.JLabel();
            lblVectorDisplacementValue = new javax.swing.JLabel();
            jLabel18 = new javax.swing.JLabel();
            lblAreaDisplacementValue = new javax.swing.JLabel();
            jScrollPane1 = new javax.swing.JScrollPane();
            jTextAreaCommentary = new javax.swing.JTextArea();
            chkOriginalLineButton = new javax.swing.JCheckBox();
            chkSimplifiedLineButton = new javax.swing.JCheckBox();
            loadSaveADrawnLineToCSVFileButton = new javax.swing.JButton();
            loadDrawALineButton = new javax.swing.JButton();
            lblRatioAngularityChange = new javax.swing.JLabel();
            lblRatioAngularityChangeValue = new javax.swing.JLabel();
            jToggleButtonLoadVectorDisplacementError = new javax.swing.JToggleButton();
            jToggleButtonLoadAreaDisplacementError = new javax.swing.JToggleButton();
            lblAreaDistortion = new javax.swing.JLabel();
            lblAreaDistortionValue = new javax.swing.JLabel();

            org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 100, Short.MAX_VALUE)
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 100, Short.MAX_VALUE)
            );

            setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
            setTitle("Line Simplification Learning Tool");
            setUndecorated(true);

            jPanel1.setBackground(new java.awt.Color(255, 255, 255));
            jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
            jPanel1.setDoubleBuffered(false);

            org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 805, Short.MAX_VALUE)
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 579, Short.MAX_VALUE)
            );

            jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
            jPanel2.setDoubleBuffered(false);
            jPanel2.setEnabled(false);

            lblPerpendicularDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPerpendicularDistance.setText("       Perpendicular distance:");
            lblPerpendicularDistance.setEnabled(false);

            lblSimplificationAlgorithm.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblSimplificationAlgorithm.setText(" Algorithm:");
            lblSimplificationAlgorithm.setEnabled(false);

            lblNthPoint.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNthPoint.setText("Nth point:");
            lblNthPoint.setEnabled(false);

            lblRadialDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRadialDistance.setText("       Radial distance:");
            lblRadialDistance.setToolTipText("");
            lblRadialDistance.setEnabled(false);

            txtPerpendicularDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtPerpendicularDistance.setText("0.00");
            txtPerpendicularDistance.setToolTipText("");
            txtPerpendicularDistance.setEnabled(false);

            CboSimplificationAlgorithm.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            CboSimplificationAlgorithm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Nth point", "Routine of radial distance", "Routine of perpendicular distance", "Reumann-Witkam", "Lang", "Douglas Peucker", "Visvalingam Whyatt", " " }));
            CboSimplificationAlgorithm.setEnabled(false);
            CboSimplificationAlgorithm.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    CboSimplificationAlgorithmActionPerformed(evt);
                }
            });

            txtNthPoint.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtNthPoint.setText("0");
            txtNthPoint.setAutoscrolls(false);
            txtNthPoint.setEnabled(false);

            txtRadialDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtRadialDistance.setText("0.00");
            txtRadialDistance.setEnabled(false);

            lblWidth.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblWidth.setText("       Width:");
            lblWidth.setEnabled(false);

            lblHeight.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblHeight.setText("       Height:");
            lblHeight.setEnabled(false);

            loadCSVButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadCSVButton.setText("Load Line from CSV");
            loadCSVButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadCSVButtonActionPerformed(evt);
                }
            });

            loadSaveCSVFileButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSaveCSVFileButton.setText("Save Simplified Line to CSV");
            loadSaveCSVFileButton.setEnabled(false);
            loadSaveCSVFileButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSaveCSVFileButtonActionPerformed(evt);
                }
            });

            loadSimplifyButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSimplifyButton.setText("Simplify");
            loadSimplifyButton.setEnabled(false);
            loadSimplifyButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSimplifyButtonActionPerformed(evt);
                }
            });

            txtWidth.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtWidth.setText("0.00");
            txtWidth.setEnabled(false);
            txtWidth.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    txtWidthActionPerformed(evt);
                }
            });

            txtHeight.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtHeight.setText("0.00");
            txtHeight.setEnabled(false);

            lblPercentageDecrease.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPercentageDecrease.setText("% decrease:");

            lblNoOfOriginalLinePts.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfOriginalLinePts.setText("Original line pts:");

            lblNoOfSimplifiedLinePts.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfSimplifiedLinePts.setText("Simplified line pts:");

            loadStepButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadStepButton.setText("Step");
            loadStepButton.setEnabled(false);
            loadStepButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadStepButtonActionPerformed(evt);
                }
            });

            loadResetButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadResetButton.setText("Reset");
            loadResetButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadResetButtonActionPerformed(evt);
                }
            });

            loadExitButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadExitButton.setText("Exit");
            loadExitButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadExitButtonActionPerformed(evt);
                }
            });

            lblNoOfPoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfPoints.setText("No of points:");
            lblNoOfPoints.setEnabled(false);

            txtNoOfPoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtNoOfPoints.setText("0");
            txtNoOfPoints.setEnabled(false);

            lblNoOfOriginalLinePtsValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfOriginalLinePtsValue.setText("0");

            lblNoOfSimplifiedLinePoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfSimplifiedLinePoints.setText("0");
            lblNoOfSimplifiedLinePoints.setToolTipText("");

            lblPercentageDecreaseValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPercentageDecreaseValue.setText("0.00");

            lblVectorDisplacement.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblVectorDisplacement.setText("Vector displacement:");
            lblVectorDisplacement.setToolTipText("");

            lblVectorDisplacementValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblVectorDisplacementValue.setText("0.00");
            lblVectorDisplacementValue.setToolTipText("");

            jLabel18.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            jLabel18.setText("Uniform dist distortion:");

            lblAreaDisplacementValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblAreaDisplacementValue.setText("0.00");
            lblAreaDisplacementValue.setToolTipText("");

            jTextAreaCommentary.setBackground(new java.awt.Color(204, 204, 204));
            jTextAreaCommentary.setColumns(20);
            jTextAreaCommentary.setLineWrap(true);
            jTextAreaCommentary.setRows(5);
            jTextAreaCommentary.setText("Information about selected algorithm to\ngo here....\nProcessing steps to go here....");
            jScrollPane1.setViewportView(jTextAreaCommentary);

            chkOriginalLineButton.setText("Original line");
            chkOriginalLineButton.setToolTipText("");
            chkOriginalLineButton.setEnabled(false);
            chkOriginalLineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    chkOriginalLineButtonActionPerformed(evt);
                }
            });

            chkSimplifiedLineButton.setText("Simplified line");
            chkSimplifiedLineButton.setToolTipText("");
            chkSimplifiedLineButton.setEnabled(false);
            chkSimplifiedLineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    chkSimplifiedLineButtonActionPerformed(evt);
                }
            });

            loadSaveADrawnLineToCSVFileButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSaveADrawnLineToCSVFileButton.setText("Save Line");
            loadSaveADrawnLineToCSVFileButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSaveADrawnLineToCSVFileButtonActionPerformed(evt);
                }
            });

            loadDrawALineButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadDrawALineButton.setText("Draw Line");
            loadDrawALineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadDrawALineButtonActionPerformed(evt);
                }
            });

            lblRatioAngularityChange.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRatioAngularityChange.setText("Ratio Angular Change");

            lblRatioAngularityChangeValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRatioAngularityChangeValue.setText("0.00");
            lblRatioAngularityChangeValue.setToolTipText("");

            jToggleButtonLoadVectorDisplacementError.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            jToggleButtonLoadVectorDisplacementError.setText("Vector Error");
            jToggleButtonLoadVectorDisplacementError.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jToggleButtonLoadVectorDisplacementErrorActionPerformed(evt);
                }
            });

            jToggleButtonLoadAreaDisplacementError.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            jToggleButtonLoadAreaDisplacementError.setText("Area Error");
            jToggleButtonLoadAreaDisplacementError.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jToggleButtonLoadAreaDisplacementErrorActionPerformed(evt);
                }
            });

            lblAreaDistortion.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblAreaDistortion.setText("Area displacement:");

            lblAreaDistortionValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblAreaDistortionValue.setText("0.00");

            org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel2Layout.createSequentialGroup()
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 349, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(15, 15, 15)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(lblSimplificationAlgorithm)
                                            .add(18, 18, 18)
                                            .add(CboSimplificationAlgorithm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                                .add(jPanel2Layout.createSequentialGroup()
                                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                                        .add(lblNthPoint)
                                                        .add(lblPerpendicularDistance)
                                                        .add(lblRadialDistance)
                                                        .add(lblWidth)
                                                        .add(lblHeight))
                                                    .add(18, 18, 18)
                                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtHeight, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtPerpendicularDistance)
                                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtRadialDistance)
                                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtWidth)
                                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtNthPoint)))
                                                .add(jPanel2Layout.createSequentialGroup()
                                                    .add(lblNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 73, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                    .add(18, 18, 18)
                                                    .add(txtNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                                .add(loadSimplifyButton)
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2Layout.createSequentialGroup()
                                                    .add(43, 43, 43)
                                                    .add(chkOriginalLineButton)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                                    .add(chkSimplifiedLineButton)))
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadCSVButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadSaveADrawnLineToCSVFileButton, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadDrawALineButton, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                                                .add(loadSaveCSVFileButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))))))
                            .add(0, 0, Short.MAX_VALUE))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(20, 20, 20)
                                    .add(loadStepButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(loadResetButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(jToggleButtonLoadAreaDisplacementError, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 159, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(jToggleButtonLoadVectorDisplacementError, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 159, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(loadExitButton))))
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(24, 24, 24)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                            .add(lblPercentageDecrease)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                            .add(lblPercentageDecreaseValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                                .add(jPanel2Layout.createSequentialGroup()
                                                    .add(14, 14, 14)
                                                    .add(lblNoOfOriginalLinePts))
                                                .add(lblNoOfSimplifiedLinePts))
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                                .add(lblNoOfOriginalLinePtsValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                .add(lblNoOfSimplifiedLinePoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(lblRatioAngularityChange)
                                            .add(14, 14, 14)
                                            .add(lblRatioAngularityChangeValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .add(0, 22, Short.MAX_VALUE))
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(jLabel18)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(lblAreaDisplacementValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2Layout.createSequentialGroup()
                                            .add(16, 16, 16)
                                            .add(lblAreaDistortion)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                            .add(lblAreaDistortionValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .add(18, 18, 18))))
                                .add(jPanel2Layout.createSequentialGroup()
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(lblVectorDisplacement)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(lblVectorDisplacementValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                    .addContainerGap())
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel2Layout.createSequentialGroup()
                    .add(15, 15, 15)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lblSimplificationAlgorithm)
                        .add(CboSimplificationAlgorithm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(txtNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lblNoOfPoints))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(txtNthPoint, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lblNthPoint))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(txtPerpendicularDistance, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(lblPerpendicularDistance))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblRadialDistance)
                                .add(txtRadialDistance, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(loadDrawALineButton)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(loadSaveADrawnLineToCSVFileButton)))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(txtWidth, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(loadCSVButton, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .add(lblWidth))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lblHeight)
                        .add(txtHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(loadSaveCSVFileButton))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(loadSimplifyButton)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(chkOriginalLineButton)
                        .add(chkSimplifiedLineButton))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 181, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(8, 8, 8)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(loadStepButton)
                                .add(loadResetButton))
                            .add(5, 5, 5)
                            .add(jToggleButtonLoadVectorDisplacementError, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(jToggleButtonLoadAreaDisplacementError)
                                .add(lblVectorDisplacement)
                                .add(lblVectorDisplacementValue)))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblNoOfOriginalLinePts)
                                .add(lblNoOfOriginalLinePtsValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblNoOfSimplifiedLinePts)
                                .add(lblNoOfSimplifiedLinePoints))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblPercentageDecrease)
                                .add(lblPercentageDecreaseValue))))
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(18, 18, 18)
                            .add(loadExitButton))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(4, 4, 4)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblAreaDistortion)
                                .add(lblAreaDistortionValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(jLabel18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(lblAreaDisplacementValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(lblRatioAngularityChangeValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(lblRatioAngularityChange))))
                    .addContainerGap(38, Short.MAX_VALUE))
            );

            loadStepButton.getAccessibleContext().setAccessibleName("loadStepButton");

            org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(44, 44, 44)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .add(47, 47, 47)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .add(layout.createSequentialGroup()
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap())
            );

            jPanel1.getAccessibleContext().setAccessibleName("");
            jPanel1.getAccessibleContext().setAccessibleDescription("");
            jPanel2.getAccessibleContext().setAccessibleName("Line Simplication");

            pack();
        }// </editor-fold>//GEN-END:initComponents

    private void loadSimplifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSimplifyButtonActionPerformed
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        lp = new LinePerformance();
         
        switch (selectedText) {
            case "Routine of radial distance":
                txtRadialDistance.setVisible(true);
                try{
                    if(validateRadialDistanceInput() == false){
                   
                    }
                    else{
                        removeMouseListener(mouseListener);
                        int n = Integer.parseInt(txtRadialDistance.getText());          
                        ls = new LineSimplification();
                        //setPoints2(ls.routineOfDistanceBetweenPoints(getPoints(),n)); //Simplified line
                        setPoints2(new ArrayList<>(getPoints()));
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());                    
                        lblPercentageDecreaseValue.setText("" + 
                        lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                getPoints2()));
                        lblRatioAngularityChangeValue.setText("" +
                                lp.ratioInChangeOfAngularity(getPoints(),
                                        getPoints2()));  
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        chkOriginalLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setEnabled(true);
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                        setCount(0);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Nth point":
                txtNthPoint.setVisible(true);
                try{
                    if(validateNthPointInput() == false){
                    }
                    else{
                    removeMouseListener(mouseListener);
                    //int n = Integer.parseInt(txtNthPoint.getText()); 
                    ls = new LineSimplification();
                    //setPoints2(ls.nthPoint(getPoints(),n));                                 
                    setPoints2(new ArrayList<>(getPoints())); 
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + 
                            lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                    getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + 
                            lp.ratioInChangeOfAngularity(getPoints(),
                                    getPoints2()));
                    loadStepButton.setEnabled(true);
                    jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                    jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                    loadSaveCSVFileButton.setEnabled(true);
                    setCount(0); 
                    setI(0);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Routine of perpendicular distance":
                txtPerpendicularDistance.setVisible(true);
                try{
                    if(validatePerpendicularDistanceInput("Routine of Perpendicular "
                            + "Distance") == false){
                    }
                    else{
                        removeMouseListener(mouseListener);
                        int n = Integer.parseInt(txtPerpendicularDistance.getText());  
                        ls = new LineSimplification();
                        //setPoints2(ls.perpendicularDistanceRoutine(getPoints(),n)); // 04/06/2016
                        setPoints2(new ArrayList<>(getPoints()));
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" +
                                lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(), 
                                        getPoints2()));
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                        setCount(0);
                        setI(0);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Reumann-Witkam":
                txtHeight.setVisible(true);
                txtWidth.setVisible(true);
                 try{
                     if(validateHeightInput() == false || 
                             validateWidthInput() == false){
                     }
                     else{
                        removeMouseListener(mouseListener);
                        int height = Integer.parseInt(txtHeight.getText());
                        int width = Integer.parseInt(txtWidth.getText());
                        ls = new LineSimplification();
                        //setPoints2(ls.reumannWitkam(points, height, width));
                        setPoints2(new ArrayList<>(getPoints())); 
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" + 
                                lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(),
                                        getPoints2()));
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                     }
                 //}
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
               break;
            case "Lang":
                txtNoOfPoints.setVisible(true);
                txtPerpendicularDistance.setVisible(true);
                try{
                    if(validatePerpendicularDistanceInput("Lang") == false){
                        removeMouseListener(mouseListener);
                    }
                    else{
                        int n = Integer.parseInt(txtPerpendicularDistance.getText()); 
                        ls = new LineSimplification();
                        //setPoints2(ls.lang(getPoints(),n));
                        setPoints2(new ArrayList<>(getPoints()));
                        setPerpendicularLines(ls.getPerpendicularLines());
                        setSimplifiedLines(ls.getSimplifiedLines());
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                        lblPercentageDecreaseValue.setText("" +
                                lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(), 
                                        getPoints2()));
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Douglas Peucker":
                txtPerpendicularDistance.setVisible(true);
                try{ 
                    if(validatePerpendicularDistanceInput(
                            "Ramer Douglas Peucker") == false){
                    }
                    else{
                        removeMouseListener(mouseListener);
                        int rdpInt = Integer.parseInt(
                                txtPerpendicularDistance.getText());
                        ls = new LineSimplification();
                        //setPoints2(ramerDouglasPeucker(getPoints(), rdpInt)); //Without Step counter
                        setPoints2(ls.ramerDouglasPeucker(getPoints(), rdpInt)); //Without Step counter
                        setLiners(null);
                        //setPoints2(new ArrayList<>(getPoints())); //NOTE: Use This and Comment out the Without
                        //Step Counter lines above if you want to use/see ramerDouglasPeuckerUsingCounter method
                        
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" +
                                getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" +
                                getPoints2().size());
                        lblPercentageDecreaseValue.setText("" +
                                lp.percentageChangeInNumberOfCoordinates(getPoints(),
                                        getPoints2()));
                        lblRatioAngularityChangeValue.setText("" + 
                                lp.ratioInChangeOfAngularity(getPoints(),
                                        getPoints2()));
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                        setCount(0);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Visvalingam Whyatt":
                txtNoOfPoints.setVisible(true);
                try{
                    if(validateNoOfPointsInput() == false){
                    }
                    else{ 
                    
                        removeMouseListener(mouseListener);
                        int vwInt = Integer.parseInt(txtNoOfPoints.getText());
                        ls = new LineSimplification();
                 //setPoints2(ls.visvalingamWhyattSimplified(getPoints(),vwInt));
                        setPoints2(new ArrayList<>(getPoints()));
                        chkSimplifiedLineButton.setEnabled(true);
                        chkSimplifiedLineButton.setSelected(true);
                        lblNoOfOriginalLinePtsValue.setText("" + 
                                getPoints().size());
                        lblNoOfSimplifiedLinePoints.setText("" +
                                getPoints2().size());
                        lblPercentageDecreaseValue.setText("" +
                                lp.percentageChangeInNumberOfCoordinates(
                                        getPoints(),getPoints2()));
                        lp.ratioInChangeOfAngularity(getPoints(), getPoints2());
                        loadStepButton.setEnabled(true);
                        jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                        jToggleButtonLoadAreaDisplacementError.setEnabled(true);
                        loadSaveCSVFileButton.setEnabled(true);
                        setCount(0);
                        setI(0);
                    }
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            default:
                break;
        }
        
        System.out.println(selectedText);
        
    }//GEN-LAST:event_loadSimplifyButtonActionPerformed

    private void loadExitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadExitButtonActionPerformed
         try{ 
                removeMouseListener(mouseListener);
                int result = JOptionPane.showConfirmDialog(null, "Are you sure you "
                        + "would like to exit? You will lose any unsaved changes!",
                        "Exit", JOptionPane.CANCEL_OPTION);
                
                if(result == 0){
                    System.exit(0);
                }
               
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadExitButtonActionPerformed

    private void loadSaveCSVFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSaveCSVFileButtonActionPerformed
         try{
                //Return file object of selected file from fileChooser dialog 
                removeMouseListener(mouseListener);
                File file = fw.saveSimplifiedLineToCSVFile();  
                String fileExtension = fw.getFileExtension(file);

                 if(file.exists() && !file.isDirectory()) { 
                    File oldFile = new File(file.toString());
                    oldFile.delete();
                    File newFile = new File(file.toString());                
                }   
                
                //DEBUG - Checking file extension is .csv or .CSV 
                System.out.println("File extension of selected file is: " + 
                        fileExtension);

                if (fileExtension.equals(".csv") || fileExtension.equals(".CSV")){                       
                    try{ 
                        removeMouseListener(mouseListener);
                        if (getPoints2() != null){
                            //Get line and write line to file
                            for (int j = 0; j < getPoints2().size(); j++){
                                String ID = getPoints2().get(j).getID();
                                int x = getPoints2().get(j).getX();
                                int y = getPoints2().get(j).getY();
                                String strLine = ID + "," + x + "," + y;
                                fw.appendWrite(file, strLine);
                            }
                            chkSimplifiedLineButton.setEnabled(true);
                            chkSimplifiedLineButton.setSelected(true);
                        }
                        else{
                            System.out.println("There is no simplified line to "
                                   + "save!. Create simplified line and try to "
                                   + "save again!");
                        }
                    }
                    catch (Exception e){
                        System.out.println("File not found"); 
                    }
                }
                else{
                    System.out.println("File is not a csv file with file extension"
                            + " .csv or .CSV. Please try loading a CSV again!");
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadSaveCSVFileButtonActionPerformed

    private void loadCSVButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadCSVButtonActionPerformed

         try{
                //Return file object of selected file from fileChooser dialog 
                removeMouseListener(mouseListener);
                File file = fw.loadCSVFile();  
                String fileExtension = fw.getFileExtension(file);

                //DEBUG - Checking file extension is .csv or .CSV 
                System.out.println("File extension of selected file is: " + 
                        fileExtension);

                if (fileExtension.equals(".csv") || fileExtension.equals(".CSV")){
                    String firstLineInCSVFile = fw.ReturnFirstLineOfFile(file); 
                    //points = Point.LoadPoints(file);                                   
                    setPoints(Point.loadOriginalPts(file)); 
                    repaint();
                    chkOriginalLineButton.setEnabled(true);
                    chkOriginalLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblPercentageDecreaseValue.setText("0");
                    lblRatioAngularityChangeValue.setText("0");
                    lblSimplificationAlgorithm.setEnabled(true);
                    CboSimplificationAlgorithm.setEnabled(true);
                    loadSimplifyButton.setEnabled(true);
                    loadDrawALineButton.setEnabled(false);
                    loadSaveADrawnLineToCSVFileButton.setEnabled(false);
                    loadCSVButton.setEnabled(false);
                    loadSaveCSVFileButton.setEnabled(false);
                    jTextAreaCommentary.setText("");
                    writeStartUpTextToTextAreaCommentary();
                }
                else{
                    System.out.println("File is not a csv file with file extension "
                            + ".csv or .CSV. Please try loading a CSV again!");
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }        
    }//GEN-LAST:event_loadCSVButtonActionPerformed

    private void loadStepButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadStepButtonActionPerformed
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        
        switch (selectedText) {
            case "Routine of radial distance":
                try{                    
                  routineOfRadialDistanceUsingCounter(ls, getCount());
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Nth point":
                try{    
                    nthPointUsingCounter(ls, getCount());
                }               
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Routine of perpendicular distance":
                try{
                    routineOfPerpendicularDistanceUsingCounter(ls, getCount());
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Reumann-Witkam":
                try{                    
                    reumannWitkamUsingCounter(ls,getCount());                   
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Lang":
                txtPerpendicularDistance.setVisible(true);
                try{
                    int p = Integer.parseInt(txtPerpendicularDistance.getText());
                    //setPoints2(ls.lang(getPoints(),p));
                    langUsingCounter(ls,getCount());
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Douglas Peucker":
                try{
                    int perpendicularDistanceTolerance =
                            Integer.parseInt(txtPerpendicularDistance.getText());
                    //setPoints2(ramerDouglasPeuckerUsingCounter(getPoints(),
                    //        perpendicularDistanceTolerance, getCount()));
                    setPoints2(ls.ramerDouglasPeucker(getPoints(),
                            perpendicularDistanceTolerance));
                    //setPoints2(rdp(getPoints(),
                    //        perpendicularDistanceTolerance, getCount()));
                    
                    repaint();
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Visvalingam Whyatt":
                try{
                    visvalingamWhyattUsingCounter(ls,getCount());
                }     
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            default:
                break;
        }
                
    }//GEN-LAST:event_loadStepButtonActionPerformed

    /**
     * Reset Text Boxes and Value Labels
     * 
     */
 
    private void resetTextBoxesAndValueLabels(){
        txtHeight.setText("0.00");
        txtNoOfPoints.setText("0");
        txtNthPoint.setText("0");
        txtPerpendicularDistance.setText("0.00");
        txtRadialDistance.setText("0.00");
        txtWidth.setText("0.00");
        lblAreaDistortionValue.setText("0");
        lblNoOfSimplifiedLinePoints.setText("0");
        lblPercentageDecreaseValue.setText("0");
        lblVectorDisplacementValue.setText("0");
        lblAreaDisplacementValue.setText("0");
        lblRatioAngularityChangeValue.setText("0");
    }
    
    private void CboSimplificationAlgorithmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CboSimplificationAlgorithmActionPerformed
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        String newLine = "\n";
        switch (selectedText) {
            case "Routine of radial distance":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                resetTextBoxesAndValueLabels();
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(true);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(true);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Radial Distance" + newLine);
                writeToTextAreaCommentary("-------------------------------------" +
                        newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("An euclidean distance is formed "
                        + "between a pair " +
                "of points" + newLine);      
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("If the distance is smaller than the min"
                        + " radial distance " +
                "tolerance then the point is rejected otherwise " +
                "it is retained for the simplified line "  + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. " 
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Distance Between Points " +
                        "(Radial Distance) is often " 
                  + " used to rapidly reduce density of points in a line, to speed " 
                  + "up the processing of other line simplification algorithms such "
                  + "as Douglas Peucker. " + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Distance between Points and "
                  + "the Nth Point algorithms are also the worst at preserving "
                  + "angularity in the line as they do not select points based "
                  + "on line topology characteristics (McMaster 1987) " + newLine);
                writeToTextAreaCommentary("Enter a Radial Distance tolerance and press"
                        + " Simplify button. " +  
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            case "Nth point":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(true);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(true);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Nth Point" + newLine);
                writeToTextAreaCommentary("-------------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Every nth point from the original line (red)"
                        + " is output in the simplified line (blue) " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. "
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Nth Point algorithm is one of the worst "
                      + "for preserving cartographic quality. It can be used to " 
                      + "rapidly reduce points in the simplified line which is " 
                      + "useful for model generalization purposes " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Nth Point along with Routine of Distance "
                     + "between Points algorithms are also the worst at preserving "
                     + "angularity in the line as they do not select points based "
                     + "on line topology characteristics (McMaster 1987)"
                     + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Nth Point algorithm has some of the "
                     + "largest area displacement at all simplification levels. "
                     + "The best algorithms have small area displacement. " 
                     + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Enter a Nth Point tolerance and press "
                        + "Simplify button. " +  
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            case "Routine of perpendicular distance":
                setLiners(null);
                setSleeve(null);
                setSimplifiedLine(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Perpendicular Distance" + 
                        newLine);
                writeToTextAreaCommentary("---------------------------------" +
                    "--------------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("A perpendicular distance is calculated "
                        + "from a temporary line " +
                "formed from the two neighbouring points to an intermediate point "
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Intermediate points(s) with perpendicular"
                        + " distances " + 
                "to the temporary line smaller than a minimum perpendicular " + 
                "distance tolerance are removed " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. " + 
                        newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Perpendicular distance " 
                    + "routine is one of the best at preserving angularity in the "
                    + "line as it uses the lines topology characteristics to select "
                    + "points (McMaster 1987). " + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Routine of Perpendicular distance "
                       + "routine has some of the largest area displacement at "
                + "all simplification levels. The best algorithms have small area "
                + "displacement. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Enter a Perpendicular Distance tolerance"
                        + " and press Simplify button " +  
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            case "Reumann-Witkam":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setSleevesList(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(true);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(true);
                lblHeight.setEnabled(true);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(true);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Ruemann-Witkamm" + newLine);
                writeToTextAreaCommentary("----------------------------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. "
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Line complexity, density of points and "
                        + "the starting point " +
                "for searching a section of the line are criteria that govern " +
                "the search extent. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("A rectangular strip is used to create a "
                        + "search area that is used " + 
                " to divide a line into sections. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed sequentially " 
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The first line segment slope is used to "
                        + "define the direction of " +  
                "the strip as it moves along the line. The strip stops moving when " +
                "it intersects another  segment that is not the same as the initial " +
                "line segment (tangent) " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The first and last points in each "
                        + "rectangular strip is kept and make " + 
                "up a section of the simplified line, and all the intermediate "
                        + "points " +
                "in between are removed. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The last point in the strip is the starting " +
                "point for where the strip is moved to next." + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The slope of the line segment with the "
                        + "new start point is used " + 
                "to create the new strip. This process repeats until the final "
                        + "strip " + 
                "contains the last point." + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Enter Height and Width tolerances and "
                        + "press Simplify button. " +  
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons();
                break;
            case "Lang":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(true);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(true);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Lang" + newLine);
                writeToTextAreaCommentary("-------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. " 
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Uses a distance tolerance as a "
                        + "constraint and a fixed number of " + 
                "consecutive points user specified tolerance " +  
                "representing the search area size." + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("An initial simplified line (blue "
                        + " dotted"
                        + " line) is drawn between start and end points of the "
                        + "search " +  
                "area. The simplified line is used to calculate a perpendicular "
                        + "distance (blue dotted line) " + 
                "for each intermediate point in the search area to the simplified "
                        + "line " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Intermediate point(s) are removed from "
                        + "the original line segment within " +
                "the search area if its associated perpendicular distance is "
                        + "smaller " + 
                "than the distance tolerance (green line). " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The start point in the next search area"
                        + " is the last point in the " +  
                "previous search area." + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("If a calculated perpendicular "
                        + "distance(s)"
                        + " in the search region is " + 
                "larger than the tolerance (green line) the last point in the"
                        + " search area " + 
                "is excluded from processing i.e. size is reduced by 1. " + 
                        newLine);   
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The search area moves along the line "
                        + "following the same steps above " + 
                "until there are no intermediate points or when all distances "
                        + "left are " + 
                "smaller than the specified distance tolerance. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("After all intermediate points have "
                        + "been"
                        + " removed a new search area " + 
                "is created beginning at the previous search regions last point. " 
                        + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Lang algorithm like Visvalingam Whyatt "
                 + "algorithm is nearly as good as Douglas Peucker for preserving "
                 + "cartographic quality. It is often used where more efficient "
                 + "processing is required and results similar in " +
                   "Cartographic quality to Douglas Peucker is the requirement " +
                    newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Lang is fairly good at preserving " +
                  "angularity in the line as it select points based on line " +
                  "topology characteristics. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Lang has some of the smallest area " 
                 + "displacement comparable to Douglas Peucker and even better at "
                 + "times at some of the simplification levels. The worst"
                 + "algorithms have large area displacement. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Enter a no of points and perpendicular "
                        + "distance tolerances " +
                "then press Simplify button." +
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            case "Douglas Peucker":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Douglas Peucker" + newLine);
                writeToTextAreaCommentary("------------------------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("These routines process the whole "
                        + "original "
                        + "line rather than a" + 
                "piece at a time like the previous categories." + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Douglas Peucker routine is widely "
                        + "used in "
                        + "cartography, " + 
                "and is the most accurate algorithm in terms of retaining line " + 
                "character." + newLine);  
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("An initial simplified line is created "
                        + "between the original line " +
                "start and end points." + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Perpendicular distances from each "
                        + "original "
                        + "point (excluding start " + 
                "and end points) to the simplified line are created." + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The point with a perpendicular "
                        + "distance "
                        + "larger than the maximum " +  
                "perpendicular distance is used to partition the point data " +
                "into two subsets. The simplified line is drawn between the "
                        + "start " +
                "and end point for each subset. " + newLine); 
                writeToTextAreaCommentary("A perpendicular distance is created "
                        + "for "
                        + "each point in the subset " +  
                "(except first and last points), and points with distances "
                        + "smaller " + 
                "than the tolerance are removed. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Douglas Peucker is the algorithm of " +
                " choice for cartographic purposes such as in Map Generalization. " 
                + "It is the best algorithm for preserving cartographic quality "
                + "and is widely used in Geographic Information Systems(GIS) "
                + "and mapping software. It is also known as Split and Merge "
                + "algorithm and is used in Robotics application. " 
                + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Douglas Peucker is also the best " +
                "algorithm for having the least area and vector displacement " +
                "(positional error) at the majority of simplification levels." +
                "(McMaster 1987). The best algorithms have small displacement."
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Enter a perpendicular distance "
                        + "tolerance "
                        + "and press Simplify button." +
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            case "Visvalingam Whyatt":
                setLiners(null);
                setSimplifiedLine(null);
                setSleeve(null);
                setPoints2(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                resetTextBoxesAndValueLabels();
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(true);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(true);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Visvalingham Whyatt" + newLine);    
                writeToTextAreaCommentary("----------------------------" + 
                        newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Triangle areas are formed for each "
                        + "intermediate point " + 
                "(excluding start and end points) in the original line (red) " +
                "and the previous point and the next point. " +
                "This is done sequentially through the line " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The intermediate point in the original "
                        + "line with the " +   
                "minimum triangle area is removed. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The above is 1 round in processing of "
                        + "the line " + newLine); 
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The above steps are repeated on the "
                        + "remaining intermediate " + 
                    "points until the no of points required to remain in the " +
                    "simplified line (blue) specified by the user is reached ");
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("The line is processed point by point. "
                        + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Visvalingam Whyatt is fairly good at " 
                 + "preserving angularity in the line as it select points based "
                 + "on line topology characteristics." + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Visvalingam Whyatt routine has some "
                 + "of the smallest area displacement at all simplification levels. "
                 + "The worst algorithms have large area displacement. The "
                 + "best algorithms have small displacement. " + newLine);
                writeToTextAreaCommentary(newLine);            
                writeToTextAreaCommentary("Enter a No Of Points to keep "
                        + "tolerance "
                        + "and press Simplify button. " +  
                "Use Step button to step through processing. " + newLine);
                setCount(0);
                resetErrorButtons(); 
                break;
            default:
                break;
        }
        System.out.println(selectedText);
    }//GEN-LAST:event_CboSimplificationAlgorithmActionPerformed

    private void loadResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadResetButtonActionPerformed
         try{ 
                
                removeMouseListener(mouseListener);
                setSleeve(null);
                setSimplifiedLine(null);
                setPoints(null);     // Original line
                setPoints2(null);    // Simplified Line
                setPoints3(null);
                setLiners(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                chkOriginalLineButton.setEnabled(false);
                chkOriginalLineButton.setSelected(false);
                chkSimplifiedLineButton.setEnabled(false);
                chkSimplifiedLineButton.setSelected(false);
                txtNoOfPoints.setText("0");
                txtNthPoint.setText("0");
                txtPerpendicularDistance.setText("0.00");
                txtRadialDistance.setText("0.00");
                txtWidth.setText("0");
                txtHeight.setText("0");
                lblNoOfOriginalLinePtsValue.setText("0");
                lblNoOfSimplifiedLinePoints.setText("0");
                lblPercentageDecreaseValue.setText("0.00");
                lblVectorDisplacementValue.setText("0.00");
                lblAreaDisplacementValue.setText("0.00");
                lblRatioAngularityChangeValue.setText("0.00");
                lblAreaDistortionValue.setText("0");                
                lblSimplificationAlgorithm.setEnabled(false); 
                CboSimplificationAlgorithm.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                txtNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                txtHeight.setEnabled(false);
                loadSimplifyButton.setEnabled(false);
                loadSaveCSVFileButton.setEnabled(false);
                loadStepButton.setEnabled(false);
                resetErrorButtons();  
                jTextAreaCommentary.setText("");
                writeStartUpTextToTextAreaCommentary();
                loadDrawALineButton.setEnabled(true);
                loadSaveADrawnLineToCSVFileButton.setEnabled(true);
                loadCSVButton.setEnabled(true);
                loadSaveCSVFileButton.setEnabled(false);
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadResetButtonActionPerformed

    
    /**
     * Reset Error Buttons 
     * 
     */
    
    public void resetErrorButtons(){
        if (jToggleButtonLoadVectorDisplacementError.isSelected() == true){
            jToggleButtonLoadVectorDisplacementError.setSelected(false);
            jToggleButtonLoadVectorDisplacementError.setEnabled(false);
        }
    
        if (jToggleButtonLoadAreaDisplacementError.isSelected() == true){
            jToggleButtonLoadAreaDisplacementError.setSelected(false);
            jToggleButtonLoadAreaDisplacementError.setEnabled(false);
        }
        
    }
    
    
    private void loadSaveADrawnLineToCSVFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSaveADrawnLineToCSVFileButtonActionPerformed

        if (getPoints() == null){
            JOptionPane.showMessageDialog(null, "There is no line to save. "
                    + "Please draw a line or load an existing line!",
                    "Save Drawn Line As CSV", JOptionPane.ERROR_MESSAGE);
        }
        else{
            try{   
                
                removeMouseListener(mouseListener);
                File file = fw.saveCSVFile();
                
                if(file.exists() && !file.isDirectory()) { 
                    File oldFile = new File(file.toString());
                    oldFile.delete();
                    File newFile = new File(file.toString());      
                    setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }   
                
                //Get original line pts (getPoints()), and write line to file
                for (int j = 0; j < getPoints().size(); j++){
                    String ID = getPoints().get(j).getID();
                    int x = getPoints().get(j).getX();
                    int y = getPoints().get(j).getY();
                    String strLine = ID + "," + x + "," + y;                    
                    fw.appendWrite(file, strLine);
                }

                //Get rid of original line saved to clear the screen after it 
                //was saved to CSV above 
                setPoints(null);
                repaint();
                chkOriginalLineButton.setEnabled(false);
                chkOriginalLineButton.setSelected(false);
                lblNoOfOriginalLinePtsValue.setText("0");
                
                setSleeve(null);
                setSimplifiedLine(null);
                setPoints(null);     // Original line
                setPoints2(null);    // Simplified Line
                setPoints3(null);
                setLiners(null);
                setCircles(null);
                setAreaCircles(null);
                setPerpendicularLines(null);
                setSimplifiedLines(null);
                setPerpendicularLinesLargerThanThreshold(null);
                setEffectiveAreaTriangles(null);
                chkOriginalLineButton.setEnabled(false);
                chkOriginalLineButton.setSelected(false);
                chkSimplifiedLineButton.setEnabled(false);
                chkSimplifiedLineButton.setSelected(false);
                txtNoOfPoints.setText("0");
                txtNthPoint.setText("0");
                txtPerpendicularDistance.setText("0.00");
                txtRadialDistance.setText("0.00");
                txtWidth.setText("0");
                txtHeight.setText("0");
                lblNoOfOriginalLinePtsValue.setText("0");
                lblNoOfSimplifiedLinePoints.setText("0");
                lblPercentageDecreaseValue.setText("0.00");
                lblVectorDisplacementValue.setText("0.00");
                lblAreaDisplacementValue.setText("0.00");
                lblRatioAngularityChangeValue.setText("0.00");
                lblAreaDistortionValue.setText("0");                
                lblSimplificationAlgorithm.setEnabled(false); 
                CboSimplificationAlgorithm.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                txtNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                txtHeight.setEnabled(false);
                loadSimplifyButton.setEnabled(false);
                loadSaveCSVFileButton.setEnabled(false);
                loadStepButton.setEnabled(false);
                resetErrorButtons();  
                jTextAreaCommentary.setText("");
                writeStartUpTextToTextAreaCommentary();
                loadDrawALineButton.setEnabled(true);
                loadSaveADrawnLineToCSVFileButton.setEnabled(true);
                loadCSVButton.setEnabled(true);
                loadSaveCSVFileButton.setEnabled(false);
                
                
                
                
                
            }   
            catch (Exception e){
                System.out.println("File not found"); 
            }
        }
    }//GEN-LAST:event_loadSaveADrawnLineToCSVFileButtonActionPerformed

    /**
     * Is Point in JPanel
     * 
     * @param p - Point to check if inside JPanel
     * @param jpanel - Object representing jPanel
     * @return true or false - If point is inside JPanel true is returned, 
     *                         otherwise false
     */
    public boolean isPointInJPanel(Point p, JPanel jpanel){
        boolean insidePanel = false;
        int x1 = 0;
        int y1 = 0;
        int x2 = jpanel.getWidth();
        int y2 = 0;
        int x3 = jpanel.getWidth();
        int y3 = jpanel.getHeight();
        int x4 = 0;
        int y4 = jpanel.getHeight();
        int px = p.getX();
        int py = p.getY();
        
        if ((px < x2 & px > x1) & (py > y1 & py < y3) & (px < x3 & px > x4) &
                (py > y2 & py < y4)){
            return insidePanel = true;        
        }    
    return insidePanel;    
    }
    
    
    
    private void loadDrawALineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadDrawALineButtonActionPerformed
        try{ 
            addMouseListener(mouseListener = new MouseAdapter(){   
            // Original line
            int count = 0;
            ArrayList<Point> originalLinePts = new ArrayList<>();
               @Override
                public void mousePressed(MouseEvent e){
                    
                    setPoints2(null);    // clear Simplified Line
                    setPoints3(null);    
                    setLiners(null);     // Clear sleeve lines and construction
                    count++;
                    Point p = capturePointClicked(e, count);
                    lblNoOfOriginalLinePtsValue.setText("" + count);
                    
                    //Created jpanel4 as workaround to get bounds of jpanel1
                    //Could not get get access to jpanel1 hence created jpanel4 
                    //same size. Required for isPointInJPanel method
                    JPanel jpanel4 = new JPanel();
                    jpanel4.setSize(807,581);
                    
                    //LineSimplificationFrame frame1 = new LineSimplificationFrame(); 
                    //Only capture points that are inside/within JPanel1
                      if (!isPointInJPanel(p, jpanel4)) {     
                          count--;
                      }
                      else{
                            //Save the point to original line if it is inside 
                            //display panel 
                            originalLinePts.add(p); 
                            setPoints(originalLinePts);
                            repaint(); 
                      }
                    }
                });   
            
                  addMouseMotionListener(new MouseAdapter() {
     
                public void mouseMoved(MouseEvent e) {
                    
                    Point point1 = capturePointClicked(e, count);
                    int x1 = point1.getX();
                    int y1 = point1.getY();
                    
                    JPanel jpanel4 = new JPanel();
                    jpanel4.setSize(807, 581);
                    
                    //Display crosshair cursor it os over the jPanel4
                    final Rectangle cellBounds = jpanel4.getBounds();
                    if (cellBounds != null && cellBounds.contains(x1, y1)) {
                        setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
                    }
                    else {
                      setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                       lblVectorDisplacementValue.setText("" + 000);
                       lblAreaDistortionValue.setText("" + 000); 
                    }
 
                
                    String strX = "" + (jpanel4.getLocation().x + e.getX() - x1);
                    String strY = "" + (jpanel4.getLocation().y + e.getY() - y1);
                    
                    
                    lblVectorDisplacementValue.setText("" + jpanel4.getLocation().x + e.getX());
                    lblAreaDistortionValue.setText("" + jpanel4.getLocation().y + (600 - e.getY()));
                
                }
            });
            
            
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadDrawALineButtonActionPerformed

    private void chkOriginalLineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkOriginalLineButtonActionPerformed

        if(chkOriginalLineButton.isSelected() == true){
            if(getPoints() == null){
                setPoints(getPoints3());
                repaint();
            }
            else{
                setPoints(getPoints());
                repaint();
            }
        }
        
        if(chkOriginalLineButton.isSelected() == false){
            setPoints3(getPoints()); 
            setPoints(null);
            repaint();
        }
    }//GEN-LAST:event_chkOriginalLineButtonActionPerformed

    private void chkSimplifiedLineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSimplifiedLineButtonActionPerformed
       if(chkSimplifiedLineButton.isSelected() == true){
            if(getPoints2() == null){
                setPoints2(getPoints4());
                repaint();
                loadStepButton.setEnabled(true);
                jToggleButtonLoadVectorDisplacementError.setEnabled(true);
                jToggleButtonLoadAreaDisplacementError.setEnabled(true);
            }
            else{
                loadStepButton.setEnabled(false);
                jToggleButtonLoadVectorDisplacementError.setEnabled(false);
                jToggleButtonLoadAreaDisplacementError.setEnabled(false);
                setPoints2(getPoints2());
                repaint();
            }
        }
        
        if(chkSimplifiedLineButton.isSelected() == false){
            setPoints4(getPoints2()); 
            setPoints2(null);
            repaint();
            loadStepButton.setEnabled(false);
            jToggleButtonLoadVectorDisplacementError.setEnabled(false);
            jToggleButtonLoadAreaDisplacementError.setEnabled(false);
        }
    }//GEN-LAST:event_chkSimplifiedLineButtonActionPerformed

    private void txtWidthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtWidthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtWidthActionPerformed

    private void jToggleButtonLoadVectorDisplacementErrorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButtonLoadVectorDisplacementErrorActionPerformed
           String newLine = "\n";
           try{
              LinePerformance lp = new LinePerformance();
              removeMouseListener(mouseListener);
             
              if(jToggleButtonLoadVectorDisplacementError.isSelected() == true){   
                setLiners(lp.vectorDisplacementError(getPoints(), getPoints2()));
                lblVectorDisplacementValue.setText(lp.getStandardizedVectorDisplacement());
                jTextAreaCommentary.setText("");
                writeToTextAreaCommentary("Displacement measures determine "
                        + "positional error between the " +
                "simplified line and the original line." +  newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Vector displacement" + newLine);
                writeToTextAreaCommentary("----------------------------" + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("This is a measure of the perpendicular "
                        + "distance (displacement line) " +  
                "between original line points and perpendicular point of "
                        + "intersection on the simplified line. " + newLine);
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Points perpendicular to the left of a "
                        + "simplified line are negative errors " + 
                "and those to the right are positive errors " + newLine);
                writeToTextAreaCommentary(newLine);        
                writeToTextAreaCommentary("Vector displacement formula (positional"
                        + " accuracy) " + newLine); 
                writeToTextAreaCommentary(newLine);
                
                
               writeToTextAreaCommentary("Sum of vector displacement line lengths "
                        + "differences / simplified line length " + newLine);
               writeToTextAreaCommentary("" + String.format( "%.2f",
                       lp.getSumOfDistortionLineLengths()) + 
                       "  /  "
                       + String.format("%8.2f",
                       lp.getSumOfSimplifiedLineSegments()) + " = " + 
                       lp.getStandardizedVectorDisplacement() + newLine);      
                writeToTextAreaCommentary(newLine);
                writeToTextAreaCommentary("Sum of Simplified Line Segments " +
                        String.format("%8.2f" ,lp.getSumOfSimplifiedLineSegments())
                        + newLine);
                writeToTextAreaCommentary("Maximum Distortion Line Distance " + 
                        String.format("%8.2f" ,lp.getMaxDistortionDistance())
                        + newLine);
                writeToTextAreaCommentary("Mean Distortion Line Distance " + 
                        String.format("%8.2f" ,lp.getMeanDistortionDistance())
                        + newLine);
                writeToTextAreaCommentary("Standard Deviation Distortion Line "
                        + "Distance " + 
                        String.format("%8.2f" ,
                        lp.getStandardDeviationDistortionDistance()) + newLine);
                writeToTextAreaCommentary("No of Distortion Lines " +
                        lp.getNoOfDistortionLines()
                        + newLine);
                writeToTextAreaCommentary("Sum of Distortion Line Distances " +
                        String.format("%8.2f" ,lp.getSumOfDistortionLineLengths())
                        + newLine);
                writeToTextAreaCommentary("Standardized Vector Displacement " 
                  + lp.getStandardizedVectorDisplacement()
                  + newLine);
                jTextAreaCommentary.setEditable(false);
              }
             
              if(jToggleButtonLoadVectorDisplacementError.isSelected() == false){
                setLiners(null);
                lblVectorDisplacementValue.setText("0");
              }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }   
    }//GEN-LAST:event_jToggleButtonLoadVectorDisplacementErrorActionPerformed

    private void jToggleButtonLoadAreaDisplacementErrorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButtonLoadAreaDisplacementErrorActionPerformed
            String newLine = "\n";
            try{
                LinePerformance lp = new LinePerformance();
                removeMouseListener(mouseListener);
                if(jToggleButtonLoadAreaDisplacementError.isSelected() == true){  
                    jTextAreaCommentary.setText("");
                    
                   setEffectiveAreaTriangles(lp.areaDisplacementError(getPoints(), 
                           getPoints2()));
                   lblAreaDistortionValue.setText("" + lp.getAreaDistortion());
                   lblAreaDisplacementValue.setText("" + 
                           lp.getStandardizedAreaDisplacement());
                   
                   writeToTextAreaCommentary(newLine); 
                   writeToTextAreaCommentary("Area displacement" + newLine); 
                   writeToTextAreaCommentary("--------------------------" + newLine);
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("This gives the positional error using"
                           + " polygon area(s) formed " +
                   "between the original line and its simplified version" + newLine);
                   writeToTextAreaCommentary("Positive difference are polygon areas"
                           + " formed to the left of " +  
                   "the simplified line and negative differences on the right " 
                           + newLine);
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("The sum of these differences is the "
                           + "area displacement." + newLine);
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("Area displacement does not rely on "
                           + "sampling like vector displacement " + 
                   " and is considered robust." + newLine);  
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("Uniform distance distortion measure " 
                           + newLine);
                   writeToTextAreaCommentary("--------------------------------"
                           + "-------------------" +
                           newLine);
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("is a standardized measure produced "
                           + "from area displacement " +  
                   "and is considered the best point/area  positional error model. "
                           + newLine);  
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("Uniform distance distortion "
                           + "formula: " + newLine);
                   writeToTextAreaCommentary("Sum of " + 
                           "polygon area differences / simplified line length " 
                           + newLine);
                   writeToTextAreaCommentary("" + String.format( "%.2f",
                           lp.getSumPolygonAreas()) + 
                           "  /  " 
                           + String.format( "%.2f",
                           lp.sumLineSegmentLengths(getPoints2())) + " = " +
                           String.format( "%.2f", lp.getUniformDistortion())
                           + newLine);
                   writeToTextAreaCommentary(newLine);
                   writeToTextAreaCommentary("Sum Left Polygons Areas:" + 
                          lp.getSumLeftPolygonAreas() + newLine);
                   writeToTextAreaCommentary("Sum Right Polygons Areas:" + 
                          lp.getSumRightPolygonAreas() + newLine);        
                   writeToTextAreaCommentary("Sum Polygons Areas:" + 
                          lp.getSumPolygonAreas() + newLine); 
                   writeToTextAreaCommentary("Original Line Length: " + 
                        String.valueOf(String.format( "%.2f", 
                                lp.sumLineSegmentLengths(getPoints()))) + 
                                newLine);
                        writeToTextAreaCommentary("Simplified Line Length: " + 
                        String.valueOf(String.format( "%.2f",
                                lp.sumLineSegmentLengths(getPoints2()))) +
                                newLine);
                               
                   writeToTextAreaCommentary("Uniform Distance Distortion:" + 
                         String.format( "%.2f", lp.getUniformDistortion()) +
                           newLine); 
                          
                }
                if(jToggleButtonLoadAreaDisplacementError.isSelected() == false){
                    setEffectiveAreaTriangles(null);
                    lblAreaDistortionValue.setText("0");
                    lblAreaDisplacementValue.setText("0");
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_jToggleButtonLoadAreaDisplacementErrorActionPerformed
    
    /**
     * displayLines 
     * 
     * Display Lines between pairs of points
     * @param pts - Points representing line points
     * @param g - Graphic object
     */
    public void displayLines(ArrayList<Point> pts, Graphics g){
        for(int j = 0; j < pts.size() - 1; j++){
            int k = j + 1;
            Point p1 = pts.get(j);
            Point p2 = pts.get(k);

            Graphics2D g2 = (Graphics2D) g; 
            g2.setColor(Color.RED);
            g2.setStroke(new BasicStroke(3));
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(),
                    600 - p2.getY()));
            repaint();
        }
    }

    /**
     * Displays Lines 2
     * 
     * The line is a line connecting 2 points.   
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param lines - Collection of line(s) to display
     */
    public void displayLines2(Graphics g, ArrayList<Liner> lines){   
   
        Graphics2D g2 = (Graphics2D)g; 
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);
        
        for (int j = 0; j < lines.size(); j++){
            Liner line = lines.get(j);
            Point p1 = line.getLinerPoint1();
            Point p2 = line.getLinerPoint2();
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(),
                    600 - p2.getY()));
            repaint();
        }
    }

    
    /**
     * Displays Lines 3.The line is a line connecting 2 points.
     * @param pts
     * @param g - A Graphics object onto which the line is drawn 
            between a pair of points.
     */
    public void displayLines3(ArrayList<Point> pts, Graphics g){
        //int k = 0;
        for(int j = 0; j < pts.size() - 1; j++){
            int k = j + 1;
            Point p1 = pts.get(j);
            Point p2 = pts.get(k);

            Graphics2D g2 = (Graphics2D) g; 
            g2.setColor(Color.BLUE);
            g2.setStroke(new BasicStroke(3));
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(),
                    600 - p2.getY()));
            repaint();
        }
    }

    /**
     * Displays Lines 4.
     * 
     * The line is a line connecting 2 points.   
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param lines - Collection of line(s) to display
     */
    
     public void displayLines4(Graphics g, ArrayList<Liner> lines){
 
        Graphics2D g2 = (Graphics2D)g; 
        g2.setColor(Color.GREEN);
        Stroke dotted = new BasicStroke(2, BasicStroke.CAP_BUTT, 
                BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);
        
        for (int j = 0; j < lines.size(); j++){
            Liner line = lines.get(j);
            Point p1 = line.getLinerPoint1();
            Point p2 = line.getLinerPoint2();
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(), 
                    600 - p2.getY()));
            repaint();
        }
    }
    
    /**
     * Draw Circle
     * 
     * Draws a Circle on the screen centred on a point with a String message
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param point - Point representing centre for circle
     * @param radius - Value representing the radius of the circle
     */
    public void drawCircle(Graphics g, Point point, int radius){
        int x = point.getX();
        int y = 600 - (point.getY());

        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.GREEN);
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, 
                BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);

        //Centre circle using x,y and radius
        g.drawOval(x - radius, y - radius, radius * 2, radius * 2);   
    }

    /**
     * Create text at point location   NOT USED!
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param p - Point on the original line which is the midpoint 
     *            of the line to label
     * @param caption - String value representing text to output
     */
    public void createText(Graphics g, Point p, String caption){
        g.setColor(Color.BLACK);
        int x = p.getX();
        int y = p.getY();
        g.drawString(caption,x,600-y-10);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 35));
    }

    /**
     * Draw polygon
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param polygonList - Points in a list representing a polygon
     * @param arraySize - Value representing the size of an array required for
     *                    the creation of a polygon object
     * @param noOfLineSegments
     */
    public void drawPolygon(Graphics g, ArrayList<Point> polygonList, 
            int arraySize, int noOfLineSegments){
        int[] x = new int[arraySize];
        int[] y = new int[arraySize];

        for (int j = 0; j < polygonList.size(); j++){
            x[j]=(polygonList.get(j).getX());
            y[j]=(polygonList.get(j).getY());
        }
        g.drawPolygon(x, y, noOfLineSegments);
    }   
    
    /**
     * Draw polygon 2   
     * 
     * Used by Reumann Witkam to draw sleeve
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param polygonList - Points in a list representing a polygon
     */
    public void drawPolygon2(Graphics g, ArrayList<Polygon> polygonList){
       
       Graphics2D g2 = (Graphics2D)g;
       g2.setColor(Color.GREEN);
       Stroke dotted = new BasicStroke(3, BasicStroke.CAP_BUTT,
               BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
       g2.setStroke(dotted);
       
        for (int j = 0; j < polygonList.size(); j++){
            Polygon polygon = polygonList.get(j);
            g.drawPolygon(polygon);
        } 
    } 
    
    
    /**
     * Draw Triangle Polygon
     * 
     * Draws a triangle polygon in black dotted line
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param triangles - Points in a list representing a triangle polygon
     */
    public void drawTrianglePolygon(Graphics g, ArrayList<Polygon> triangles){
       
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.BLACK);
        
        
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, 
                BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);
       
        for(int j = 0; j < triangles.size(); j++){
             Polygon triangleLines = triangles.get(j);            
             g2.drawPolygon(triangleLines);
             //g2.fillPolygon(triangleLines);
        }
        
        
//    BufferedImage bufferedImage = new BufferedImage(5, 5, BufferedImage.TYPE_INT_ARGB);
//    g2 = bufferedImage.createGraphics();
//    g2.setColor(Color.WHITE);
//    g2.fillRect(0, 0, 5, 5);
//    g2.setColor(Color.BLACK);
//    g2.drawLine(0, 0, 5, 5); // \
//    g2.drawLine(0, 5, 5, 0); // /
//
//    for(int j = 0; j < triangles.size(); j++){
//        Polygon triangleLines = triangles.get(j);            
//        //g2.drawPolygon(triangleLines);
//        //g2.fillPolygon(triangleLines);
//        Rectangle2D rect = new Rectangle2D.Double(0, 0, 5, 5);
//        g2.setPaint(new TexturePaint(bufferedImage, rect));
//        g2.fillPolygon(triangleLines);
//    }
        
    }   
   
    /**
     * Draw Triangle Polygon 2
     * 
     * Draws a triangle polygon in green dotted line
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param triangles - Points in a list representing a triangle polygon  
     */
   public void drawTrianglePolygon2(Graphics g, ArrayList<Polygon> triangles){
      
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.GREEN);
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, 
                BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);
       
        for(int j = 0; j < triangles.size(); j++){
             Polygon triangleLines = triangles.get(j);            
             g2.drawPolygon(triangleLines);
        }
    }   

    /**
     * Draw circles
     * 
     * Draws an array list collection of circles in magenta dotted line
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param circles - Point(s) representing where circle needs to be drawn
     */
   public void drawCircles(Graphics g, ArrayList<Point> circles){
     
       int radius = 50;
       
       Graphics2D g2 = (Graphics2D)g;
       g2.setColor(Color.MAGENTA);
       Stroke dotted = new BasicStroke(3, BasicStroke.CAP_BUTT,
               BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
       g2.setStroke(dotted);
       
       //Only draw circles for intermediate points (excluding for 
       //start and end points)
       for(int j = 1; j < circles.size()-1; j++){
           int x = circles.get(j).getX();
           int y = 600 - circles.get(j).getY();
           x = x -(radius/2);
           y = y -(radius/2);
          g.drawOval(x,y,radius,radius);
       }
    }
   
   /**
     * Draw circle
     * 
     * Draws a single circle in magenta dotted line
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param circles - Point representing where 1 circle needs to be drawn 
     */
   public void drawCircle(Graphics g, ArrayList<Point> circles){
    
       int radius = 50;
       
       Graphics2D g2 = (Graphics2D)g;
       g2.setColor(Color.MAGENTA);
       Stroke dotted = new BasicStroke(3, BasicStroke.CAP_BUTT,
               BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
       g2.setStroke(dotted);
       
       //Only draw circles for intermediate points (excluding for start
       //and end points)
       for(int j = 0; j < circles.size(); j++){
           int x = circles.get(j).getX();
           int y = 600 - circles.get(j).getY();
           x = x -(radius/2);
           y = y -(radius/2);
          g.drawOval(x, y,radius,radius);
       }
    }
   
   
   /**
     * Draw area circles
     * 
     * Used to draw and render green area circles created for the radial distance 
     * routine
     * 
     * @param g - A Graphics object onto which the line is drawn 
     *            between a pair of points.
     * @param areacircles - Point(s) representing where circle(s) are to be drawn
     * @param radius - Value representing a radius of a circle
     */
   public void drawAreaCircles(Graphics g, ArrayList<Point> areacircles, int radius){
    
       int circleradius = radius * 2;
       
       Graphics2D g2 = (Graphics2D)g;
       g2.setColor(Color.GREEN);
       Stroke dotted = new BasicStroke(3, BasicStroke.CAP_BUTT,
               BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
       g2.setStroke(dotted);
       
       //Only draw circles for intermediate points (excluding for start and 
       //end points)
       for(int j = 0; j < areacircles.size(); j++){
           int x = areacircles.get(j).getX();
           int y = 600 - areacircles.get(j).getY();
           x = x -(circleradius/2);
           y = y -(circleradius/2);
          g.drawOval(x, y,circleradius,circleradius);
       }
    }
   
  
   
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            javax.swing.UIManager.LookAndFeelInfo[] installedLookAndFeels=javax.swing.UIManager.getInstalledLookAndFeels();
            for (int idx=0; idx<installedLookAndFeels.length; idx++)
                if ("Nimbus".equals(installedLookAndFeels[idx].getName())) {
                    javax.swing.UIManager.setLookAndFeel(installedLookAndFeels[idx].getClassName());
                    break;
                }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            new LineSimplificationFrame().setVisible(true);         
                
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox CboSimplificationAlgorithm;
    private javax.swing.JCheckBox chkOriginalLineButton;
    private javax.swing.JCheckBox chkSimplifiedLineButton;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaCommentary;
    private javax.swing.JToggleButton jToggleButtonLoadAreaDisplacementError;
    private javax.swing.JToggleButton jToggleButtonLoadVectorDisplacementError;
    private javax.swing.JLabel lblAreaDisplacementValue;
    private javax.swing.JLabel lblAreaDistortion;
    private javax.swing.JLabel lblAreaDistortionValue;
    private javax.swing.JLabel lblHeight;
    private javax.swing.JLabel lblNoOfOriginalLinePts;
    private javax.swing.JLabel lblNoOfOriginalLinePtsValue;
    private javax.swing.JLabel lblNoOfPoints;
    private javax.swing.JLabel lblNoOfSimplifiedLinePoints;
    private javax.swing.JLabel lblNoOfSimplifiedLinePts;
    private javax.swing.JLabel lblNthPoint;
    private javax.swing.JLabel lblPercentageDecrease;
    private javax.swing.JLabel lblPercentageDecreaseValue;
    private javax.swing.JLabel lblPerpendicularDistance;
    private javax.swing.JLabel lblRadialDistance;
    private javax.swing.JLabel lblRatioAngularityChange;
    private javax.swing.JLabel lblRatioAngularityChangeValue;
    private javax.swing.JLabel lblSimplificationAlgorithm;
    private javax.swing.JLabel lblVectorDisplacement;
    private javax.swing.JLabel lblVectorDisplacementValue;
    private javax.swing.JLabel lblWidth;
    private javax.swing.JButton loadCSVButton;
    private javax.swing.JButton loadDrawALineButton;
    private javax.swing.JButton loadExitButton;
    private javax.swing.JButton loadResetButton;
    private javax.swing.JButton loadSaveADrawnLineToCSVFileButton;
    private javax.swing.JButton loadSaveCSVFileButton;
    private javax.swing.JButton loadSimplifyButton;
    private javax.swing.JButton loadStepButton;
    private javax.swing.JTextField txtHeight;
    private javax.swing.JTextField txtNoOfPoints;
    private javax.swing.JTextField txtNthPoint;
    private javax.swing.JTextField txtPerpendicularDistance;
    private javax.swing.JTextField txtRadialDistance;
    private javax.swing.JTextField txtWidth;
    // End of variables declaration//GEN-END:variables
       
}
