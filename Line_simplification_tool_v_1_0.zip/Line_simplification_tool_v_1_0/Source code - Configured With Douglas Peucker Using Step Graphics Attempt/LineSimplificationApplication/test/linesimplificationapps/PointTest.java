/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.io.File;
import java.util.ArrayList;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Point Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class PointTest {
    
    public PointTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getID method, of class Point.
     */
    @Test
    public void testGetID() {
        System.out.println("getID");
        Point p1 = new Point("p1,100,100");
        String expResult = "p1";
        String result = p1.getID();
        assertEquals(expResult, result);
    }

    /**
     * Test of getX method, of class Point.
     */
    @Test
    public void testGetX() {
        System.out.println("getX");
        Point p2 = new Point("p2,200,200");
        int expResult = 200;
        int result = p2.getX();
        assertEquals(expResult, result);
    }

    /**
     * Test of getY method, of class Point.
     */
    @Test
    public void testGetY() {
        System.out.println("getY");
        Point p3 = new Point("p3,250,221");
        int expResult = 221;
        int result = p3.getY();
        assertEquals(expResult, result);
    }

    /**
     * Test of setX method, of class Point.
     */
    @Test
    public void testSetX() {
        System.out.println("setX");
        int x = 0;
        Point p1 = new Point("p1,200,200");
        p1.setX(220);
        int result = p1.getX();
        int expected = 220;
        assertEquals(expected,result);
    }

    /**
     * Test of setY method, of class Point.
     */
    @Test
    public void testSetY() {
        System.out.println("setY");
        int y = 0;
        Point p2 = new Point("p2,300,300");
        p2.setY(310);
        int result = p2.getY();
        int expected = 310;
        assertEquals(expected,result);
    }

    /**
     * Test of setID method, of class Point.
     */
    @Test
    public void testSetID() {
        System.out.println("setID");
        String id = "";
        Point p2 = new Point("p1,323,456");
        p2.setID("p3");
        String expected = "p3";
        String actual = p2.getID();
        assertEquals(expected,actual);

    }

    /**
     * Test of loadOriginalPts method, of class Point.
     * @throws java.lang.Exception
     */
    @Test
    public void testLoadOriginalPts() throws Exception {
        System.out.println("loadOriginalPts");
        
        ArrayList<Point> expResult = new ArrayList<>();
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        expResult.add(p1);
        expResult.add(p2);
        expResult.add(p3);
        expResult.add(p4);
        expResult.add(p5);
        expResult.add(p6);       
        expResult.add(p7);
        expResult.add(p8);
        expResult.add(p9);
        expResult.add(p10);
        expResult.add(p11);
        expResult.add(p12);
        expResult.add(p13);
      
        expResult.add(p1);
        expResult.add(p2);
        expResult.add(p3);
        expResult.add(p4);
        expResult.add(p5);
        expResult.add(p6);       
        expResult.add(p7);
        expResult.add(p8);
        expResult.add(p9);
        expResult.add(p10);
        expResult.add(p11);
        expResult.add(p12);
        expResult.add(p13);
        
        
        String expectedResult1 = expResult.get(0).getID();
        String expectedResult2 = expResult.get(1).getID();
        String expectedResult3 = expResult.get(2).getID();
        String expectedResult4 = expResult.get(3).getID();
        String expectedResult5 = expResult.get(4).getID();
        String expectedResult6 = expResult.get(5).getID();       
        String expectedResult7 = expResult.get(6).getID();
        String expectedResult8 = expResult.get(7).getID();
        String expectedResult9 = expResult.get(8).getID();
        String expectedResult10 = expResult.get(9).getID();
        String expectedResult11 = expResult.get(10).getID();
        String expectedResult12 = expResult.get(11).getID();
        String expectedResult13 = expResult.get(12).getID();
        
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        ArrayList<Point> result = Point.loadOriginalPts(file);
        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();
        String result4 = result.get(3).getID();
        String result5 = result.get(4).getID();
        String result6 = result.get(5).getID();
        String result7 = result.get(6).getID();
        String result8 = result.get(7).getID();
        String result9 = result.get(8).getID();
        String result10 = result.get(9).getID();
        String result11 = result.get(10).getID();
        String result12 = result.get(11).getID();
        String result13 = result.get(12).getID();
        
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
        assertEquals(expectedResult6, result6);
        assertEquals(expectedResult7, result7);
        assertEquals(expectedResult8, result8);
        assertEquals(expectedResult9, result9);
        assertEquals(expectedResult10, result10);
        assertEquals(expectedResult11, result11);
        assertEquals(expectedResult12, result12);
        assertEquals(expectedResult13, result13);
        
        int expectedSize = 13;
        int resultSize = result.size();
        assertEquals(expectedSize, resultSize);
        
    }
 
}
