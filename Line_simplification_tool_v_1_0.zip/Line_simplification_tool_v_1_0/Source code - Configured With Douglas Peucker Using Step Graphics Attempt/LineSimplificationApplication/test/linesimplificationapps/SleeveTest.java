/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.util.ArrayList;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Sleeve Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class SleeveTest {
    
    public SleeveTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
      
       
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of createSleeve method, of class Sleeve.
     */
    @Test
    public void testCreateSleeve_from_tangent_with_bearing_in_1st_quadrant_Positive_Test() {
        System.out.println("createSleeve");
        Point p1 = new Point("p1,137,201");
        Point p2 = new Point("p2,214,327");
        Liner line = new Liner(p1,p2);
        double bearingOfTangent = line.calculateBearingofLine(p1, p2);  //31.43
        
        //---- THIS BIT REQUIRED FOR SLEEVE ADJUSTMENT BY WIDTH - TO GET NEW ENDPOINT FOR STARTING
        //-----TANGENT. THE SLEEVE IS CREATED (USING CREATESLEEVE) ACCORDING TO THIS RE-ADJUSTED TANGENT
        double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);
        //Adjust tangent length to be same length (width) as user input length (width) by creating new endPoint for line 
        long newEndPointX = Math.round(p1.getX()+ (200 * Math.sin(bearingOfTangentInRadians)));
        long newEndPointY = Math.round(p1.getY()+ (200 * Math.cos(bearingOfTangentInRadians)));
        Point endPoint = new Point("p" + 9 + "," + newEndPointX + "," + newEndPointY);
      
        int expectedResult_x1 = 94;
        int expectedResult_y1 = 227;
        int expectedResult_x2 = 198;
        int expectedResult_y2 = 398;
        int expectedResult_x3 = 284;
        int expectedResult_y3 = 346;
        int expectedResult_x4 = 180;
        int expectedResult_y4 = 175;
        
       //Assumes height(100) and width (200) has been set for sleeve
        Sleeve sleeve = new Sleeve(100,200);
        ArrayList<Liner> lines = new ArrayList<>(sleeve.createSleeve(p1, endPoint, bearingOfTangent));//31.43));
        
        int resultX1 = lines.get(0).getLinerPoint1().getX();
        int resultY1 = lines.get(0).getLinerPoint1().getY();
        int resultX2 = lines.get(1).getLinerPoint1().getX();
        int resultY2 = lines.get(1).getLinerPoint1().getY();
        int resultX3 = lines.get(2).getLinerPoint1().getX();
        int resultY3 = lines.get(2).getLinerPoint1().getY();
        int resultX4 = lines.get(3).getLinerPoint1().getX();
        int resultY4 = lines.get(3).getLinerPoint1().getY();
        
        assertEquals(expectedResult_x1, resultX1);
        assertEquals(expectedResult_y1, resultY1);
        assertEquals(expectedResult_x2, resultX2);
        assertEquals(expectedResult_y2, resultY2);
        assertEquals(expectedResult_x3, resultX3);
        assertEquals(expectedResult_y3, resultY3);
        assertEquals(expectedResult_x4, resultX4);
        assertEquals(expectedResult_y4, resultY4);
    }
    
    /**
     * Test of createSleeve method, of class Sleeve.
     */
    @Test
    public void testCreateSleeve_from_tangent_with_bearing_in_2nd_quadrant_Positive_Test() {
        
        Point p1 = new Point("p4,274,391");
        Point p2 = new Point("p2,484,361");
        int expectedResult_x1 = 281;
        int expectedResult_y1 = 440;
        int expectedResult_x2 = 479;
        int expectedResult_y2 = 412;
        int expectedResult_x3 = 465;
        int expectedResult_y3 = 314;
        int expectedResult_x4 = 267;
        int expectedResult_y4 = 342;
   
       
        Liner tangent = new Liner(p1, p2);
        System.out.println("createSleeve");
        Liner line = new Liner(p1,p2);
        double bearingOfTangent = line.calculateBearingofLine(p1, p2);
     
        //---- THIS BIT REQUIRED FOR SLEEVE ADJUSTMENT BY WIDTH - TO GET NEW ENDPOINT FOR STARTING
        //-----TANGENT. THE SLEEVE IS CREATED (USING CREATESLEEVE) ACCORDING TO THIS RE-ADJUSTED TANGENT
        double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);
        //Adjust tangent length to be same length (width) as user input length (width) by creating new endPoint for line 
        long newEndPointX = Math.round(p1.getX()+ (200 * Math.sin(bearingOfTangentInRadians)));
        long newEndPointY = Math.round(p1.getY()+ (200 * Math.cos(bearingOfTangentInRadians)));
        //System.out.println("newpoint:" + newEndPointX + "," + newEndPointY);  //DEBUG TEST
        Point endPoint = new Point("p" + 9 + "," + newEndPointX + "," + newEndPointY);
        
       //Assumes height(100) and width (200) has been set for sleeve
        Sleeve sleeve = new Sleeve(100,200);
        ArrayList<Liner> result = new ArrayList<>(sleeve.createSleeve(p1, endPoint, bearingOfTangent));
        int resultX1 = result.get(0).getLinerPoint1().getX();
        int resultY1 = result.get(0).getLinerPoint1().getY();
        int resultX2 = result.get(1).getLinerPoint1().getX();
        int resultY2 = result.get(1).getLinerPoint1().getY();
        int resultX3 = result.get(2).getLinerPoint1().getX();
        int resultY3 = result.get(2).getLinerPoint1().getY();
        int resultX4 = result.get(3).getLinerPoint1().getX();
        int resultY4 = result.get(3).getLinerPoint1().getY();
        
        assertEquals(expectedResult_x1, resultX1);
        assertEquals(expectedResult_y1, resultY1);
        assertEquals(expectedResult_x2, resultX2);
        assertEquals(expectedResult_y2, resultY2);
        assertEquals(expectedResult_x3, resultX3);
        assertEquals(expectedResult_y3, resultY3);
        assertEquals(expectedResult_x4, resultX4);
        assertEquals(expectedResult_y4, resultY4);
    }
    
    /**
     * Test of createSleeve method, of class Sleeve.
     */
    @Test
    public void testCreateSleeve_from_tangent_with_bearing_in_3nd_quadrant_Positive_Test() {
        Point p1 = new Point("p5,484,361");
        Point p2 = new Point("p6,395,138");
       
        int expectedResult_x1 = 438;
        int expectedResult_y1 = 380;
        int expectedResult_x2 = 364;
        int expectedResult_y2 = 194;
        int expectedResult_x3 = 456;
        int expectedResult_y3 = 156;
        int expectedResult_x4 = 530;
        int expectedResult_y4 = 342;
       
        Liner tangent = new Liner(p1, p2);
        System.out.println("createSleeve");
        Liner line = new Liner(p1,p2);
        double bearingOfTangent = line.calculateBearingofLine(p1, p2); // 201.76;
     
            
        //---- THIS BIT REQUIRED FOR SLEEVE ADJUSTMENT BY WIDTH - TO GET NEW ENDPOINT FOR STARTING
        //-----TANGENT. THE SLEEVE IS CREATED (USING CREATESLEEVE) ACCORDING TO THIS RE-ADJUSTED TANGENT
        double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);
        //Adjust tangent length to be same length (width) as user input length (width) by creating new endPoint for line 
        long newEndPointX = Math.round(p1.getX()+ (200 * Math.sin(bearingOfTangentInRadians)));
        long newEndPointY = Math.round(p1.getY()+ (200 * Math.cos(bearingOfTangentInRadians)));
        Point endPoint = new Point("p" + 9 + "," + newEndPointX + "," + newEndPointY);
 
        
       //Assumes height(100) and width (200) has been set for sleeve
        Sleeve sleeve = new Sleeve(100,200);
        ArrayList<Liner> result = sleeve.createSleeve(p1, endPoint, bearingOfTangent);
        int resultX1 = result.get(0).getLinerPoint1().getX();
        int resultY1 = result.get(0).getLinerPoint1().getY();
        int resultX2 = result.get(1).getLinerPoint1().getX();
        int resultY2 = result.get(1).getLinerPoint1().getY();
        int resultX3 = result.get(2).getLinerPoint1().getX();
        int resultY3 = result.get(2).getLinerPoint1().getY();
        int resultX4 = result.get(3).getLinerPoint1().getX();
        int resultY4 = result.get(3).getLinerPoint1().getY();
        
        assertEquals(expectedResult_x1, resultX1);
        assertEquals(expectedResult_y1, resultY1);
        assertEquals(expectedResult_x2, resultX2);
        assertEquals(expectedResult_y2, resultY2);
        assertEquals(expectedResult_x3, resultX3);
        assertEquals(expectedResult_y3, resultY3);
        assertEquals(expectedResult_x4, resultX4);
        assertEquals(expectedResult_y4, resultY4);
    }
    
    /**
     * Test of createSleeve method, of class Sleeve.
     */
    @Test
    public void testCreateSleeve_from_tangent_with_bearing_in_4th_quadrant_Positive_Test() {
        //using aw.csv for test
        
        Point p1 = new Point("p1,656,106");
        Point p2 = new Point("p2,343,274");

        int expectedResult_x1 = 632;
        int expectedResult_y1 = 62;
        int expectedResult_x2 = 456;
        int expectedResult_y2 = 157;
        int expectedResult_x3 = 504;
        int expectedResult_y3 = 245;
        int expectedResult_x4 = 680;
        int expectedResult_y4 = 150;
    
        
        Liner tangent = new Liner(p1, p2);
        System.out.println("createSleeve");
        Liner line = new Liner(p1,p2);
        double bearingOfTangent = line.calculateBearingofLine(p1, p2); //298.22;
     
        //---- THIS BIT REQUIRED FOR SLEEVE ADJUSTMENT BY WIDTH - TO GET NEW ENDPOINT FOR STARTING
        //-----TANGENT. THE SLEEVE IS CREATED (USING CREATESLEEVE) ACCORDING TO THIS RE-ADJUSTED TANGENT
        double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);
        //Adjust tangent length to be same length (width) as user input length (width) by creating new endPoint for line 
        long newEndPointX = Math.round(p1.getX()+ (200 * Math.sin(bearingOfTangentInRadians)));
        long newEndPointY = Math.round(p1.getY()+ (200 * Math.cos(bearingOfTangentInRadians)));
        Point endPoint = new Point("p" + 9 + "," + newEndPointX + "," + newEndPointY);
        
        
       //Assumes height(100) and width (200) has been set for sleeve
        Sleeve sleeve = new Sleeve(100,200);
        ArrayList<Liner> result = sleeve.createSleeve(p1, endPoint, bearingOfTangent);
        int resultX1 = result.get(0).getLinerPoint1().getX();
        int resultY1 = result.get(0).getLinerPoint1().getY();
        int resultX2 = result.get(1).getLinerPoint1().getX();
        int resultY2 = result.get(1).getLinerPoint1().getY();
        int resultX3 = result.get(2).getLinerPoint1().getX();
        int resultY3 = result.get(2).getLinerPoint1().getY();
        int resultX4 = result.get(3).getLinerPoint1().getX();
        int resultY4 = result.get(3).getLinerPoint1().getY();
        
        assertEquals(expectedResult_x1, resultX1);
        assertEquals(expectedResult_y1, resultY1);
        assertEquals(expectedResult_x2, resultX2);
        assertEquals(expectedResult_y2, resultY2);
        assertEquals(expectedResult_x3, resultX3);
        assertEquals(expectedResult_y3, resultY3);
        assertEquals(expectedResult_x4, resultX4);
        assertEquals(expectedResult_y4, resultY4);
    }
   
}
