/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * Liner Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class LinerTest {
    
    public LinerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of getLinerPoint1 method, of class Liner.
     */
    @Test
    public void testGetLinerPoint1() {
        System.out.println("getLinerPoint1");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,200");
        Liner line = new Liner(p1,p2);
        Point result = line.getLinerPoint1();
        String expectedResult = p1.getID();
        String actualResult = result.getID();
        assertEquals(expectedResult, actualResult);
    }

    /**
     * Test of getLinerPoint2 method, of class Liner.
     */
    @Test
    public void testGetLinerPoint2() {
        System.out.println("getLinerPoint2");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,200");
        Liner line = new Liner(p1,p2);
        Point result = line.getLinerPoint2();
        String expectedResult = p2.getID();
        String actualResult = "p2";
        assertEquals(expectedResult, actualResult);
    }

    /**
     * Test of getLength method, of class Liner.
     */
    @Test
    public void testGetLength() {
        System.out.println("getLength");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,200");
        Liner line = new Liner(p1,p2);
        double expResult = 141.42;
        double result = line.getLength();
        assertEquals(expResult, result, 0.01);

    }
    
    /**
     * Test of calculateBearingofLine method, of class LinePerformance.
     */
    @Test
    public void testCalculateBearingofLine_first_Quadrant() {
        System.out.println("calculateBearingofLine");
        Point point1 = new Point("p1,137,201");
        Point point2 = new Point("p2,214,327");
        Liner line = new Liner(point1, point2);
        double expResult = 31.43;
        double result = line.calculateBearingofLine(point1, point2);
        assertEquals(expResult, result, 31.43);
    }

     /**
     * Test of calculateBearingofLine method, of class LinePerformance.
     */
    @Test
    public void testCalculateBearingofLine_second_Quadrant() {
        System.out.println("calculateBearingofLine");
        Point point1 = new Point("p1,310,173");
        Point point2 = new Point("p2,555,183");
        Liner line = new Liner(point1, point2);
        double expResult = 127.79;
        double result = line.calculateBearingofLine(point1, point2);
        assertEquals(expResult, result, 127.79);
    }

     /**
     * Test of calculateBearingofLine method, of class LinePerformance.
     */
    @Test
    public void testCalculateBearingofLine_third_Quadrant() {
        System.out.println("calculateBearingofLine");
        Point point1 = new Point("p1,555,183");
        Point point2 = new Point("p2,383,18");
        Liner line = new Liner(point1, point2);
        double expResult = 226.19;
        double result = line.calculateBearingofLine(point1, point2);
        assertEquals(expResult, result, 226.19);
    }

     /**
     * Test of calculateBearingofLine method, of class LinePerformance.
     */
    @Test
    public void testCalculateBearingofLine_fourth_Quadrant() {
        System.out.println("calculateBearingofLine");
        Point point1 = new Point("p1,383,18");
        Point point2 = new Point("p2,193,117");
        Liner line = new Liner(point1, point2);
        double expResult = 297.52;
        double result = line.calculateBearingofLine(point1, point2);
        assertEquals(expResult, result, 297.52);
    }

    
}
