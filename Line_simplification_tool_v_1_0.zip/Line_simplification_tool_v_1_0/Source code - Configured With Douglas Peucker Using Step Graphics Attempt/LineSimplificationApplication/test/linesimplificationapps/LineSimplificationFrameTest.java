/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JPanel;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Line Simplification Frame Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class LineSimplificationFrameTest {
    
    public LineSimplificationFrameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    
    /**
     * Test of isPointInJPanel method, of class LineSimplificationFrame.
     */
    @Test
    public void testIsPointInJPanel_PositiveTest() {
        System.out.println("isPointInJPanel_PositiveTest");
        Point p = new Point("p1,200,300");
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        JPanel jpanel = new JPanel();
        jpanel.setSize(800, 600);
        LineSimplificationFrame ls = new LineSimplificationFrame();
        boolean expResult = true;
        boolean result = ls.isPointInJPanel(p, jpanel);
        assertEquals(expResult, result);
    }
    
       /**
     * Test of isPointInJPanel method, of class LineSimplificationFrame.
     */
    @Test
    public void testIsPointInJPanel_NegativeTest() {
        System.out.println("isPointInJPanel_NegativeTest");
        Point p = new Point("p1,900,900");
        JPanel jpanel2 = new JPanel();
        jpanel2.setSize(800,600); 
        LineSimplificationFrame ls = new LineSimplificationFrame();
        boolean expResult = false;
        boolean result = ls.isPointInJPanel(p, jpanel2);
        assertEquals(expResult, result);
    }
    
 
    /**
     * Test of routineOfRadialDistanceUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testRoutineOfRadialDistanceUsingCounter() throws FileNotFoundException {
        System.out.println("routineOfRadialDistanceUsingCounter");
        LineSimplification ls = new LineSimplification();
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        lsf.setPoints2(new ArrayList<>(lsf.getPoints()));
        lsf.setTxtRadialDistance("150");
        
        ls.routineOfDistanceBetweenPoints(lsf.getPoints(), 150);
        
        //Imitate step button pressed 12 times by calling method 12 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected (via combo box selection event) 
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount()); 
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount()); 
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount()); 
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfRadialDistanceUsingCounter(ls,lsf.getCount()); 
        
       
       //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        //Expected points after simplification
        String expectedResult1 = p1.getID();
        String expectedResult2 = p4.getID();
        String expectedResult3 = p6.getID();
        String expectedResult4 = p9.getID();        
        String expectedResult5 = p11.getID();        
        String expectedResult6 = p13.getID();

        
         //Get actual simplifiedLine (getPoints2)
        String result1 = lsf.getPoints2().get(0).getID();
        String result2 = lsf.getPoints2().get(1).getID();
        String result3 = lsf.getPoints2().get(2).getID();
        String result4 = lsf.getPoints2().get(3).getID();
        String result5 = lsf.getPoints2().get(4).getID();
        String result6 = lsf.getPoints2().get(5).getID();
     
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
        assertEquals(expectedResult6, result6);
    
        
        //Test no of returned points is as expected
        int expected = 6;
        int result = lsf.getPoints2().size();
        assertEquals(expected,result);        
    }

    
    
    
    
    /**
     * Test of nthPointUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testNthPointUsingCounter() throws FileNotFoundException {
      
        System.out.println("nthPointUsingCounter");
  
        LineSimplification ls = new LineSimplification();
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        lsf.setTxtNthPoint("3");
        
        //Imitate step button pressed 12 times by calling method 12 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected (via combo box selection event) 
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount()); 
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount()); 
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount()); 
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount());
        lsf.nthPointUsingCounter(ls,lsf.getCount()); 
        
       
       //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        //Expected points after simplification
        String expectedResult1 = p1.getID();
        String expectedResult2 = p4.getID();       
        String expectedResult3 = p7.getID();        
        String expectedResult4 = p10.getID();         
        String expectedResult5 = p13.getID();
        
         //Get actual simplifiedLine (getPoints2)
        String result1 = lsf.getPoints2().get(0).getID();
        String result2 = lsf.getPoints2().get(1).getID();
        String result3 = lsf.getPoints2().get(2).getID();
        String result4 = lsf.getPoints2().get(3).getID();
        String result5 = lsf.getPoints2().get(4).getID();
                
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
        
        //Test no of returned points is as expected
        int expected = 5;
        int result = lsf.getPoints2().size();
        assertEquals(expected,result);        
    }

    
    
    /**
     * Test of routineOfPerpendicularDistanceUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testRoutineOfPerpendicularDistanceUsingCounter() throws FileNotFoundException {
        
        System.out.println("routineOfPerpendicularDistanceUsingCounter");
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        lsf.setPoints2(new ArrayList<>(lsf.getPoints()));
        lsf.setTxtPerpendicularDistance("100");
        LineSimplification ls = new LineSimplification();
        
        //Imitate step button pressed 22 times by calling method 22 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected (via combo box selection event) 
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
        lsf.routineOfPerpendicularDistanceUsingCounter(ls,lsf.getCount());
       
       //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        //Expected points after simplification
        String expectedResult1 = p1.getID();
        String expectedResult2 = p9.getID();       
        String expectedResult3 = p11.getID();        
        String expectedResult4 = p13.getID();
        
         //Get actual simplifiedLine (getPoints2)
        String result1 = lsf.getPoints2().get(0).getID();
        String result2 = lsf.getPoints2().get(1).getID();
        String result3 = lsf.getPoints2().get(2).getID();
        String result4 = lsf.getPoints2().get(3).getID();
     
                
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);

        
        //Test no of returned points is as expected
        int expected = 4;
        int result = lsf.getPoints2().size();
        assertEquals(expected,result);        
        
    }
    
   

       
    
    /**
     * Test of reumannWitkamUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testReumannWitkamUsingCounter() throws FileNotFoundException {
        System.out.println("reumannWitkamUsingCounter");
        
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        lsf.setPoints2(new ArrayList<>(lsf.getPoints()));
        lsf.setTxtHeight("100");
        lsf.setTxtWidth("200");
        LineSimplification ls = new LineSimplification();
        
        //Imitate step button pressed 11 times by calling method 11 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected (via combo box selection event) 
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount()); 
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount()); 
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount()); 
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
        lsf.reumannWitkamUsingCounter(ls,lsf.getCount());
         
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        //Expected points after simplification
        String expectedResult1 = p1.getID();
        String expectedResult2 = p3.getID();       
        String expectedResult3 = p4.getID();        
        String expectedResult4 = p6.getID();         
        String expectedResult5 = p7.getID();
        String expectedResult6 = p8.getID();
        String expectedResult7 = p9.getID();       
        String expectedResult8 = p10.getID();        
        String expectedResult9 = p11.getID();         
        String expectedResult10 = p12.getID();
        String expectedResult11 = p13.getID();
           
        
         //Get actual simplifiedLine (getPoints2)
        String result1 = lsf.getPoints2().get(0).getID(); 
        String result2 = lsf.getPoints2().get(1).getID(); 
        String result3 = lsf.getPoints2().get(2).getID();  
        String result4 = lsf.getPoints2().get(3).getID();  
        String result5 = lsf.getPoints2().get(4).getID();
        String result6 = lsf.getPoints2().get(5).getID();
        String result7 = lsf.getPoints2().get(6).getID();
        String result8 = lsf.getPoints2().get(7).getID();
        String result9 = lsf.getPoints2().get(8).getID();
        String result10 = lsf.getPoints2().get(9).getID();
        String result11 = lsf.getPoints2().get(10).getID();
        
        
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
        assertEquals(expectedResult6, result6);
        assertEquals(expectedResult7, result7);
        assertEquals(expectedResult8, result8);
        assertEquals(expectedResult9, result9);
        assertEquals(expectedResult10, result10);
        assertEquals(expectedResult11, result11);
        
        
        //Test no of returned points is as expected
        int expected = 11;
        int result = lsf.getPoints2().size();
        assertEquals(expected,result);      

    }

    
    
    /**
     * Test of visvalingamWhyattUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testVisvalingamWhyattUsingCounter() throws FileNotFoundException {
        System.out.println("visvalingamWhyattUsingCounter");
        //LineSimplification ls = new LineSimplification();
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        lsf.setPoints2(new ArrayList<>(lsf.getPoints()));
        lsf.setTxtNoOfPoints("5");
        lsf.setCount(0);
        
        //Imitate step button pressed 17 times by calling method 12 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected (via combo box selection event) 
        
       LineSimplification ls = new LineSimplification();
       ls.visvalingamWhyattSimplified(lsf.getPoints(), 5); //called and used within vw_UsingCounter method 
       
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());  
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());  
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());  
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount()); 
        lsf.visvalingamWhyattUsingCounter(ls,lsf.getCount());  
       
       //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        //Expected points left after simplification
        String expectedResult1 = p1.getID();
        String expectedResult2 = p7.getID();       
        String expectedResult3 = p9.getID();        
        String expectedResult4 = p11.getID();         
        String expectedResult5 = p13.getID();
        
        //lsf.getPoints2();
         //Get actual simplifiedLine (getPoints2)
        
        Point actualPt1 = lsf.getPoints2().get(0);
        Point actualPt2 = lsf.getPoints2().get(1);
        Point actualPt3 = lsf.getPoints2().get(2);
        Point actualPt4 = lsf.getPoints2().get(3);
        Point actualPt5 = lsf.getPoints2().get(4);
        
        String result1 = actualPt1.getID();
        String result2 = actualPt2.getID();
        String result3 = actualPt3.getID();
        String result4 = actualPt4.getID();
        String result5 = actualPt5.getID();
                
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
        
        //Test no of returned points is as expected
        int expected = 5;
        int result = ls.getSimplifiedLinePts().size();
        assertEquals(expected,result);
    }
    
  
    
    
    /**
     * Test of langUsingCounter method, of class LineSimplificationFrame.
     * @throws java.io.FileNotFoundException
     */
    @Test
    public void testLangUsingCounter() throws FileNotFoundException {
        System.out.println("langUsingCounter");
        
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        //File file = new File("C:\\ACTESTDATA\\dews.csv");
        //lsf.setPoints(new ArrayList<>(Point.loadOriginalPts(file)));
        //lsf.setPoints2(new ArrayList<>(lsf.getPoints()));
        
        
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p7);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p13);
        
        lsf.setPoints(new ArrayList<Point>(originalLinePts));
        lsf.setPoints2(new ArrayList<Point>(simplifiedLinePts));
       
        lsf.setTxtNoOfPoints("10");
        lsf.setTxtPerpendicularDistance("100");
        LineSimplification ls = new LineSimplification();

        
        //Imitate step button pressed 13 times by calling method 13 times
        //Increment of count happens in method. getCount is initially 0.
        //NB It gets reset when a new algorithm is selected
        //(via combo box selection event) 
        lsf.setCount(0);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(1);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(2);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(3);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(4);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(5);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(6);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(7);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(8);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(9);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(10);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(11);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(12);
        lsf.langUsingCounter(ls,lsf.getCount());
        lsf.setCount(13);
     
        //Expected points after simplification
        String expectedResult1 = p1.getID();         
        String expectedResult2 = p7.getID();
        String expectedResult3 = p9.getID();              
        String expectedResult4 = p11.getID();         
        String expectedResult5 = p13.getID();
             
         //Get actual simplifiedLine (getPoints2)
        String result1 = lsf.getPoints2().get(0).getID(); 
        String result2 = lsf.getPoints2().get(1).getID(); 
        String result3 = lsf.getPoints2().get(2).getID();  
        String result4 = lsf.getPoints2().get(3).getID();  
        String result5 = lsf.getPoints2().get(4).getID();
            
        
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        assertEquals(expectedResult3, result3);
        assertEquals(expectedResult4, result4);
        assertEquals(expectedResult5, result5);
       
        
        //Test no of returned points is as expected
        int expected = 5;
        int result = lsf.getPoints2().size();
        assertEquals(expected,result);      

    }
    
    
     /**
     * Test of validateNthPointInput method, of class LineSimplificationFrame.
     * 
     */
    @Test
    public void validateNthPointInput_PositiveTest(){
        System.out.println("validateNthPointInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        
        //Set up original line points
         //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
     
        
        //Test For Acceptable values any value between 1 and size of getPoints
        //returned e.g. 13. inside the validNthPointInput() method being tested
        lsf.setTxtNthPoint("1");
        boolean expected1 = true;
        boolean result1 = lsf.validateNthPointInput();
        
        lsf.setTxtNthPoint("13");
        boolean expected2 = true;
        boolean result2 = lsf.validateNthPointInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
        
    }
    
    
    /**
     * Test of validateNoOfPointsInput method, of class LineSimplificationFrame.
     */
    @Test
    public void validateNoOfPointsInput_PostitiveTest(){
        System.out.println("validateNoOfPointsInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
         //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
     
        //Test For Accceptable values (1 - 13)
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
  
        lsf.setTxtNoOfPoints("1");
        boolean expected1 = true;
        boolean result1 = lsf.validateNoOfPointsInput();
        lsf.setTxtNoOfPoints("13");
        boolean expected2 = true;
        boolean result2 = lsf.validateNoOfPointsInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
    }
    
    /**
     * Test of validatePerpendicularDistanceInput method, of 
     * class LineSimplificationFrame.
     */
    @Test
    public void validatePerpendicularDistanceInput_PositiveTest(){
        System.out.println("validatePerpendicularDistanceInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
            
        //Test For Acceptable values (1 - 800)
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        lsf.setTxtPerpendicularDistance("1");
        boolean expected1 = true;
        boolean result1 = lsf.validatePerpendicularDistanceInput("");
        lsf.setTxtPerpendicularDistance("800");
        boolean expected2 = true;
        boolean result2 = lsf.validatePerpendicularDistanceInput("");
       
        assertEquals(expected1,result1);      
        assertEquals(expected2,result2);       
    }
    
    
    /**
     * Test of validateRadialDistanceInput method, of class 
     * LineSimplificationFrame.
     */
    @Test
    public void validateRadialDistanceInput_PostiveTest(){
        System.out.println("validateRadialDistanceInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Acceptable values (1 - 300)
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        lsf.setTxtRadialDistance("1");
        boolean expected1 = true;
        boolean result1 = lsf.validateRadialDistanceInput();
        
        lsf.setTxtRadialDistance("300");
        boolean expected2 = true;
        boolean result2 = lsf.validateRadialDistanceInput();
        
        assertEquals(expected1,result1);      
        assertEquals(expected2,result2); 
    
    }
    
    
    
    /**
     * Test of validateHeightInput method, of class LineSimplificationFrame.
     */
    @Test
    public void validateHeightInput_PositiveTest(){
        System.out.println("validateHeightInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        //Test For Acceptable values (1 - 600)
        lsf.setTxtHeight("1");
        boolean expected1 = true;
        boolean result1 = lsf.validateHeightInput();
        
        lsf.setTxtHeight("600");
        boolean expected2 = true;
        boolean result2 = lsf.validateHeightInput();
        
        assertEquals(expected1,result1);    
        assertEquals(expected2,result2);
    }
    
    /**
     * Test of validateWidth method, of class LineSimplificationFrame.
     */
    @Test
    public void validateWidthInput_PositiveTest(){
        System.out.println("validateWidthInput_PositiveTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
                
        //Test For Acceptable values (1 - 800)
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        lsf.setTxtWidth("1");
        boolean expected1 = true;
        boolean result1 = lsf.validateWidthInput();
        lsf.setTxtWidth("800");
        boolean expected2 = true;
        boolean result2 = lsf.validateWidthInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
    }
    
    /**
     * Test of validateNthPointInput method, of class LineSimplificationFrame.
     * 
     */
    @Test
    public void validateNthPointInput_NegativeTest(){
        System.out.println("validateNthPointInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Not Acceptable values (bounds -1, 14 and aaaa)
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        lsf.setTxtNthPoint("-1");      
        boolean expected1 = false;
        boolean result1 = lsf.validateNthPointInput();
        
        lsf.setTxtNthPoint("14");      
        boolean expected2 = false;
        boolean result2 = lsf.validateNthPointInput();
        
        lsf.setTxtNthPoint("aaaaaa");      
        boolean expected3 = false;
        boolean result3 = lsf.validateNthPointInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
        assertEquals(expected3,result3);
        
    }
    
    
    /**
     * Test of validateNoOfPointsInput method, of class LineSimplificationFrame.
     */
    @Test
    public void validateNoOfPointsInput_NegativeTest(){
        System.out.println("validateNoOfPointsInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
       
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Not Acceptable values
        LineSimplificationFrame lsf = new LineSimplificationFrame();        
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        
        //Test For Not Acceptable values (e.g bounds -1, 14 and aaab"
        lsf.setTxtNoOfPoints("-1");
        boolean expected1 = false;
        boolean result1 = lsf.validateNoOfPointsInput();
        
        lsf.setTxtNoOfPoints("14");
        boolean expected2 = false;
        boolean result2 = lsf.validateNoOfPointsInput();
        
        lsf.setTxtNoOfPoints("aaab");
        boolean expected3 = false;
        boolean result3 = lsf.validateNoOfPointsInput();
        
        assertEquals(expected1,result1);   
        assertEquals(expected2,result2);  
        assertEquals(expected3,result3);  
    }
    
    /**
     * Test of validatePerpendicularDistanceInput method, of 
     * class LineSimplificationFrame.
     */
    @Test
    public void validatePerpendicularDistanceInput_NegativeTest(){
        System.out.println("validatePerpendicularDistanceInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Not Acceptable values
        LineSimplificationFrame lsf = new LineSimplificationFrame();        
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        //Test For Not Accepted values
        lsf.setTxtPerpendicularDistance("-1");
        boolean expected1 = false;
        boolean result1 = lsf.validatePerpendicularDistanceInput("");
        assertEquals(expected1,result1);      
        
        //Test For Not Accepted values
        lsf.setTxtPerpendicularDistance("801");
        boolean expected2 = false;
        boolean result2 = lsf.validatePerpendicularDistanceInput("");
        assertEquals(expected2,result2);
        
        //Test For Not Accepted values
        lsf.setTxtPerpendicularDistance("aasbdbd");
        boolean expected3 = false;
        boolean result3 = lsf.validatePerpendicularDistanceInput("");
        assertEquals(expected3,result3);
        
    }
        
    /**
     * Test of validateRadialDistanceInput method, of class 
     * LineSimplificationFrame.
     */
    @Test
    public void validateRadialDistanceInput_NegativeTest(){
        System.out.println("validateRadialDistanceInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Not Acceptable values
        LineSimplificationFrame lsf = new LineSimplificationFrame();        
        lsf.setPoints(new ArrayList<>(originalLinePts));
        
        //Test For Not Accepted Values (-1, 301, aaaa)
        lsf.setTxtRadialDistance("-1");
        boolean expected1 = false;
        boolean result1 = lsf.validateRadialDistanceInput();
        
        lsf.setTxtRadialDistance("301");
        boolean expected2 = false;
        boolean result2 = lsf.validateRadialDistanceInput();
        
        lsf.setTxtRadialDistance("aaaa");
        boolean expected3 = false;
        boolean result3 = lsf.validateRadialDistanceInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
        assertEquals(expected3,result3);
    }
    
    
    /**
     * Test of validateHeightInput method, of class LineSimplificationFrame.
     */
    @Test
    public void validateHeightInput_NegativeTest(){
        System.out.println("validateHeightInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();
      
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        //Test For Not Acceptable values (-1, 601, zzzz)
        LineSimplificationFrame lsf = new LineSimplificationFrame();        
        lsf.setPoints(new ArrayList<>(originalLinePts));
               
        //Test For Not Accepted Values
        lsf.setTxtHeight("-1");
        boolean expected1 = false;
        boolean result1 = lsf.validateHeightInput();
        
        lsf.setTxtHeight("601");
        boolean expected2 = false;
        boolean result2 = lsf.validateHeightInput();
        
        lsf.setTxtHeight("zzzz");
        boolean expected3 = false;
        boolean result3 = lsf.validateHeightInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
        assertEquals(expected3,result3);
    }
    
    /**
     * Test of validateWidth method, of class LineSimplificationFrame.
     */
    @Test
    public void validateWidthInput_NegativeTest(){
        System.out.println("validateWidthInput_NegativeTest");
        ArrayList<Point> originalLinePts = new ArrayList<>();  
        
        //Set up original line points
        //Points in dews.csv (before simplification)
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
       
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
      
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        lsf.setPoints(new ArrayList<>(originalLinePts));
        //Test For Not Accepted values (bounds -1, 801, aaaa)
        lsf.setTxtWidth("-1");
        boolean expected1 = false;
        boolean result1 = lsf.validateWidthInput();
        
        lsf.setTxtWidth("801");
        boolean expected2 = false;
        boolean result2 = lsf.validateWidthInput();
        
        lsf.setTxtWidth("aaaa");
        boolean expected3 = false;
        boolean result3 = lsf.validateWidthInput();
        
        assertEquals(expected1,result1);
        assertEquals(expected2,result2);
        assertEquals(expected3,result3);
    }
    
     
    
    
   
}
