/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * File Write Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class FileWriteTest {
    
    public FileWriteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of appendWrite method, of class FileWrite.
     * 
     * @throws java.io.IOException
     */
    @Test
    public void testAppendWrite() throws IOException {
        
        //BEFORE THIS UNIT TEST IS RUN
        //DELETE OUT "p14,100,200" FROM testOfAppendWrite.csv file
          
        System.out.println("appendWrite");
        File file = new File("C:\\ACTESTDATA\\testOfAppendWrite.csv");
        String textToWrite = "p14,100,200";
        FileWrite fw = new FileWrite();
        fw.appendWrite(file, textToWrite);
           
        ArrayList<String> recordsInFile = new ArrayList<>();
        String lastRecord = "";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("C:\\ACTESTDATA\\testOfAppendWrite.csv"));
            while ((lastRecord = br.readLine()) != null) {
                 String record = br.readLine();
                 recordsInFile.add(record);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileWriteTest.class.getName()).log(Level.SEVERE, null, ex);
        }

        String expected = textToWrite;
        String result = recordsInFile.get(recordsInFile.size()-1);  
        assertEquals(textToWrite,result);
    }

    /**
     * Test of loadCSVFile method, of class FileWrite.
     */
    @Test
    public void testLoadCSVFile() {
        //When this test is run please select dews.csv file
        //In the dialog that appears
        
        System.out.println("loadCSVFile");
        FileWrite fw = new FileWrite();
        File expResult = new File("C:\\ACTESTDATA\\dews.csv");
        //Enter dews.csv into load csv dialog 
        File result = fw.loadCSVFile();
        assertEquals(expResult, result);
    }

    /**
     * Test of saveCSVFile method, of class FileWrite.
     */
    @Test
    public void testSaveCSVFile_PositiveTest() {
        //When this test is run please select fred.csv file
        //In the dialog that appears

        System.out.println("saveCSVFile");
        FileWrite fw = new FileWrite();
        File expResult = new File("C:\\ACTESTDATA\\fred.csv");
        //Enter fred.csv into save csv dialog
        File result = fw.saveCSVFile();
        assertEquals(expResult, result);
    }
    
    
    /**
     * Test of Save Simplified Line TO CSV File method, of class FileWrite.
     */
    @Test
    public void testSaveSimplifiedLineToCSVFile_PositiveTest() {
        //When this test is run please select fred.csv file
        //In the dialog that appears

        System.out.println("saveSimplifiedLineToCSVFile");
        FileWrite fw = new FileWrite();
        File expResult = new File("C:\\ACTESTDATA\\fred.csv");
        //Enter fred.csv into save csv dialog
        File result = fw.saveSimplifiedLineToCSVFile();
        assertEquals(expResult, result);
    }
    
    
    /**
     * Test of getFileExtension method, of class FileWrite.
     */
    @Test
    public void testGetFileExtension_PositiveTest() {
        System.out.println("getFileExtension_PositiveTest");
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        FileWrite fw = new FileWrite();       
        String result = fw.getFileExtension(file);
        String expResult = ".csv";  
        assertEquals(expResult, result);
    }

    /**
     * Test of ReturnFirstLineOfFile method, of class FileWrite.
     * @throws java.lang.Exception
     */
    @Test
    public void testReturnFirstLineOfFile_PositiveTest() throws Exception {
        System.out.println("ReturnFirstLineOfFile_PositiveTest");
        File file = new File("C:\\ACTESTDATA\\dews.csv");
        FileWrite fw = new FileWrite();
        String expResult = "p1,68,113";
        String result = fw.ReturnFirstLineOfFile(file);
        assertEquals(expResult, result);
    }

}
