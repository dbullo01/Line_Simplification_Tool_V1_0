/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.awt.Polygon;
import java.awt.Rectangle;
import java.util.ArrayList;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/**
 *Line Simplification Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class LineSimplificationTest {
    
    public LineSimplificationTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

  
    /**
     * Test of checkNoOfPoints method, of class LineSimplification.
     */
    @Test
    public void testCheckNoOfPoints() {
        System.out.println("checkNoOfPoints");
        String nameOfAlgorithm = "nthPoint";
        ArrayList<Point> points = new ArrayList<>();
        int noOfReqPoints = 4;
        LineSimplification ls = new LineSimplification();
        boolean expResult = false;
        boolean result = ls.checkNoOfPoints(nameOfAlgorithm, points, 
                noOfReqPoints);
        assertEquals(expResult, result);
    }

    /**
     * Test of nthPoint method, of class LineSimplification.
     */
    @Test
    public void testNthPoint() {
        System.out.println("nthPoint");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p5);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p13);
        
        int n = 4;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> result = ls.nthPoint(originalLinePts, n);
        String expectedStr1 = simplifiedLinePts.get(0).getID();
        String expectedStr2 = simplifiedLinePts.get(1).getID();
        String expectedStr3 = simplifiedLinePts.get(2).getID();
        String expectedStr4 = simplifiedLinePts.get(3).getID();
        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();
        String result4 = result.get(3).getID();
        
        assertEquals(expectedStr1, result1);
        assertEquals(expectedStr2, result2);
        assertEquals(expectedStr3, result3);
        assertEquals(expectedStr4, result4);
        
        int expectedNoOfPoints = 4;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of routineOfDistanceBetweenPoints method, of class LineSimplification.
     */
    @Test
    public void testRoutineOfDistanceBetweenPoints() {
        System.out.println("routineOfDistanceBetweenPoints");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p4);
        simplifiedLinePts.add(p6);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p13);
                  
        int radiusDistanceTolerance = 150;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> result = ls.routineOfDistanceBetweenPoints(originalLinePts,
                radiusDistanceTolerance);
       
        String strExpected1 = simplifiedLinePts.get(0).getID();
        String strExpected2 = simplifiedLinePts.get(1).getID();
        String strExpected3 = simplifiedLinePts.get(2).getID();
        String strExpected4 = simplifiedLinePts.get(3).getID();
        String strExpected5 = simplifiedLinePts.get(4).getID();
        String strExpected6 = simplifiedLinePts.get(5).getID();

        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();      
        String result4 = result.get(3).getID();
        String result5 = result.get(4).getID();
        String result6 = result.get(5).getID();      
      
        assertEquals(strExpected1, result1);
        assertEquals(strExpected2, result2);
        assertEquals(strExpected3, result3);
        assertEquals(strExpected4, result4);
        assertEquals(strExpected5, result5);
        assertEquals(strExpected6, result6);
        
        int expectedNoOfPoints = 6;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of perpendicularDistanceRoutine method, of class LineSimplification.
     */
    @Test
    public void testPerpendicularDistanceRoutine() {
        System.out.println("perpendicularDistanceRoutine");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p13);
                  
        LineSimplification ls = new LineSimplification();  
        double perpendicularDistanceTolerance = 100.0;
        ArrayList<Point> result = ls.perpendicularDistanceRoutine(originalLinePts,
                perpendicularDistanceTolerance);
        
        String expResult1 = simplifiedLinePts.get(0).getID();
        String expResult2 = simplifiedLinePts.get(1).getID();
        String expResult3 = simplifiedLinePts.get(2).getID();
        String expResult4 = simplifiedLinePts.get(3).getID();
        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();
        String result4 = result.get(3).getID();
      
        assertEquals(expResult1, result1);
        assertEquals(expResult2, result2);
        assertEquals(expResult3, result3);
        assertEquals(expResult4, result4);
        
        int expectedNoOfPoints = 4;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of reumannWitkam method, of class LineSimplification.
     */
    @Test
    public void testReumannWitkam() {
        System.out.println("reumannWitkam");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
       
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        LineSimplification ls = new LineSimplification();
        int height = 100;
        int width = 200;
        simplifiedLinePts = ls.reumannWitkam(originalLinePts, height, width);
        
        String expResult1 = p1.getID();
        String expResult2 = p3.getID();
        String expResult3 = p4.getID();
        String expResult4 = p6.getID();
        String expResult5 = p7.getID();
        String expResult6 = p8.getID();
        String expResult7 = p9.getID();
        String expResult8 = p10.getID();
        String expResult9 = p11.getID();
        String expResult10 = p12.getID();
        String expResult11 = p13.getID();
    
        String result1 = simplifiedLinePts.get(0).getID();
        String result2 = simplifiedLinePts.get(1).getID();
        String result3 = simplifiedLinePts.get(2).getID();
        String result4 = simplifiedLinePts.get(3).getID();
        String result5 = simplifiedLinePts.get(4).getID();
        String result6 = simplifiedLinePts.get(5).getID();
        String result7 = simplifiedLinePts.get(6).getID();
        String result8 = simplifiedLinePts.get(7).getID();
        String result9 = simplifiedLinePts.get(8).getID();
        String result10 = simplifiedLinePts.get(9).getID();
        String result11 = simplifiedLinePts.get(10).getID();
        
        assertEquals(expResult1, result1);
        assertEquals(expResult2, result2);
        assertEquals(expResult3, result3);
        assertEquals(expResult4, result4);
        assertEquals(expResult5, result5);
        assertEquals(expResult6, result6);
        assertEquals(expResult7, result7);
        assertEquals(expResult8, result8);
        assertEquals(expResult9, result9);
        assertEquals(expResult10, result10);
        assertEquals(expResult11, result11);
        
        int expectedNoOfPoints = 11;
        int actualNoOfPoints = simplifiedLinePts.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of simplifiedLinePointsInSleeve method, of class LineSimplification.
     */
    @Test
    public void testSimplifiedLinePointsInSleeve_PositiveTest() {
        System.out.println("simplifiedLinePointsInSleeve_PositiveTest");
        Point startPoint = null;
        ArrayList<Point> originalLinePts = new ArrayList<>();
        
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        ArrayList<Point> expectedResultPts = new ArrayList<>();
        expectedResultPts.add(p3);
        expectedResultPts.add(p6);
     
        
        ArrayList<Liner> sleeveLines = new ArrayList<>();
        int sleeveCounter = 0;
        
        //Sleeve used is 200w x 400h
        Point p80 = new Point("p80,-120,182");
        Point p81 = new Point("p81,-51,370");
        Point p82 = new Point("p82,325,232");
        Point p83 = new Point("p83,256,44");

        sleeveLines.add(new Liner(p80,p81));
        sleeveLines.add(new Liner(p81,p82));
        sleeveLines.add(new Liner(p82,p83));
        sleeveLines.add(new Liner(p83,p81));
        
        startPoint = p3; // Point where sleeve starts from
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> simplifiedLinePtsInSleeve = 
                ls.simplifiedLinePointsInSleeve(startPoint, originalLinePts, 
                        sleeveLines, sleeveCounter);
        simplifiedLinePtsInSleeve.add(p3);
        simplifiedLinePtsInSleeve.add(p6);        
        
        String expectedResult1 = expectedResultPts.get(0).getID();
        String expectedResult2 = expectedResultPts.get(1).getID();
        String result1 = simplifiedLinePtsInSleeve.get(0).getID();
        String result2 = simplifiedLinePtsInSleeve.get(1).getID();
     
        assertEquals(expectedResult1, result1);
        assertEquals(expectedResult2, result2);
        
        int actualNoOfSimplifiedPointsInSleeve = simplifiedLinePtsInSleeve.size();
        int expectedNoOfSimplifiedPtsInSleeve = 2;
        assertEquals(expectedNoOfSimplifiedPtsInSleeve,actualNoOfSimplifiedPointsInSleeve);  
    }
    
   
    /**
     * Test of ramerDouglasPeucker method, of class LineSimplification.
     */
    @Test
    public void testRamerDouglasPeucker() {
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
         //Create Points using contents of dews.csv
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p7);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p12);
        simplifiedLinePts.add(p13);
        
        int perpendicularDistanceTolerance = 100;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> result = ls.ramerDouglasPeucker(originalLinePts,
                perpendicularDistanceTolerance);
        
        String strExpected1 = simplifiedLinePts.get(0).getID();
        String strExpected2 = simplifiedLinePts.get(1).getID();
        String strExpected3 = simplifiedLinePts.get(2).getID();
        String strExpected4 = simplifiedLinePts.get(3).getID();
        String strExpected5 = simplifiedLinePts.get(4).getID();
        String strExpected6 = simplifiedLinePts.get(5).getID();
        
        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();
        String result4 = result.get(3).getID();
        String result5 = result.get(4).getID();
        String result6 = result.get(5).getID();
                
        assertEquals(strExpected1, result1);
        assertEquals(strExpected2, result2);
        assertEquals(strExpected3, result3);
        assertEquals(strExpected4, result4);
        assertEquals(strExpected5, result5);
        assertEquals(strExpected6, result6);
        
        int expectedNoOfPoints = 6;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of visvalingamWhyattSimplified method, of class LineSimplification.
     */
    @Test
    public void testVisvalingamWhyattSimplified() {
        System.out.println("visvalingamWhyattSimplified");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
         //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p7);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p13);
        
        int noOfPointsToKeep = 5;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> result = ls.visvalingamWhyattSimplified(originalLinePts,
                noOfPointsToKeep);
        
        String strExpected1 = simplifiedLinePts.get(0).getID();
        String strExpected2 = simplifiedLinePts.get(1).getID();
        String strExpected3 = simplifiedLinePts.get(2).getID();
        String strExpected4 = simplifiedLinePts.get(3).getID();
        String strExpected5 = simplifiedLinePts.get(4).getID();
        String result1 = result.get(0).getID();
        String result2 = result.get(1).getID();
        String result3 = result.get(2).getID();
        String result4 = result.get(3).getID();
        String result5 = result.get(4).getID();
                
        assertEquals(strExpected1, result1);
        assertEquals(strExpected2, result2);
        assertEquals(strExpected3, result3);
        assertEquals(strExpected4, result4);
        assertEquals(strExpected5, result5);
        
        int expectedNoOfPoints = 5;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

  
    /**
     * Test of lang method, of class LineSimplification.
     */
    @Test
    public void testLang() {
        System.out.println("lang");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
         //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        simplifiedLinePts.add(p1);
        simplifiedLinePts.add(p3);
        simplifiedLinePts.add(p5);
        simplifiedLinePts.add(p7);
        simplifiedLinePts.add(p9);
        simplifiedLinePts.add(p11);
        simplifiedLinePts.add(p13);
        
        
        int perpendicularDistanceTolerance = 100;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> result = new ArrayList<Point>();
        result = new ArrayList<Point>(ls.lang(originalLinePts,perpendicularDistanceTolerance));
       
        String strExpected1 = p1.getID();
        String strExpected2 = p3.getID();
        String strExpected3 = p5.getID();
        String strExpected4 = p7.getID();
        String strExpected5 = p9.getID();
        String strExpected6 = p11.getID();
        String strExpected7 = p13.getID();
        
        String result1 = p1.getID();
        String result2 = p3.getID();
        String result3 = p5.getID();
        String result4 = p7.getID();
        String result5 = p9.getID();
        String result6 = p11.getID();
        String result7 = p13.getID();
                
        assertEquals(strExpected1, result1);
        assertEquals(strExpected2, result2);
        assertEquals(strExpected3, result3);
        assertEquals(strExpected4, result4);
        assertEquals(strExpected5, result5);
        assertEquals(strExpected6, result6);
        assertEquals(strExpected7, result7);
        
        int expectedNoOfPoints = 7;
        int actualNoOfPoints = result.size();
        assertEquals(expectedNoOfPoints, actualNoOfPoints);
    }

    /**
     * Test of isPointInConvexPolygon method, of class LineSimplification.
     */
    @Test
    public void testIsPointInConvexPolygon_PositiveTest() {
        System.out.println("isPointInConvexPolygon_PositiveTest");
        Point pToCheck1 = new Point("p5,150,150");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,100,200");
        Point p3 = new Point("p3,200,200");
        Point p4 = new Point("p4,200,100");
        
        Liner polygonSide1 = new Liner(p1,p2);
        Liner polygonSide2 = new Liner(p2,p3);
        Liner polygonSide3 = new Liner(p3,p4);
        Liner polygonSide4 = new Liner(p4,p1);
        
        ArrayList<Liner> lines = new ArrayList<>();
        lines.add(polygonSide1);
        lines.add(polygonSide2);
        lines.add(polygonSide3);
        lines.add(polygonSide4);
        
        LineSimplification ls = new LineSimplification();
        boolean expResult = true;
        boolean result = ls.isPointInConvexPolygon(pToCheck1, lines);
        assertEquals(expResult, result);
    }

     /**
     * Test of isPointInConvexPolygon method, of class LineSimplification.
     */
    @Test
    public void testIsPointInConvexPolygon_NegativeTest() {
        System.out.println("isPointInConvexPolygon_NegativeTest");
        Point pToCheck2 = new Point("p6,50,50");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,100,200");
        Point p3 = new Point("p3,200,200");
        Point p4 = new Point("p4,200,100");
        
        Liner polygonSide1 = new Liner(p1,p2);
        Liner polygonSide2 = new Liner(p2,p3);
        Liner polygonSide3 = new Liner(p3,p4);
        Liner polygonSide4 = new Liner(p4,p1);
        
        ArrayList<Liner> lines = new ArrayList<>();
        lines.add(polygonSide1);
        lines.add(polygonSide2);
        lines.add(polygonSide3);
        lines.add(polygonSide4);
        
        LineSimplification ls = new LineSimplification();
        boolean expResult = false;
        boolean result = ls.isPointInConvexPolygon(pToCheck2, lines);
        assertEquals(expResult, result);
    }

    
    /**
     * Test of getNoOfIntermediatePts method, of class LineSimplification.
     */
    @Test
    public void testGetNoOfIntermediatePts_PositiveTest() {
        System.out.println("getNoOfIntermediatePts");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        Point p1 = new Point("p1,100,100"); 
        Point p2 = new Point("p2,100,100"); 
        Point p3 = new Point("p3,100,100"); 
        Point p4 = new Point("p4,100,100"); 
        Point p5 = new Point("p5,100,100"); 
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        
        LineSimplification ls = new LineSimplification();
        int expResult = 3;
        int result = ls.getNoOfIntermediatePts(originalLinePts);
        assertEquals(expResult, result);
    }
    
       /**
     * Test of getNoOfIntermediatePts method, of class LineSimplification.
     */
    @Test
    public void testGetNoOfIntermediatePts_NegativeTest() {
        System.out.println("getNoOfIntermediatePts");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        Point p1 = new Point("p1,100,100"); 
        Point p2 = new Point("p2,100,100"); 
        Point p3 = new Point("p3,100,100"); 
        Point p4 = new Point("p4,100,100"); 
        Point p5 = new Point("p5,100,100"); 
        originalLinePts.add(p1);
        
        LineSimplification ls = new LineSimplification();
        int expResult1 = 0;
        int result1 = ls.getNoOfIntermediatePts(originalLinePts);
        assertEquals(expResult1, result1);
        
        originalLinePts.add(p2);
        int expResult2 = 0;
        int result2 = ls.getNoOfIntermediatePts(originalLinePts);
        assertEquals(expResult2, result2);
        
        originalLinePts.add(p3);
        int expResult3 = 1;
        int result3 = ls.getNoOfIntermediatePts(originalLinePts);
        assertEquals(expResult3, result3);  
    }
    

    /**
     * Test of isPointInLine method, of class LineSimplification.
     */
    @Test
    public void testIsPointInLine_PositiveTest() {
        System.out.println("isPointInLine_PositiveTest");
        
        Point p1 = new Point("p1,345,234");
        Point p2 = new Point("p2,450,349");
        Point p3 = new Point("p3,450,450");
        Point p4 = new Point("p4,100,100");
        
        Point pToCheck = new Point("p4,100,100");
        ArrayList<Point> linePts = new ArrayList<>();
        linePts.add(p1);
        linePts.add(p2);
        linePts.add(p3);
        linePts.add(p4);
        
        LineSimplification ls = new LineSimplification();
        boolean expResult = true;
        boolean result = ls.isPointInLine(pToCheck, linePts);
        
        assertEquals(expResult, result);
    }
    
    /**
     * Test of isPointInLine method, of class LineSimplification.
     */
    @Test
    public void testIsPointInLine_NegativeTest() {
        System.out.println("isPointInLine_PositiveTest");
        
        Point p1 = new Point("p1,345,234");
        Point p2 = new Point("p2,450,349");
        Point p3 = new Point("p3,450,450");
        Point p4 = new Point("p4,100,100");
        
        Point pToCheck = new Point("p5,100,100");
        ArrayList<Point> linePts = new ArrayList<>();
        linePts.add(p1);
        linePts.add(p2);
        linePts.add(p3);
        linePts.add(p4);
        
        LineSimplification ls = new LineSimplification();
        boolean expResult = false;
        boolean result = ls.isPointInLine(pToCheck, linePts);
        
        assertEquals(expResult, result);
    }
    
    
    
    /**
     * Test of distanceOfPointPerpendicularToLine method, of class LineSimplification.
     */
    @Test
    public void testDistanceOfPointPerpendicularToLine_PositiveTest() {
        System.out.println("distanceOfPointPerpendicularToLine_PositiveTest");
        Point point = new Point("p3,150,230");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,200");
        Liner line = new Liner(p1,p2);
        LineSimplification ls = new LineSimplification();
        double expResult = 56.57;
        double result = ls.distanceOfPointPerpendicularToLine(point, line);
        assertEquals(expResult, result, 0.001);
    }
    
  /**
     * Test of distanceOfPointPerpendicularToLine method, of class LineSimplification.
     */
    @Test
    public void testDistanceOfPointPerpendicularToLine_NegativeTest() {
        System.out.println("distanceOfPointPerpendicularToLine_NegativeTest");
        Point point = new Point("p3,150,100");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,100");
        Liner line = new Liner(p1,p2);
        LineSimplification ls = new LineSimplification();
        double expResult = 0;
        double result = ls.distanceOfPointPerpendicularToLine(point, line);
        assertEquals(expResult, result, 0.001);  
    }
    
    
    
    
    /**
     * Test of printLineLengthsForPointInList method, of class LineSimplification.
     */
    @Test
    public void testPrintLineLengthsForPointInList() {
        System.out.println("printLineLengthsForPointInList");
        ArrayList<Point> points = new ArrayList<>();
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,100");
        Point p3 = new Point("p3,200,200");
        Point p4 = new Point("p4,100,200");
        points.add(p1);
        points.add(p2);
        points.add(p3);
        points.add(p4);
        
        Liner line1 = new Liner(p1,p2);
        Liner line2 = new Liner(p2,p3);
        Liner line3 = new Liner(p3,p4);
        Liner line4 = new Liner(p4,p1);
        
        double expected1 = line1.getLength();
        double expected2 = line2.getLength();
        double expected3 = line3.getLength();
        double expected4 = line4.getLength();
       
        double actual1 = 100;
        double actual2 = 100;
        double actual3 = 100;
        double actual4 = 100;
        
        LineSimplification ls = new LineSimplification();
        ls.printLineLengthsForPointInList(points);
        assertEquals(expected1, actual1, 0.01);
        assertEquals(expected2, actual2, 0.01);
        assertEquals(expected3, actual3, 0.01);
        assertEquals(expected4, actual4, 0.01);

    }

    /**
     * Test of calcTriangleArea method, of class LineSimplification.
     */
    @Test
    public void testCalcTriangleArea() {
        System.out.println("calcTriangleArea");
        Point point = new Point("p2,150,150");
        Point prevPoint = new Point("p1,100,100");
        Point nextPoint = new Point("p3,200,100");
        LineSimplification ls = new LineSimplification();
        double expResult = 2500.0;
        double result = ls.calcTriangleArea(point, prevPoint, nextPoint);
        assertEquals(expResult, result, 0.001);
    }

    /**
     * Test of drawTriangle method, of class LineSimplification.
     */
    @Test
    public void testDrawTriangle() {
        System.out.println("drawTriangle");
        
//        int xPoints[] = {150,100,200};
//        int yPoints[] = {150,100,100};
//        int noOfPoints = 3;
//        Polygon expectedPolygon = new Polygon(xPoints, yPoints,3);
//        Rectangle rectangle1 = expectedPolygon.getBounds();
        
        int npoints = 3;
        int arraySize = 3;
        LineSimplification ls = new LineSimplification();

        Point intermediatePoint = new Point("p2,150,150");
        Point prevPoint = new Point("p1,100,100");
        Point nextPoint = new Point("p3,200,100");

        Polygon result = ls.drawTriangle(intermediatePoint, prevPoint, nextPoint,
                npoints, arraySize);
        Rectangle rectangle2 = result.getBounds();
        
        double expectedMaxX = 200; 
        double expectedMaxY = 500; // NB Y was adjusted in drawTriangle for screen
        double expectedMinX = 100; 
        double expectedMinY = 450; // NB Y was adjusted in drawTriangle for screen
        
        double resultMaxX = rectangle2.getMaxX();
        double resultMaxY = rectangle2.getMaxY();
        double resultMinX = rectangle2.getMinX();
        double resultMinY = rectangle2.getMinY();
        
        assertEquals(expectedMaxX, resultMaxX, 0.01);
        assertEquals(expectedMaxY, resultMaxY, 0.01);
        assertEquals(expectedMinX, resultMinX, 0.01);
        assertEquals(expectedMinY, resultMinY, 0.01);
    }

    /**
     * Test of maximumDistance method, of class LineSimplification.
     */
    @Test
    public void testMaximumDistance() {
        System.out.println("maximumDistance");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        
         //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        int noOfPointsToKeep = 2;
        LineSimplification ls = new LineSimplification(); 
        simplifiedLinePts = ls.visvalingamWhyattSimplified(originalLinePts,
                noOfPointsToKeep);
        Point linePoint1 = simplifiedLinePts.get(0);
        Point linePoint2 = simplifiedLinePts.get(simplifiedLinePts.size()-1);
        Liner line = new Liner(linePoint1,linePoint2);
        
        double resultMaxDistance = ls.maximumDistance(originalLinePts, line);
        double actualMaxDistance = 326.19;
        assertEquals(resultMaxDistance, actualMaxDistance, 0.001);

    }
    
    
    /**
     * Test of get Points In Circle method, of class LineSimplification.
     */
    @Test
    public void testGetPointsInCircle() {
        System.out.println("getPointsInCircle");
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> pts = new ArrayList<Point>();
        ArrayList<Point> returnedPoints = new ArrayList<>();
           
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        pts.add(p1);
        pts.add(p2);
        pts.add(p3);
        pts.add(p4);
        pts.add(p5);
        pts.add(p6);
        pts.add(p7);
        pts.add(p8);
        pts.add(p9);
        pts.add(p10);
        pts.add(p11);
        pts.add(p12);
        pts.add(p13);
        
        double radius = 75;
        Point point = p1;
        returnedPoints = ls.getPointsInCircle(pts, radius, point);
        
        //Check points that are in the given circle (defined by given radius).
        Point returnedPoint1 = returnedPoints.get(0);
        Point returnedPoint2 = returnedPoints.get(1);
        String expected1 = "p1";
        String expected2 = "p2";
        String result1 = returnedPoint1.getID();
        String result2 = returnedPoint2.getID();
        assertEquals(expected1, result1);
        assertEquals(expected2, result2);
        
        //Check no of points returned is as expected
        int expectedSize = 2; 
        int returnedSize = returnedPoints.size();
        assertEquals(expectedSize, returnedSize);
    }
    
  
    
}
