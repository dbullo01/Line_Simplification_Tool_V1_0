/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.awt.Polygon;
import java.util.ArrayList;
import java.util.List;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Line Performance Test
 * 
 * @author Davison Bullock
 * version (28/07/2016)
 */
public class LinePerformanceTest {
    
    public LinePerformanceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
         //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
   

    /**
     * Test of isLineSegmentsIntersecting2 method, of class LinePerformance.
     */
    @Test
    public void testIsLineSegmentsIntersecting2() {
        System.out.println("isLineSegmentsIntersecting2");
        Point p1 = new Point("p6,241,409");
        Point p2 = new Point("p11,523,406");
        Point p3 = new Point("p7,321,442");
        Point p4 = new Point("p8,358,323");
        
        Liner line1 = new Liner(p1,p2);
        Liner line2 = new Liner(p3,p4);
        LinePerformance lp = new LinePerformance();
        Point expResult = new Point("p999,331,408");
        Point result = lp.isLineSegmentsIntersecting2(line1, line2);
        
        String expResult_PtID = expResult.getID();
        int expResult_X = expResult.getX();
        int expResult_Y = expResult.getY();
        
        String result_PtID = result.getID();
        int result_X = result.getX();
        int result_Y = result.getY();   
                
        assertEquals(expResult_PtID, result_PtID);
        assertEquals(expResult_X, result_X);
        assertEquals(expResult_Y, result_Y);
    }

    /**
     * Test of vectorDisplacementError method, of class LinePerformance.
     */
    @Test
    public void testVectorDisplacementError() {
        System.out.println("vectorDisplacementError");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        
        //Create Points like what is in dews.csv
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
    
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        int n = 3;
        LineSimplification ls = new LineSimplification();
        simplifiedLinePts = ls.nthPoint(originalLinePts,n);
        
        LinePerformance lp = new LinePerformance();
        ArrayList<Liner> result = lp.vectorDisplacementError(originalLinePts,
                simplifiedLinePts);
        double resultLine1Length = result.get(0).getLength();
        double resultLine2Length = result.get(1).getLength();
        double resultLine3Length = result.get(2).getLength();
        double resultLine4Length = result.get(3).getLength();
        double resultLine5Length = result.get(4).getLength();
        double resultLine6Length = result.get(5).getLength();
        double resultLine7Length = result.get(6).getLength();
        double resultLine8Length = result.get(7).getLength();
     
        
        double expectedLine1Length = 4.12;
        double expectedLine2Length = 4.12;
        double expectedLine3Length = 1.0;
        double expectedLine4Length = 13.04; 
        double expectedLine5Length = 46.86; 
        double expectedLine6Length = 107.94;
        double expectedLine7Length = 142.13; 
        double expectedLine8Length = 137.89; 
       
        
        assertEquals(expectedLine1Length, resultLine1Length, 0.01);
        assertEquals(expectedLine2Length, resultLine2Length, 0.01);
        assertEquals(expectedLine3Length, resultLine3Length, 0.01);
        assertEquals(expectedLine4Length, resultLine4Length, 0.01);
        assertEquals(expectedLine5Length, resultLine5Length, 0.01);
        assertEquals(expectedLine6Length, resultLine6Length, 0.01);
        assertEquals(expectedLine7Length, resultLine7Length, 0.01);
        assertEquals(expectedLine8Length, resultLine8Length, 0.01);
        
        double expectedSumOfSimplifiedLineSegments = 887.28;
        double actualSumOfSimplifiedLineSegments = 
              lp.getSumOfSimplifiedLineSegments();

        double expectedMaxDistortionLineDistance = 142.02;
        double actualMaxDistortionLineDistance =
              lp.getMaxDistortionDistance();
        
        double expectedMeanDistortionLineDistance = 57.14;
        double actualMeanDistortionLineDistance =lp.getMeanDistortionDistance();
        
        double expectedStandardDeviationDistortionDistance = 58.25;
        double actualStandardDeviationDistortionDistance = 
                lp.getStandardDeviationDistortionDistance();
                
        int expectedNoOfDistortionLines = 8;
        int actualNoOfDistortionLines = lp.getNoOfDistortionLines();
        
        double expectedSumOfDistortionLineDistance = 457.10; 
        double actualSumOfDistortionLineDistance = 
            lp.getSumOfDistortionLineLengths();
        
        double expectedStandardizedVectorDisplacement = 0.515171;
        double actualStandardizedVectorDisplacement =
                Double.parseDouble(lp.getStandardizedVectorDisplacement());
     
        assertEquals(expectedSumOfSimplifiedLineSegments, 
                actualSumOfSimplifiedLineSegments, 0.01);
        
        assertEquals(expectedMaxDistortionLineDistance, 
                actualMaxDistortionLineDistance, 0.01);
        
        assertEquals(expectedMeanDistortionLineDistance, 
                actualMeanDistortionLineDistance, 0.01);
      
        assertEquals(expectedStandardDeviationDistortionDistance, 
                actualStandardDeviationDistortionDistance, 0.01);
      
        assertEquals(expectedNoOfDistortionLines, 
                actualNoOfDistortionLines, 0.01);

        assertEquals(expectedSumOfDistortionLineDistance, 
                actualSumOfDistortionLineDistance, 0.01);
        
        assertEquals(expectedStandardizedVectorDisplacement,
                actualStandardizedVectorDisplacement,0.01);
    }
    /**
     * Test of areaDisplacementError method, of class LinePerformance.
     */
    @Test
    public void testAreaDisplacementError() {
        System.out.println("areaDisplacementError");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
        
       
          //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
    
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        LineSimplification ls = new LineSimplification();
        int n = 4; 
        simplifiedLinePts = ls.nthPoint(originalLinePts, n);
        LinePerformance lp = new LinePerformance();
        ArrayList<Polygon> result = lp.areaDisplacementError(originalLinePts,
                simplifiedLinePts);
        
        double expectedSumLineSegmentLengths =  793.66; 
        double expectedSumLeftPolygonAreas = 65509.0;
        double expectedSumRightPolygonAreas = 0;
        double expectedSumPolygonAreas = 65509.0; 
        double expectedUniformDistortion = 82.54;
        double expectedNoOfPolygons = result.size();
      
        double actualSumLineSegmentLengths = lp.sumLineSegmentLengths(
                simplifiedLinePts); 
        double actualSumLeftPolygonAreas = lp.getSumLeftPolygonAreas();
        double actualSumRightPolygonAreas = lp.getSumRightPolygonAreas();
        double actualSumPolygonAreas = lp.getSumPolygonAreas(); 
        double actualUniformDistortion = lp.getUniformDistortion();
        double actualNoOfPolygons = result.size();
        
        assertEquals(expectedSumLineSegmentLengths, 
                actualSumLineSegmentLengths, 0.01);
        assertEquals(expectedSumLeftPolygonAreas,actualSumLeftPolygonAreas,0.01);
        assertEquals(expectedSumRightPolygonAreas, 
                actualSumRightPolygonAreas, 0.01);
        assertEquals(expectedSumPolygonAreas, actualSumPolygonAreas, 0.01);
        assertEquals(expectedUniformDistortion, actualUniformDistortion,0.01);
        assertEquals(expectedNoOfPolygons, actualNoOfPolygons,0.01);

    }

    /**
     * Test of splitPolygon method, of class LinePerformance.
     */
    @Test
    public void testSplitPolygon() {
        System.out.println("splitPolygon");
        ArrayList<Point> polygonList = new ArrayList<>();
        
        //From dews.csv with polygons formed when nth Point = 5
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p999 = new Point("p999,331,408"); // Intersection point
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
          
        polygonList.add(p6);
        polygonList.add(p7);
        polygonList.add(p999);
        polygonList.add(p8);
        polygonList.add(p9);
        polygonList.add(p10);
        polygonList.add(p11);
        polygonList.add(p6);
        
        LinePerformance lp = new LinePerformance();
        ArrayList<ArrayList<Point>> result = lp.splitPolygon(polygonList);
        
        ArrayList<Point> polygon1 = result.get(0);
        ArrayList<Point> polygon2 = result.get(1);
        
        String expectedPolygon1Pt1 = polygon1.get(0).getID();
        String expectedPolygon1Pt2 = polygon1.get(1).getID();
        String expectedPolygon1Pt3 = polygon1.get(2).getID();
        String expectedPolygon1Pt4 = polygon1.get(3).getID();
        
        String resultPolygon1Pt1 = "p6";
        String resultPolygon1Pt2 = "p7";
        String resultPolygon1Pt3 = "p999";
        String resultPolygon1Pt4 = "p6";
        
        String expectedPolygon2Pt1 = polygon2.get(0).getID();
        String expectedPolygon2Pt2 = polygon2.get(1).getID();
        String expectedPolygon2Pt3 = polygon2.get(2).getID();
        String expectedPolygon2Pt4 = polygon2.get(3).getID();
        String expectedPolygon2Pt5 = polygon2.get(4).getID();
        String expectedPolygon2Pt6 = polygon2.get(5).getID();
        
        String resultPolygon2Pt1 = "p999";
        String resultPolygon2Pt2 = "p8";
        String resultPolygon2Pt3 = "p9";
        String resultPolygon2Pt4 = "p10";
        String resultPolygon2Pt5 = "p11";
        String resultPolygon2Pt6 = "p999";
        
        assertEquals(expectedPolygon2Pt1, resultPolygon2Pt1);
        assertEquals(expectedPolygon2Pt2, resultPolygon2Pt2);
        assertEquals(expectedPolygon2Pt3, resultPolygon2Pt3);
        assertEquals(expectedPolygon2Pt4, resultPolygon2Pt4);
        assertEquals(expectedPolygon2Pt5, resultPolygon2Pt5);
        assertEquals(expectedPolygon2Pt6, resultPolygon2Pt6);
    }

    /**
     * Test of removeDuplicatePoints method, of class LinePerformance.
     */
    @Test
    public void testRemoveDuplicatePoints() {
        System.out.println("removeDuplicatePoints");
        ArrayList<Point> originalLinePts = new ArrayList<>();
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,190,113"); 
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p1);
        originalLinePts.add(p3);
        originalLinePts.add(p9);
        originalLinePts.add(p9);
        originalLinePts.add(p1);
        originalLinePts.add(p9);
  
        LinePerformance lp = new LinePerformance();
        ArrayList<Point> result = lp.removeDuplicatePoints(originalLinePts);
        
        int expectedNoOfElements = 4;
        int resultNoOfElements = result.size();
        assertEquals(expectedNoOfElements, resultNoOfElements);
                
        String resultPoint1 = result.get(0).getID();
        String resultPoint2 = result.get(1).getID();
        String resultPoint3 = result.get(2).getID();
        String resultPoint4 = result.get(3).getID();

        assertEquals(p1.getID(), resultPoint1);
        assertEquals(p2.getID(), resultPoint2);
        assertEquals(p3.getID(), resultPoint3);
        assertEquals(p9.getID(), resultPoint4);
    }

    /**
     * Test of calculateIntersectionPointBetweenTwoLines method, of
     * class LinePerformance.
     */
    @Test
    public void testCalculateIntersectionPointBetweenTwoLines() {
        System.out.println("calculateIntersectionPointBetweenTwoLines");
        ArrayList<Point> polygonList = new ArrayList<>();
        
        // Test case - Self intersecting polygon formed from nth point tolerance = 5
        // from the dews.csv file
        polygonList.add(new Point("p6,241,409"));
        polygonList.add(new Point("p7,321,442"));
        polygonList.add(new Point("p8,358,323"));
        polygonList.add(new Point("p9,447,119"));
        polygonList.add(new Point("p10,479,250"));
        polygonList.add(new Point("p11,523,406"));
        polygonList.add(new Point("p6,241,409"));
        
        LinePerformance lp = new LinePerformance();
        ArrayList<Point> expResult = polygonList;
        ArrayList<Point> result =
                lp.calculateIntersectionPointBetweenTwoLines(polygonList);
         
        String expectedIntersectionPoint_PtID = "p999";
        int expectedIntersectionPoint_X = 331;
        int expectedIntersectionPoint_Y = 408;
        String resultIntersectionPoint_PtID = result.get(2).getID();
        int resultIntersectionPoint_X = result.get(2).getX();
        int resultIntersectionPoint_Y = result.get(2).getY();
        
        assertEquals(expectedIntersectionPoint_PtID, resultIntersectionPoint_PtID);
        assertEquals(expectedIntersectionPoint_X, resultIntersectionPoint_X);
        assertEquals(expectedIntersectionPoint_Y, resultIntersectionPoint_Y);
        assertEquals(expResult, result);
  
    }

    /**
     * Test of indexPositionOfPointOfIntersection method, of class LinePerformance.
     */
    @Test
    public void testIndexPositionOfPointOfIntersection() {
        System.out.println("indexPositionOfPointOfIntersection");
        ArrayList<Point> polygonList = new ArrayList<>();
        Point p1 = new Point("p1,100,300");
        Point p2 = new Point("p2,80,120");
        Point p3 = new Point("p3,325,350");
        Point p4 = new Point("p4,350,150");
        Point p5 = new Point("p1,100,300");
        polygonList.add(p1);
        polygonList.add(p2);
        polygonList.add(p3);
        polygonList.add(p4);
        polygonList.add(p5);
        
        //Add point to create a self intersecting polygon (polygonList)
        LinePerformance lp = new LinePerformance();
        int expResult = 2;
        int result = lp.indexPositionOfPointOfIntersection(polygonList);
        assertEquals(expResult, result);
  
    }

    

    /**
     * Test of calculateUniformDistortion method, of class LinePerformance.
     */
    @Test
    public void testCalculateUniformDistortion() {
        System.out.println("calculateUniformDistortion");
        
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        double sumPolygonAreas = 142811.0;
        int n = 4;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> simplifiedLinePts = ls.nthPoint(originalLinePts,n);
        
        LinePerformance lp = new LinePerformance();
        double expResult = 179.94;
        double result = 
                lp.calculateUniformDistortion(sumPolygonAreas, simplifiedLinePts);
        assertEquals(expResult, result, 179.94);
    }

    /**
     * Test of createPerpendicularPoint method, of class LinePerformance.
     */
    @Test
    public void testCreatePerpendicularPoint() {
        System.out.println("createPerpendicularPoint");
        Point intermediatePoint = new Point("p1,150,230");
        Point startPoint = new Point("p2,100,100");
        Point endPoint = new Point("p3,200,200");
        LinePerformance lp = new LinePerformance();
        String result = 
                lp.createPerpendicularPoint(intermediatePoint,
                        startPoint, endPoint);
        String expResult = "190,190";
        assertEquals(expResult, result);
    }

    
    
    /**
     * Test of ratioInChangeOfAngularity method, of class LinePerformance.
     */
    @Test
    public void testRatioInChangeOfAngularity() {
        System.out.println("ratioInChangeOfAngularity");
         //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        LineSimplification ls = new LineSimplification();
        int noOfPtsToKeep = 6;
        ArrayList<Point> simplifiedLinePts =
     new ArrayList<>(ls.visvalingamWhyattSimplified(originalLinePts, 
             noOfPtsToKeep));
        LinePerformance lp = new LinePerformance();
        double expResult = 88.0;
        double result = lp.ratioInChangeOfAngularity(originalLinePts,
                simplifiedLinePts);
        assertEquals(expResult, result, 88.0);

    }

    /**
     * Test of percentageChangeInNumberOfCoordinates method,
     * of class LinePerformance.
     */
    @Test
    public void testPercentageChangeInNumberOfCoordinates(){
        System.out.println("percentageChangeInNumberOfCoordinates");        
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
          //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        int n = 3;
        //Using nth point to test - Should only have 5 points left   
        //5/13*100 = 38  
        //100 - 38 = 62% is the expected result
        LineSimplification ls = new LineSimplification();
        simplifiedLinePts = ls.nthPoint(originalLinePts, n);
       
        LinePerformance lp = new LinePerformance();
        double expResult = 62.0;
        double result = lp.percentageChangeInNumberOfCoordinates(originalLinePts,
                simplifiedLinePts);
        assertEquals(expResult, result, 62.0);
    }
    
    /**
     * Test of percentageChangeInLineLengths method,
     * of class LinePerformance.
     */
    @Test
    public void testPercentageChangeInLineLengths(){
        System.out.println("percentageChangeInLineLengths");        
        ArrayList<Point> simplifiedLinePts = new ArrayList<>();
       
          //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        int n = 3;
        //Using nth point to test - Should only have 5 points left   
        //37.59 is the expected percentage decrease result
        LineSimplification ls = new LineSimplification();
        simplifiedLinePts = ls.nthPoint(originalLinePts, n);
       
        LinePerformance lp = new LinePerformance();
        double expResult = 37.59;
        double result = lp.percentageChangeInLineLengths(originalLinePts,
                simplifiedLinePts);
        assertEquals(expResult, result, 0.01);
    }
    

    /**
     * Test of isPointRightOfLine method, of class LinePerformance.
     */
    @Test
    public void testIsPointRightOfLine(){
        System.out.println("isPointRightOfLine");
        Point p1 = new Point("p1,100,100");
        Point p2 = new Point("p2,200,200");
        Liner line = new Liner(p1,p2);
        
        //Create Points
        Point actualPointRightOfLine = new Point("p3,150,120");
        Point actualPointLeftOfLine = new Point("p4,150,230");
                    
        LinePerformance lp = new LinePerformance();
        boolean expResult1 = true;
        boolean result1 = lp.isPointRightOfLine(actualPointRightOfLine, line);
        assertEquals(expResult1, result1);
        
        boolean expResult2 = false;
        boolean result2 = lp.isPointRightOfLine(actualPointLeftOfLine, line);
        assertEquals(expResult2, result2);
    }
   
    
     /**
     * Test of calculatePolygonAreas method, of class LinePerformance.
     */
    @Test
    public void testCalculatePolygonAreas(){
        System.out.println("calculatePolygonAreas");
        double expectedSumPolygonArea = 142811.0;
        
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
   
        ArrayList<Point> originalLinePts = new ArrayList<>();
        originalLinePts.add(p1);
        originalLinePts.add(p2);
        originalLinePts.add(p3);
        originalLinePts.add(p4);
        originalLinePts.add(p5);
        originalLinePts.add(p6);
        originalLinePts.add(p7);
        originalLinePts.add(p8);
        originalLinePts.add(p9);
        originalLinePts.add(p10);
        originalLinePts.add(p11);
        originalLinePts.add(p12);
        originalLinePts.add(p13);
        
        ArrayList<ArrayList<Point>> polygonLists =
                new ArrayList<ArrayList<Point>>();
        ArrayList<Point> subList1 = new ArrayList<>();
        ArrayList<Point> subList2 = new ArrayList<>();
        ArrayList<Point> subList3 = new ArrayList<>();
        
        subList1.add(p1);
        subList1.add(p2);
        subList1.add(p3);
        subList1.add(p4);        
        subList1.add(p5);
        
        subList2.add(p5);
        subList2.add(p6);
        subList2.add(p7); 
        subList2.add(p8);
        subList2.add(p9);
        
        subList3.add(p9);
        subList3.add(p10);
        subList3.add(p11); 
        subList3.add(p12);
        subList3.add(p13);
        
        polygonLists.add(subList1);
        polygonLists.add(subList2);
        polygonLists.add(subList3);
        
        //Create polygon areas from the originalLinePts and simplifiedLinePts
        int n  = 4;
        LineSimplification ls = new LineSimplification();
        ArrayList<Point> simplifiedLinePts = ls.nthPoint(originalLinePts,n);
        
        LinePerformance lp = new LinePerformance();
        double result = lp.calculatePolygonAreas(polygonLists, simplifiedLinePts);
        assertEquals(expectedSumPolygonArea, result, 0.001);
       
    }
    
    
    
    
    /**
     * Test of SumLineSegmentLength method, of class LinePerformance.
     * 
     */
    @Test
    public void testSumLineSegmentLength(){
        System.out.println("sumLineSegmentLengths");
        ArrayList<Point> pts = new ArrayList<>();
        
        //Create Points
        Point p1 = new Point("p1,68,113");
        Point p2 = new Point("p2,79,143");
        Point p3 = new Point("p3,101,247");
        Point p4 = new Point("p4,111,315");                
        Point p5 = new Point("p5,182,359");
        Point p6 = new Point("p6,241,409");
        Point p7 = new Point("p7,321,442");
        Point p8 = new Point("p8,358,323");
        Point p9 = new Point("p9,447,119");
        Point p10 = new Point("p10,479,250");
        Point p11 = new Point("p11,523,406");
        Point p12 = new Point("p12,613,312");
        Point p13 = new Point("p13,612,119");
        
        pts.add(p1);
        pts.add(p2);
        pts.add(p3);
        pts.add(p4);
        pts.add(p5);
        pts.add(p6);
        pts.add(p7);
        pts.add(p8);
        pts.add(p9);
        pts.add(p10);
        pts.add(p11);
        pts.add(p12);
        pts.add(p13);
      
        LinePerformance lp = new LinePerformance();
        double expected = 1421.66;
        double result = lp.sumLineSegmentLengths(pts);
        assertEquals(expected, result, 0.01);
    }
    
    
    
}
