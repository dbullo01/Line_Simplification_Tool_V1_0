/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.util.Scanner;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * Point
 * 
 * This class is used to store the ID and location of points. 
 * @author Davison Bullock
 * @version (01/05/2016)
 */
public class Point
{

    private String id;
    private int  x;
    private int y;

    /**
     * Instantiates a new Point class.
     *
     * @param s  - A string that contains comma delimited point data as follows:
     *             id,x,y.  Where x,y are the coordinates of the points and id 
     *             is the identifier of the Point. 
     */
    public Point(String s) throws IndexOutOfBoundsException
    {
        Scanner in = new Scanner(s);
        in.useDelimiter(",");
        id = in.next();
        x = in.nextInt();
        y = in.nextInt();
    }

    /**
     * Gets the Point id.
     *
     * @return Point id - Value presenting the points id.
     */
    public String getID(){
        return id;
    }

    /**
     * Gets PointX Coordinate.
     *
     * @return x-coordinate - Value representing a points x coordinate.
     */

    public int getX(){
        return x;
    }

    /**
     * Gets PointY Coordinate.
     *
     * @return y-coordinate - Value representing a points y coordinate
     */
    public int getY(){
        return y;
    }

    /**
     * Sets Point X Coordinate.
     * 
     * @param x - Value representing the points x coordinate
     */
    public void setX(int x){
        this.x = x;
        
    }
    
    /**
     * Sets Point Y Coordinate. 
     * @param y - Value representing the points y coordinate
     */
    public void setY(int y){
        this.y = y;
        
    }
    
     /**
     * Sets Point ID.  
     *
     * @param id - Value representing the points id
     */
    public void setID(String id){
        this.id = id;
        
    }
    
    
    /**
     *  Load Original Line Points
     * 
     *  Scans through a file to find and load Point data.
     *  @param file - File to load line data from
     *  @return points. - Points representing original line points
     *  @throws java.io.FileNotFoundException
     *  
     */   

   public static ArrayList<Point> loadOriginalPts(File file) 
           throws FileNotFoundException{
        ArrayList<Point> originalPts = new ArrayList<>();
        try (Scanner in = new Scanner(file)) {     
            while(in.hasNextLine()){
                String str = in.nextLine();
                originalPts.add(new Point(str));
            }
        }
        return(originalPts);        
    } 
   
    
    /**
     * Displays a Point. The Point is represented by a black oval.
     *
     * @param g A Graphics object onto which the Point is drawn. 
     */
    public void DisplayPoint(Graphics g){
        g.setColor(Color.RED);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 15));
        g.drawString("   " + id,x,600-y);
        g.setColor(Color.BLACK);
        g.fillOval(x-5, 600-y-5, 12,12); 
      
    }
}
