/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;


import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.awt.Polygon;
import javax.swing.*;

/**
 * Write a description of class LineSimplification here.
 * 
 * @author (Davison Bullock) 
 * @version (1.0) 20-10-2015
 */
public class LineSimplification extends JComponent{
    private ArrayList<Liner> perpendicularLines;
    private ArrayList<Liner> simplifiedLines;
    private ArrayList<Point> originalLinePts;
    private ArrayList<Point> simplifiedLinePts;  
    private ArrayList<Polygon> effectiveAreaTriangles;
    private ArrayList<ArrayList<Liner>> sleevesList; 
    private int noOfPoints;
    private int nthpoint;
    private double height;
    private double width;
    private double perpendicularDistanceTolerance;
    private double radialDistanceTolerance;
    private double effectiveArea;
    private ArrayList<ArrayList<Point>> simplifiedLineSegmentList;
    private ArrayList<Liner> pointList1DistortionLines;
    private ArrayList<Liner> pointList2DistortionLines;
    
    /**
     * Constructor for objects of class LineSimplification
     */
    public LineSimplification(){
        // initialise instance variables
        this.perpendicularLines = null;
        this.simplifiedLinePts = null;
        this.simplifiedLines = null;
        this.originalLinePts = null;
        this.effectiveAreaTriangles = null;
        this.sleevesList = null;     
        this.noOfPoints = 0;
        this.nthpoint = 0;
        this.height = 0;
        this.width = 0;
        this.perpendicularDistanceTolerance = 0;
        this.radialDistanceTolerance = 0;
        this.effectiveArea = 0;
        this.simplifiedLineSegmentList = null;       
        this.pointList1DistortionLines = null;
        this.pointList2DistortionLines = null;
    }
    
    /**
     * Get Point List 1 Distortion Lines
     * @return pointList1DistortionLines - Lines representing distortion lines
     */
    public ArrayList<Liner> getPointList1DistortionLines(){
        return this.pointList1DistortionLines;
    }
    
    /**
     * Get Point List 1 Distortion Lines 
     * @param pointList1DistortionLines - Lines representing distortion lines 
     */
    public void setPointList1DistortionLines(ArrayList<Liner> 
            pointList1DistortionLines){
        this.pointList1DistortionLines = pointList1DistortionLines;
    }
    
    /**
     * Get Point List 2 Distortion Lines
     * @return pointList2DistortionLines - Lines representing distortion lines
     */
    public ArrayList<Liner> getPointList2DistortionLines(){
        return this.pointList2DistortionLines;
    }
    
    /**
     * Set Point List 2 Distortion Lines 
     * @param pointList2DistortionLines - Lines representing distortion lines 
     */
    public void setPointList2DistortionLines(ArrayList<Liner> 
            pointList2DistortionLines){
        this.pointList2DistortionLines = pointList2DistortionLines;
    }
       
    
    /**
     * Get Simplified Line Segment List
     * @return simplifiedLineSegmentList - Collection of point Lists each list
     * represents simplified line segment 
     */
    public ArrayList<ArrayList<Point>> getSimplifiedLineSegmentList(){
        return this.simplifiedLineSegmentList;
    }
    
    /**
     * Simplified Line Segment List
     * @param simplifiedLineSegmentList - Collection of point lists each list
     * represents simplified line segment
     */
    public void setSimplifiedLineSegmentList(ArrayList<ArrayList<Point>>
            simplifiedLineSegmentList){
         this.simplifiedLineSegmentList = simplifiedLineSegmentList;
    }

    /**
     * Get Sleeves List
     * @return sleeveList - Collection representing lists of lists.
     * Each list represents the lines in a sleeve
     */
    public ArrayList<ArrayList<Liner>> getSleevesList(){
        return this.sleevesList;
    }
    
    /**
     * Set Sleeves List 
     * @param sleevesList - Collection representing lists of lists.
     * Each list represents the lines in a sleeve
     */
    public void setSleevesList(ArrayList<ArrayList<Liner>>sleevesList){
        this.sleevesList = sleevesList;
    }
     
    /**
     * Get Effective Area Triangles
     * @return effectiveAreaTriangles - Collection representing polygons 
     * representing effective Area triangles
     */
    public ArrayList<Polygon> getEffectiveAreaTriangles(){
        return this. effectiveAreaTriangles;
    }
    
    /**
     * Set Effective Area Triangles
     * @param effectiveAreaTriangles - Collection representing polygons 
     * representing effective Area triangles
     */
    public void setEffectiveAreaTriangles(ArrayList<Polygon> 
            effectiveAreaTriangles){
        this.effectiveAreaTriangles = effectiveAreaTriangles; 
    }
    
    /**
     * Get no of points
     * @return noOfPoints - Value representing the no of points tolerance 
     */
    public int getNoOfPoints(){
         return this.noOfPoints;
    }
     
    /**
     * Set no of points
     * @param noOfPoints - Value representing the no of points tolerance 
     */
     public void setNoOfPoints(int noOfPoints){
         this.noOfPoints = noOfPoints;
     }
     
     /**
      * Get nth Point 
      * @return nthPoint - Value representing the nth Point tolerance
      */
     public int getNthPoint(){
         return this.nthpoint;
     }
     
     /**
      * Set nth Point
      * @param nthpoint - Value representing the nth Point tolerance 
      */
     public void setNthPoint(int nthpoint){
         this.nthpoint = nthpoint;
     }
     
     /**
      * Get Heights
      * @return height - Value representing the height
      */
     public double getHeights(){
         return this.height;
     }
     
     /**
      * Set Heights
      * @param height - Value representing the height 
      */
     public void setHeights(double height){
         this.height = height;
     }
     
     /**
      * Get Widths
      * @return width - Value representing the width 
      */
     public double getWidths(){
         return this.width;
     }
     
     /**
      * Set Widths 
      * @param width - Value representing the width
      */
     public void setWidths(double width){
         this.width = width;
     }
     
     /**
      * Get Perpendicular Distance Tolerance
      * @return perpendicularDistanceTolerance - Value representing the 
      * perpendicular distance tolerance
      */
     public double getPerpendicularDistanceTolerance(){
         return this.perpendicularDistanceTolerance;
     }
     
     /**
      * Set Perpendicular Distance Tolerance
      * @param perpendicularDistanceTolerance - Value representing the
      * perpendicular distance tolerance
      */
     public void setPerpendicularDistanceTolerance(double 
             perpendicularDistanceTolerance){
         this.perpendicularDistanceTolerance = perpendicularDistanceTolerance;
         
     }
     
     /**
      * Get Radial Distance
      * @return radialDistanceTolerance - Value representing the 
      * radial distance tolerance
      */
     public double getRadialDistanceTolerance(){
         return this.radialDistanceTolerance;
     }
    
     /**
      * Set Radial Distance Tolerance
      * @param radialDistanceTolerance - Value representing the radial distance
      * tolerance
      */
     public void setRadialDistanceTolerance(double radialDistanceTolerance){
         this.radialDistanceTolerance = radialDistanceTolerance;
     }
    
     /**
      * Get Effective Area
      * @return effectiveArea - Value representing the effective area
      */
     public double getEffectiveArea(){
         return this.effectiveArea;
     }
    
     /**
      * Set Effective Area
      * @param effectiveArea - Value representing the effective area 
      */
     public void setEffectiveArea(double effectiveArea){
         this.effectiveArea = effectiveArea;
     }
   
     /**
      * Get Original Line Pts
      * @return originalLinePts - Points representing the original line points
      */
     public ArrayList<Point> getOriginalLinePts(){
        return this.originalLinePts;
    }
    
     /**
      * Set Original Line Pts
      * @param originalLinePts - Points representing the original line points  
      */
    public void setOriginalLinePts(ArrayList<Point> originalLinePts){
        this.originalLinePts = originalLinePts;
    }
    
    /**
     * Get Simplified Line Pts
     * @return simplified Line Pts - Points representing the simplified line
     * points
     */
    public ArrayList<Point> getSimplifiedLinePts(){
        return this.simplifiedLinePts;
    }
    
    /**
     * Set Simplified Line Pts 
     * @param simplifiedLinePts - Points representing the simplified line points 
     */
    public void setSimplifiedLinePts(ArrayList<Point> simplifiedLinePts){
        this.simplifiedLinePts = simplifiedLinePts;
    }
    
    /**
     * Get Simplified Lines
     * @return simplifiedLines - Value representing simplified lines  
     */
    public ArrayList<Liner> getSimplifiedLines(){
        return this.simplifiedLines;
    }
    
    /**
     * Set Simplified Lines
     * @param simplifiedLines - Value representing simplified lines
     */
     public void setSimplifiedLines(ArrayList<Liner> simplifiedLines){
        this.simplifiedLines = simplifiedLines;
    }
    
    /**
      * 
      * @return 
      */
    public ArrayList<Liner> getPerpendicularLines(){
        return this.perpendicularLines;
    }
    
    /**
     * Set Perpendicular Distance Lines
     * @param perpendicularLines - Value representing perpendicular lines 
     */
    public void setPerpendicularLines(ArrayList<Liner> perpendicularLines){
        this.perpendicularLines = perpendicularLines;
    }
     

    /**
     * Check no of points
     * 
     * Called by nthPoint method
     * 
     * Checks that the minimum required no of points for a line is correct for
     * the selected algorithm
     * @param nameOfAlgorithm - Name of Algorithm to check points for 
     * @param points - Point representing line to check
     * @param noOfReqPoints - Value representing the number of points required
     *                        for the algorithm
     * @return true or false - Returns true or false if the no of points in the
     *                         point collection is within the bounds set for the
     *                         named algorithm
     */
    public boolean checkNoOfPoints(String nameOfAlgorithm, 
            ArrayList<Point> points, int noOfReqPoints){
        boolean isNoOfPtsOkay = true;
        if (points.size() < noOfReqPoints){
            System.out.println(nameOfAlgorithm + " requires a line with at least "
                    + noOfReqPoints + " points");
            isNoOfPtsOkay = false;
        }
        return isNoOfPtsOkay;
    }

    
    /**
     * 1. nthPoint Line Simplification 
     * 
     * Type: Independent Point Algorithm
     * 
     * Starting at the second point of poly line remove every nth point, where 
     * n is specified by the user
     * 
     * @param  originalLinePts - Points representing the original line points 
     * @param  n - Value representing the nth points to keep
     * @return simplifiedLinePts - Points representing the simplified line  
     */
    public ArrayList<Point> nthPoint(ArrayList<Point> originalLinePts, int n){
        setNthPoint(n);
        setSimplifiedLinePts(new ArrayList<>());
        setOriginalLinePts(originalLinePts);

        //Check that input line has at least 3 points
        if(checkNoOfPoints("nth Point", getOriginalLinePts(), 3)){
            //Get end point from originalLinePts and add to simplifiedlinePts if
            //it has not already been added above
            Point endPoint =
                    getOriginalLinePts().get(getOriginalLinePts().size()-1);
            //Get nth points for all intermediate points
            int i = 0;
            boolean isEndPointReached = false;
            while (i < getOriginalLinePts().size()){
                Point p = getOriginalLinePts().get(i);
                getSimplifiedLinePts().add(p);
                i = i + n;
                //Get end point from originalLinePts and add to simplifiedLinePts 
                //if it has not already been added above
                if (p.getX() == endPoint.getX() && p.getY() == endPoint.getY()){
                    isEndPointReached = true; 
                }
            }
            if (isEndPointReached == false){
                getSimplifiedLinePts().add(endPoint);
            }
            System.out.println("There are total of " 
                    + getSimplifiedLinePts().size() +
                    " points in simplified line array");
            return getSimplifiedLinePts();
        }
        else{
            System.out.println("Input line has 2 points or less, please load a " +
                    " line  with at least 3 points");
        }
        return getSimplifiedLinePts();
    }

  

    
    /**
     * 2. Routine of distance between points 
     * 
     * Type: Local Processing Routines
     * 
     * This algorithm removes the nearest neighbour next point)
     * to a point if it is within a set distance of the point.
     * The process is carried out on each point of a line in turn.
     * 
     *  1.User enters radius distance tolerance                                                                          DONE                    
     *  2.Display the line to simplify
     *  3.Display points and point id's                                                                                   DONE
     *  4.Calculate circle with the user entered radius distance and store circle                                        DONE
     *  5.For each intermediate point (excluding start and end point)                                                    CHECK THIS!
     *      5.1 Display the circle on point + Label + Arrow                                                              PARTIAL
     *      5.2 Calculate distance of nearest point to intermediate point                                                DONE
     *      5.3 If distance to nearest neighbour is smaller than circle radius 
     *          distance                                  
     *              5.3.1 Remove nearest neighbour point                                                                 DONE
     *      5.4 Recalculate line to simplify                                                                             DONE
     *      5.5 Display the line to simplify                                 
     *      
     * @param originalLinePts - Points representing the original line points
     * @param radiusDistanceTolerance - Value representing the radial distance
     *                                  tolerance
     * @return point - Points representing the simplified line points
     */
    public ArrayList<Point> routineOfDistanceBetweenPoints(ArrayList<Point>
            originalLinePts,
            int radiusDistanceTolerance){
        int nearestNeighbourIndexPos = 0;
        setOriginalLinePts(new ArrayList<>(originalLinePts));
        setSimplifiedLinePts(new ArrayList<>(originalLinePts));
        setRadialDistanceTolerance(radialDistanceTolerance);
        LineSimplificationFrame lsf = new LineSimplificationFrame();

        //Check input line has more than 4 points 
        if (checkNoOfPoints("Routine of distance between points", 
                getOriginalLinePts(), 4)){
            //for each intermediate point (excluding start and end points)
            //remove either the previous point or next point if either one has 
            //the shortest distance from the
            //intermdiate point, and whose distance is within the radial 
            //distance threshold. 

            for (int i = 0;  i < getSimplifiedLinePts().size() - 1; i++){
                Point keyPoint = getSimplifiedLinePts().get(i);
                ArrayList<Point> pointsInCircle = 
                        getPointsInCircle(getSimplifiedLinePts(), 
                                radiusDistanceTolerance, keyPoint);
                    
                //FOR DEBUG: Print points in circle
                for(int w = 0; w < pointsInCircle.size(); w++){
                    Point p = pointsInCircle.get(w);
                    System.out.println("Point in circle: " + p.getID());
                }

                //determine and store consecutive points
                //get rid of any points which are not consecutive
                //Store only consecutive points that fall in a circle starting
                //with the circles key point. Any points before the circles key
                //point are removed from the pointsInCircle arraylist
                int startPos = pointsInCircle.indexOf(keyPoint);
                for (int l = 0; l < pointsInCircle.size(); l++){
                    int pointPos = pointsInCircle.indexOf(pointsInCircle.get(l));  
                    if (pointPos < startPos){
                        pointsInCircle.remove(pointPos);
                    }
                }
                    
                //Determine ONLY consecutive points after sleeve start point
                //and only store those in the subpartList                          
                ArrayList<Point> pointsInCircle2 = new ArrayList<>();
                pointsInCircle2.add(keyPoint);
                for(int d = 0; d < pointsInCircle.size()-1; d++){
                    Point point1 = pointsInCircle.get(d);
                    Point point2 = pointsInCircle.get(d+1);                    
                    String strPoint1 = point1.getID();
                    String strPoint2 = point2.getID();
                    System.out.println("strPoint1 " + strPoint1);
                    System.out.println("strPoint2 " + strPoint2);
                    strPoint1 = strPoint1.substring(1);
                    strPoint2 = strPoint2.substring(1);
                    int pt1 = Integer.parseInt(strPoint1);
                    int pt2 = Integer.parseInt(strPoint2);                    
                    System.out.println(""+ pt1);
                    System.out.println(""+ pt2);
                    
                    //Only keeping consecutive points i.e 
                    //determined using difference in point ID = 1
                    if (pt2 - pt1 == 1){
                        pointsInCircle2.add(point1);
                        pointsInCircle2.add(point2);        
                    }
                    else{
                        break;
                    }
                }
                            
                //Getting rid of any duplicate elements (duplicate points 
                //from subpartList2)
                List<Point> pointsInCircle2WithoutDuplicates = new ArrayList<>();
                for(int r = 0; r < pointsInCircle2.size(); r++){
                    Point pp = pointsInCircle2.get(r);
                    pointsInCircle2WithoutDuplicates.add(pp);    
                }
                
                //Sorting the elements (points)
                LinkedHashSet<Point> linkedhashset = new LinkedHashSet<>();
                linkedhashset.addAll(pointsInCircle2WithoutDuplicates);
                pointsInCircle2WithoutDuplicates.clear();
                pointsInCircle2WithoutDuplicates.addAll(linkedhashset);
                
                //Saving elements (points) to arraylist
                pointsInCircle2 = new ArrayList<>(pointsInCircle2WithoutDuplicates);
  
                //For DEBUG: Print sublist
                for(int y = 0; y < pointsInCircle2.size(); y++){
                    System.out.println("pointsInCircle2 :" + 
                            pointsInCircle2.get(y).getID());
                }
                    
                String str = "";
                String str2 = "";
                for (int l = 0; l < pointsInCircle2.size(); l++){    
                    //Store first and last points only from sublist to
                    //simplified line 
                    if(l == 0){//| l == pointsInCircle2.size()-1){
                        
                    }
                    else{
                        //Remove all intermediate points that are not first or 
                        //last point in the pointsInCircle2 sublist
                        System.out.println("Removing " + 
                                pointsInCircle2.get(l).getID());
                        str = str +  pointsInCircle2.get(l).getID();
                        Point lastPointInGetPoints2 =
                        getSimplifiedLinePts().get(getSimplifiedLinePts().size()-1); 
                        
                        if(pointsInCircle2.get(l).getID().equals(
                                lastPointInGetPoints2.getID())){
                        
                        }
                        else
                            getSimplifiedLinePts().remove(pointsInCircle2.get(l));
                        }
                    }              
                }         
            }         
        return getSimplifiedLinePts();
    } 


   /**
     * 3. Perpendicular distance routine   
     *                  
     * Processes line a point at a time
     * 
     * Type: Local Processing Routines
     * 
     * 1. User enters perpendicular distance tolerance                                                                                  DONE
     * 2. Display the complete line to simplify                
     * 3. Label all points with an id                                                                                                   DONE
     * 4. For each intermediate point in sequence (excluding start and end point)
     *      4.1.  Calculate effective area for intermediate point                                                                       DONE
     *      4.2.  Calculate simplified line for intermediate point (simplified 
     *            line is a line between previous point and next point)   
     *      4.3.  Calculate perpendicular distance for intermediate point (from 
     *            intermediate point to simplified line created at 4.2).   
     *      4.4.  Check perpendicular distance for intermediate point is larger 
     *            than perpendicular distance tolerance                    
     *      4.5.  if perpendicular distance is smaller than 
     *            perpendicular distance tolerance
     *         4.5.1. Store intermediate point with perpendicular 
     *                distance smaller than the perpendicular tolerance
     *                to remove                                            
     *         4.5.2. Highlight intermediate point and label "Point id" is 
     *                smaller than the perpendicular tolerance and 
     *                will be removed                                      
     *         REPEAT 4 for each intermediate point
     *  5. Remove all intermediate points marked as having perpendicular
     *     distance smaller than the tolerance                              
     *  6. Recalculate the line                                                                                                         CHECK                                
     *  7. Display the final simplified line.
     *
     *  @param originalLinePts - Points represent the original line points 
     *  @param perpendicularDistanceTolerance - Value representing perpendicular
     *  distance to simplified line. Points within this tolerance to be removed 
     *  @return simplifiedLinePts - Points representing the simplified line 
     *                              points 
     */
    public ArrayList<Point> perpendicularDistanceRoutine(ArrayList<Point>
            originalLinePts, 
            double perpendicularDistanceTolerance){       
 
        setPerpendicularDistanceTolerance(perpendicularDistanceTolerance);
        setOriginalLinePts(originalLinePts);
        setSimplifiedLinePts(new ArrayList<>());
        setSimplifiedLines(new ArrayList<>());
        setPerpendicularLines(new ArrayList<>());

        if (checkNoOfPoints("Routine of perpendicular distance",
                getOriginalLinePts(), 3)){
            //Retain start point for simplified line
            getSimplifiedLinePts().add(getOriginalLinePts().get(0));

            //for each intermediate point at a time in original line (points) array, 
            //create a simplified line between the prev and next point
            for(int i = 1; i < getOriginalLinePts().size() - 1; i++){ 
                int j = i - 1;
                int k = i + 1;
                Point prevPoint = getOriginalLinePts().get(j);
                Point point = getOriginalLinePts().get(i);
                Point nextPoint = getOriginalLinePts().get(k);

                //Create, store and draw the simplified line segment(s)          
                Liner simplifiedLine = new Liner(prevPoint, nextPoint);
                getSimplifiedLines().add(simplifiedLine);

                //Create perpendicular point perpendicular to intermediate point
                //and that intersects the simplified line segment
                LinePerformance lp = new LinePerformance();
                String coord =  "p" + i + "," + lp.createPerpendicularPoint(point,
                        prevPoint, nextPoint);
                Point perpendicularPoint = new Point(coord);

                //Create, store and draw the perpendicular line and label line   
                Liner perpendicularLine = new Liner(point, perpendicularPoint);
                getPerpendicularLines().add(perpendicularLine);  
             

                //Calculate the perpendicular distance from the intermediate point
                //to the created simplified line
                double perpendicularDist = distanceOfPointPerpendicularToLine(point,
                        simplifiedLine);
                System.out.println("Perpendicular distance " + i + ": " 
                        + perpendicularDist);        

                //Retain intermediate point if perpendicular distance is more than
                //perpendicular distance threshold tolerance
                if (perpendicularDist > perpendicularDistanceTolerance){
                    getSimplifiedLinePts().add(getOriginalLinePts().get(i));
                }  
            }

            //Retain end point for simplified line pts 
            getSimplifiedLinePts().add(getOriginalLinePts().get(
                    getOriginalLinePts().size()-1));
            return getSimplifiedLinePts();

        }
        else{
            System.out.println("Input line has 2 points or less, please load a "
                    + "line with at least 3 points");
        }
        return getOriginalLinePts();
    }

    
     /**
     * 4. Reumann-Witkam Routine       
     *                                                
     * 
     * Type: Unconstrained Extended Local Processing
     * 
     * 1. Create strip based on size(w,h) input by user
     * 2. Get bearing for each line (each pair of points)                   
     * 3. For each tangent (line bearing)
     *      Align strip with line in the direction of initial tangent until strip
     *      hits the line                                                   
     *      (Points within strip make up 1 section of the line
     * 4. Find the Last Point within the strip. This is the Initial Point of the
     *    remaining part of the line                                        
     * 5. REPEAT 3 for so strip has direction the same as the initial tangent of
     *    the remaining part                                                
     * 6. Repeat whole process until the strip contains the end point 
     *    of the line.                                                      
     * 7. The Initial Point of each section of the line and the end point of the 
     *    line are retained and points between them are removed
     *    
     *    Ref: To extend tangent to be width (length) of what user input (used 
     *    formula from)
     *    
     *    To get of rid of duplicate points for array list
     *    Ref: http://stackoverflow.com/questions/203984/how-do-i-remove-repeated
     *         -elements-from-arraylist
     *    Ref: http://stackoverflow.com/questions/28935962/copying-linkedhashset
     *         -content-to-new-arraylist
     * 
     * @param originalLinePts - Points representing the original line points
     * @param height - Value representing the height tolerance (for sleeve)
     * @param width - Value representing the width tolerance (for sleeve)
     * @return simplifiedLinePts - Points representing the simplified line 
     *                             points  
     */
    public ArrayList<Point> reumannWitkam(ArrayList<Point> originalLinePts,
            int height, int width){
        
        ArrayList<Point> simplifiedLinePts = new ArrayList<>(originalLinePts);  
        ArrayList<Point> subpartList = new ArrayList<>();                            
        int sleeveCounter = 0;
        
        for (int f = 0; f < simplifiedLinePts.size()-1; f++){
            Point startPoint = simplifiedLinePts.get(f);
            Point endPoint = simplifiedLinePts.get(f+1);
                        
            //Reset point sublist
            subpartList = new ArrayList<>();
                                
            //Get bearing in radians for tangent line
            Liner line = new Liner(startPoint, endPoint);
            double bearingOfTangent = line.calculateBearingofLine(startPoint, 
                    endPoint);
            double bearingOfTangentInRadians = Math.toRadians(bearingOfTangent);

            //Adjust tangent length to be same length (width) as user input length
            //(width) by creating new endPoint for line 
            long newEndPointX = Math.round(startPoint.getX()+ 
                    (width * Math.sin(bearingOfTangentInRadians)));
            long newEndPointY = Math.round(startPoint.getY()+ 
                    (width * Math.cos(bearingOfTangentInRadians)));
            endPoint = new Point("p" + f + "," + newEndPointX + ","
                    + newEndPointY);

            //Create and store rectangle strip (sleeve) in SLEEVELINES 
            //aligned to intitial line tangent so they can be drawn 
            Sleeve sleeve = new Sleeve(height, width);
            ArrayList<Liner> sleeveLines = new ArrayList<>(
                    sleeve.createSleeve(startPoint, endPoint, bearingOfTangent));
            sleeveCounter++;
    
        
            //Initially determine and store the points inside sleeve (sleeveLines)
            //into subpartList
            for (int y = 0; y < simplifiedLinePts.size(); y++){  
                if (isPointInConvexPolygon(simplifiedLinePts.get(y), sleeveLines)){
                    System.out.println("Point " + (y+1) + " is inside sleeve:" +
                            sleeveCounter); 
                    subpartList.add(simplifiedLinePts.get(y));
                }
                else{
                    System.out.println("Point " + (y+1) + " is NOT inside "
                            + "sleeve:" + 
                            sleeveCounter);
                }        
            }                    
                        
            //Store only consecutive points that fall in a sleeve starting
            //with the sleeves start point. Any points before the sleeves start 
            //point are removed from the subpartList
            int startPos = subpartList.indexOf(startPoint);
            for (int l = 0; l < subpartList.size(); l++){
                int pointPos = subpartList.indexOf(subpartList.get(l));  
                if (pointPos < startPos){
                    subpartList.remove(pointPos);
                }
            }
   
            //Determine ONLY consecutive points after sleeve start point
            //and only store those in the subpartList           
            ArrayList<Point> subpartList2 = new ArrayList<>();
            subpartList2.add(startPoint);
            for(int d = 0; d < subpartList.size()-1; d++){
                Point point1 = subpartList.get(d);
                Point point2 = subpartList.get(d+1);        
                String strPoint1 = point1.getID();
                String strPoint2 = point2.getID();
                System.out.println("strPoint1 " + strPoint1);
                System.out.println("strPoint2 " + strPoint2);
                strPoint1 = strPoint1.substring(1);
                strPoint2 = strPoint2.substring(1);
                int pt1 = Integer.parseInt(strPoint1);
                int pt2 = Integer.parseInt(strPoint2);
                System.out.println(""+ pt1);
                System.out.println(""+ pt2);
                   
                //Only keeping consecutive points i.e 
                //determined using difference in point ID = 1
                if (pt2 - pt1 == 1){
                    subpartList2.add(point1);
                    subpartList2.add(point2);
                }
                else{
                    break;
                }
            }
            
            //Getting rid of any duplicate elements (duplicate points from 
            //subpartList2)
            List<Point> subpartList2WithoutDuplicates = new ArrayList<>();
            for(int r = 0; r < subpartList2.size(); r++){
                Point pp = subpartList2.get(r);
                subpartList2WithoutDuplicates.add(pp);    
            }
                
            //Sorting the elements (points)
            LinkedHashSet<Point> linkedhashset = new LinkedHashSet<>();
            linkedhashset.addAll(subpartList2WithoutDuplicates);
            subpartList2WithoutDuplicates.clear();
            subpartList2WithoutDuplicates.addAll(linkedhashset);
                
            //Saving elements (points) to arraylist
            subpartList2 = new ArrayList<>(subpartList2WithoutDuplicates);
  
            //For DEBUG: Print sublist
            for(int y = 0; y < subpartList2.size(); y++){
                System.out.println("subpartList2 :" + subpartList2.get(y).getID());
            }
                   
            String str = "";
            for (int l = 0; l < subpartList2.size(); l++){    
                //Store first and last points only from sublist to simplified line 
                if(l == 0 || l == subpartList2.size()-1){
                }
                else{
                    //Remove all intermediate points that are not first or last 
                    //point in the sublist
                    System.out.println("Removing " + subpartList2.get(l).getID());
                    str = str +  subpartList2.get(l).getID();
                    simplifiedLinePts.remove(subpartList2.get(l));                
                    }              
                }
            }

        return simplifiedLinePts;
    }
    

    /**
     * Simplified Line Points In Sleeve
     * 
     * Called by method reumannWitkam
     * 
     * Returns the original points inside a sleeve that should be in the 
     * simplified line segment for the Reumann-Witkam algorithm
     * 
     * @param startPoint - Point representing the start point
     * @param originalLinePts - Points representing the original line points
     * @param sleeveLines - Lines representing a sleeve
     * @param sleeveCounter - Value representing sleeve id
     * @return points - Points representing simplified line points in sleeve
     */
    public ArrayList<Point> simplifiedLinePointsInSleeve(Point startPoint, 
            ArrayList<Point> originalLinePts, ArrayList<Liner> sleeveLines, 
            int sleeveCounter){
        setSimplifiedLinePts(new ArrayList<>());
        setOriginalLinePts(originalLinePts);
        ArrayList<Point> subpartList = new ArrayList<>();
        //Check in each sleeve to see which original points fall within 
        //it and store in sublist
        int startPosIndex = 0;
        int endPosIndex = 0;
        int countPtsInsideSleeve = 0;
        //sleeveCounter++;
        for (int y = 0; y < originalLinePts.size(); y++){
            //Initially determine and store the points in A sleeve (sleeveLines)
            if (isPointInConvexPolygon(originalLinePts.get(y), sleeveLines)){
                System.out.println("Point " + (y+1) + " is inside sleeve:" + 
                        sleeveCounter); 
                subpartList.add(originalLinePts.get(y));
            }
            else{
                System.out.println("Point " + (y+1) + " is NOT inside sleeve:" +
                        sleeveCounter); 
            }    
        }
  
        //Get index of startPoint of where sleeve starts in relation to where it
        //is in subpartList
        for (int k = 0; k < subpartList.size(); k++){
            Point p = subpartList.get(k);
            if(startPoint.getID().equals(p.getID())){
                startPosIndex = k;
            }
        }
        
        //Get rid of points in sleeve that are before the startPoint (original
        //point) of where sleeve starts to be drawn        
         List<Point> numbers = new ArrayList<>(subpartList);
         endPosIndex = subpartList.size()-1;
         List<Point> subpart = numbers.subList(startPosIndex, endPosIndex);
         subpartList = new ArrayList<>(subpart);
         
        //Store only last and end points that fall in a sleeve
        for (int i = 0; i < subpartList.size(); i++){
            //Add first and last points only from sublist to simplified line 
            if(i == 0 | i == subpartList.size()-1){
                getSimplifiedLinePts().add(subpartList.get(i));
            }
        }
        return getSimplifiedLinePts();
    }



    /**
     * Create Perpendicular Lines for Original Line 
     * Intermediate Points To Tangent Line
     * 
     * @param tangentLine - Line representing the line segment to create 
     *                      perpendicular lines to
     * @param originalPtsSubList - Points in original line to create perpendicular
     *                             line from
     * @return perpendicularLines - Collection of Lines representing 
     *                              perpendicular lines
     */
    private ArrayList<Liner> calculatePerpendicularLinesForLineSegment(Liner 
            tangentLine, ArrayList<Point> originalPtsSubList){
        ArrayList<Liner> perpendicularLines = new ArrayList<>();
        Point startPoint = tangentLine.getLinerPoint1();
        Point endPoint = tangentLine.getLinerPoint2();
      
        for(int i = 1; i < originalPtsSubList.size()-1; i++){
            //Create perpendicular line to tangent line for each original 
            //intermediate point
            Point intermediatePoint = originalPtsSubList.get(i);   

            //Create perpendicular point perpendicular to intermediate point and
            //that intersects the tangent line
            LinePerformance lp = new LinePerformance();
            String coord =  "p" + i + "," +
             lp.createPerpendicularPoint(intermediatePoint, startPoint, endPoint);
            Point perpendicularPoint = new Point(coord);

            //Create, store and draw the perpendicular line and label line   
            Liner perpendicularLine = new Liner(intermediatePoint, 
                    perpendicularPoint);
            perpendicularLines.add(perpendicularLine);

            //Calculate the perpendicular distance from the intermediate point to
            //the tangent line
            double perpendicularDist = 
             distanceOfPointPerpendicularToLine(intermediatePoint, tangentLine);
            
        }
        return perpendicularLines;
    }

   
    /**
     * 6. Ramer Douglas Peucker Line Simplification
     * 
     * Type: Global Routine
     * 
     * Taken from project proposal:
     * 
     * Step 1 - User specifies a maximum perpendicular distance
     * Step 2 - Draw the original line
     * Step 3 - Create the initial simplified line between start and 
     *          end point of original line
     * Step 4 - For each point (excluding start and end point)
     * Step 5 - Create a perpendicular distance from point to simplified line
     * Step 6 - If perpendicular distance is larger than maximum perpendicular 
     *          distance tolerance
     * Step 7 - Point with this distance is used to partition line into 
     *          point subsets
     * Step 8 - Remove points with perpendicular distances in each subset smaller
     *          than the maximum perpendicular distance
     * Step 9 - Draw simplified line from start to end points of each point subset
     * Step 10 - Repeat steps 4-9 until all perpendicular distances are smaller
     *           than the maximum perpendicular distance tolerance
     * Step 11 - Display the simplified line and label
     * Step 12 - Remove the original line and label
     * 
     * Two parts to algorithm
     * First part of algorithm looks through input one dimension array and finds
     * point which is furthest away using (a) maxDistance and records its 
     * (b) points index position.
     * These are both needed for second part of algorithm
     * 
     * Second part of algorithm removes any points that are within epsilon 
     * (user specified threshold in display units), hence simplifying line
     * 
     * ref: http://web.cs.sunyit.edu/~poissad/projects/Curve/about_algorithms
     * /douglas.php
     * ref: https://en.wikipedia.org/wiki/Ramer%E2%80%93Douglas%E2%80%93Peucker_
     * algorithm
     * 
     * @param pts - Points representing original line points
     * @param  perpendicularDistanceTolerance - Value representing the 
     *                                  perpendicular distance tolerance
     * @param count - Value representing a counter value
     * @return  ArrayList of points after line simplification  
     */
     public ArrayList<Point> ramerDouglasPeucker(ArrayList<Point> pts,
             double perpendicularDistanceTolerance){
        //Find the intermediate point with the max perpendicular 
        //distance from simplified line
        
	//double perpendicularDistance = 0;
        double maxPerpendicularDistance = 0;
        int pointIndexPosition = 0;
        String strStart = "";
        String strEnd = "";
        String strIntermediatePoint = "";

        ArrayList<Point> originalPtsList = pts;
        ArrayList<Point> simplifiedPtsList = new ArrayList<>();
        ArrayList<Point> pointList1 = new ArrayList<>();
        ArrayList<Point> pointList2 = new ArrayList<>();
        ArrayList<Point> results1 = new ArrayList<>();
        ArrayList<Point> results2 = new ArrayList<>();

        //Iterate through each of the original points and find the intermediate 
        //point with the maximum perpendicular distance from the simplfied line
        for (int i = 1; i < originalPtsList.size()-1; i++){
            Point startPoint = originalPtsList.get(0);
            Point endPoint = originalPtsList.get(originalPtsList.size()-1);
            Point intermediatePoint = originalPtsList.get(i);
            Liner simplifiedLine = new Liner(startPoint, endPoint); 
            double perpendicularDistance = 
             distanceOfPointPerpendicularToLine(originalPtsList.get(i), 
                     simplifiedLine);

            //Determine intermediate point to keep
            if (perpendicularDistance >= maxPerpendicularDistance){
                maxPerpendicularDistance = perpendicularDistance;
                pointIndexPosition = i;
                strStart = startPoint.getID();
                strEnd = endPoint.getID();
                strIntermediatePoint = intermediatePoint.getID();
            }
        }
    

        System.out.println("Start of simplified line: " + strStart + ", "
                + "End of simplified line: " + strEnd); 

        if (maxPerpendicularDistance >= perpendicularDistanceTolerance){
            System.out.println("Point " + strIntermediatePoint +
                    " has Maximum Distance " + maxPerpendicularDistance + 
                " greater than " + perpendicularDistanceTolerance + " threshold");
            System.out.println("Keep " + strIntermediatePoint); 
        }
        else{
            System.out.println("Point " + strIntermediatePoint + 
                    " has Maximum Distance " + maxPerpendicularDistance + 
                " smaller than " + perpendicularDistanceTolerance + " threshold");
            System.out.println("Remove " + strIntermediatePoint); 
        }

        //Build 2 lists of result points:
        //First list (first point to point with max perpendicular distance)
        
        for (int j = 0; j < pointIndexPosition + 1; j++){
            pointList1.add(originalPtsList.get(j));
        }
        //Second list (point with max perpendicular distance to last point)
        for (int k = pointIndexPosition; k < originalPtsList.size(); k++){
            pointList2.add(originalPtsList.get(k));
        }

        ArrayList<Liner> pointList1DistortionLines = new ArrayList<>();
        //ArrayList<Liner> pointList2DistortionLines = new ArrayList<>();
      
        //Process each half of partitioned list
        if (maxPerpendicularDistance > perpendicularDistanceTolerance){
            results1 = ramerDouglasPeucker(pointList1,
                    perpendicularDistanceTolerance);  //recursive call
            results2 = ramerDouglasPeucker(pointList2, 
                    perpendicularDistanceTolerance);  //recursive call
            //Contruct list of both lists 
                    
                for (int m = 0; m < results1.size()-1; m++){
                    simplifiedPtsList.add(results1.get(m));
                }
                
                    //Draw perpendicular distances from each point in pointList1
                for (int f = 0; f < pointList1.size(); f++){ 
                    LinePerformance lp = new LinePerformance();
                    Point p = pointList1.get(f);
                    Point startPoint1 = results1.get(0);
                    Point endPoint1 = results1.get(results1.size()-1);
                    //Create Point (p2) where distortion distance intersects
                    //simplified line
                    String coord =  "p" + f + "," +
                            lp.createPerpendicularPoint(p, startPoint1, endPoint1);
                    Point p2 = new Point(coord);
                    Liner pointList1DistortionLine = new Liner(p,p2);
                    System.out.println("PointList1:" + 
                            pointList1DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList1DistortionLine);            
                }
                setPointList1DistortionLines(new ArrayList<>(
                        pointList1DistortionLines));
                           
                for (int n = 0; n < results2.size(); n++){
                    simplifiedPtsList.add(results2.get(n));
                }
                
                //Draw perpendicular distances from each point in pointList1
                for (int g = 0; g < pointList2.size(); g++){ 
                    LinePerformance lp = new LinePerformance();
                    Point p = pointList2.get(g);
                    Point startPoint2 = results2.get(0);
                    Point endPoint2 = results2.get(results2.size()-1);
                    //Create Point (p2) where distortion distance intersects 
                    //simplified line
                    String coord =  "p" + g + "," + 
                            lp.createPerpendicularPoint(p, startPoint2, endPoint2);
                    Point p2 = new Point(coord);
                    Liner pointList2DistortionLine = new Liner(p,p2);
                    System.out.println("PointList2:" + 
                            pointList2DistortionLine.getLength());
                    pointList1DistortionLines.add(pointList2DistortionLine);            
                }
                setPointList1DistortionLines(new ArrayList<>(
                        pointList1DistortionLines));
                
        }
        else{
            //System.out.println("Removed all intermediate points between " +
            //strStart + " and " + strEnd);  
            //Add start and end points to simplifiedPtsList
            simplifiedPtsList.add(originalPtsList.get(0));                         
            simplifiedPtsList.add(originalPtsList.get(originalPtsList.size()-1));   
        }
        return simplifiedPtsList;
     }


     
     
    /**
     * 7. VisvalingamWhyatt Line Simplification known as  Line Generalisation 
     *    using repeated elimination of points 
     * 
     * Type: Global Routine
     * 
     * The algorithm below is as follows (taken from Visvalingam, M and 
     * Whyatt J D (1993) "Line Generalisation by Repeated Elimination of Points",
     * Cartographic J., 30 (1), 46 - 51: Steps followed are documented in project
     * proposal.
     * 
     * @param  originalLinePts - Points representing original line points
     * @param  noOfPointsToKeep - Value representing the number of points to 
     *                            keep tolerance
     * @return simplifiedLinePtss - Points representing simplified line points                          
     */

    public ArrayList<Point> visvalingamWhyattSimplified(ArrayList<Point> 
            originalLinePts, int noOfPointsToKeep){
        //Check input line has more than 4 points 
        if (checkNoOfPoints("Visvalingam Whyatt", originalLinePts, 
                noOfPointsToKeep)){
            setNoOfPoints(noOfPointsToKeep);
            setSimplifiedLinePts(new ArrayList<>());
            setOriginalLinePts(originalLinePts);
            setEffectiveAreaTriangles(new ArrayList<>());
            
            double minEffectiveArea = 200000000;
            double effectiveArea = 0;
            int minEffectiveAreaIndex = 0;

            //Make a copy of the original line into simplified line points
            for (int s = 0; s < getOriginalLinePts().size(); s++){
                getSimplifiedLinePts().add(getOriginalLinePts().get(s));
            }
            //Remove intemediate points with min effective area until the no of 
            //points specified for simplified line is reached         
            do{
                //Excluding the start and end points calculate the effective area
                //of each intermediate point  
                //Add original line intermediate points that do not have the 
                //smallest effect area to simplified line 
                for (int i = 1; i < getSimplifiedLinePts().size()-1; i++){ 
                    int j = i - 1; 
                    int k = i + 1;
                    Point intermediatePoint = getSimplifiedLinePts().get(i);    
                    Point prevPoint = getSimplifiedLinePts().get(j);             
                    Point nextPoint = getSimplifiedLinePts().get(k);          

                    //Calculate effective area for each original line 
                    //intermediate point
                    effectiveArea = calcTriangleArea(intermediatePoint, prevPoint,
                            nextPoint);
                    setEffectiveArea(effectiveArea); 
                    
                    System.out.println("Effective Area for Point: " + i + "," 
                            + effectiveArea); 

                    //Create and store the effective area triangle for 
                    //intermediate point
                    Polygon effectiveAreaTriangle = drawTriangle(intermediatePoint, 
                            prevPoint, nextPoint, 3, 3);
                    getEffectiveAreaTriangles().add(effectiveAreaTriangle);
                    
                    //Check if effective area is the smallest effective area
                    if (effectiveArea > minEffectiveArea){
                    }
                    else{
                        minEffectiveArea = effectiveArea;
                        minEffectiveAreaIndex = i;
                        System.out.println("Min Effective Area is for Point: " + 
                                (minEffectiveAreaIndex) + "," + effectiveArea + 
                                " removing Pt " + (minEffectiveAreaIndex)
                                +  " from line");
                    }  
                }
                setEffectiveAreaTriangles(getEffectiveAreaTriangles());
                //Remove intermediate point in simplified line with the 
                //smallest effective area 
                getSimplifiedLinePts().remove(minEffectiveAreaIndex);
                minEffectiveArea = 200000000;
            }while(getSimplifiedLinePts().size() > noOfPointsToKeep);
            return getSimplifiedLinePts();
        }
        else{
            System.out.println("Input line has 2 points or less, please load a line"
                    + " with at least 3 points");
        }
        return getOriginalLinePts();
    }

    
    
    /**
     * 5. Lang Line Simplification
     * 
     * Type: Constrained Extended Local Processing
     * 
     * Based on algorithm found at 
     * http://web.cs.sunyit.edu/~poissad/projects/Curve/about_algorithms/lang.php   
     * 
     * 1. Select the first point as the key point                           
     * 2. Select the last point as the end point                            
     * 3. If there are no points between the key point and end point        
     *    and if the end point is not the last intermediate point           
     *    Make the end point the new key point                              
     *    Make the last intermediate point the new end point                
     *    Restart the step 3 using the new end point and key points        
     *    and if the end point is the last point
     * 4. If there are intermediate points between the key point and the end point
     *    continue to step 5
     * 5. Create simplified line between the key point and the end point                                      
     * 6. Find the point between the key point and the end point with the   
     *     largest perpendicular distance from this simplified line
     * 7. If that largest perpendicular distance is greater than 
     *    some tolerance                                                                
     *      Decrement the end point                                                                     
     *      Restart at step 3 using the new end point                      
     * 8. If that distance is less than, or equal to, the tolerance         
     *      Eliminate all points between the key point and the end point    
     *      Make the end point the new key point                            
     *      Make the last intermediate point the new end point              
     *      Restart at step3                                               
     *          
     * This implementation is based on pseudo code located here:
     * REF: http://web.cs.sunyit.edu/~poissad/projects/Curve/about_
     * algorithms/lang.php
     * 
     * NB. This implementation does not consider a LookAhead (no of points)
     * tolerance value unlike the langUsingCounter method which uses
     * a no of point tolerance AND a perpendicular distance tolerance
     * 
     * Ambiguity lead me to find a more detailed methodology
     * outlined on psimpl http://psimpl.sourceforge.net/lang.html
     * which is the basis for the langUsingCounter method
     * 
     * @param originalLinePts - Points representing original line points
     * @param tolerance - Value representing a perpendicular distance tolerance 
     * @return  ArrayList of points after line simplification  
     */

    public ArrayList<Point> lang(ArrayList<Point> originalLinePts,
            double tolerance){
        ArrayList<Point> simplifiedLinePts = originalLinePts;
        int keyPoint = 0;                             //First Point
        int endPoint = simplifiedLinePts.size()-1;    //End Point
        double maximumPerpendicularDistance = 0;
        int i = 0;
        
        do{
            endPoint = simplifiedLinePts.size()-1;
            //If intermediate points exist between key point and end point
            //keyPoint = keyPoint + 1;
            if(keyPoint + 1 < endPoint){
                i = i + 1;
                Liner simplifiedLineBetweenKeyPointAndEndPoint = 
                        new Liner(simplifiedLinePts.get(keyPoint), 
                                simplifiedLinePts.get(endPoint));
                LineSimplification ls = new LineSimplification();
                double perpendicularDistance = 
                 ls.distanceOfPointPerpendicularToLine(simplifiedLinePts.get(i),
                                simplifiedLineBetweenKeyPointAndEndPoint);
                      
                if (perpendicularDistance > maximumPerpendicularDistance){
                    maximumPerpendicularDistance = perpendicularDistance;
                 }
            }
                
            if (maximumPerpendicularDistance > tolerance){
                endPoint = endPoint - 1;
            }
               
            if (maximumPerpendicularDistance <= tolerance){
                for (int n = keyPoint + 1; n < endPoint; n++){
                        simplifiedLinePts.remove(n);
                }
                keyPoint = endPoint;
            }
        }while(endPoint != simplifiedLinePts.size()-1);
        
        return simplifiedLinePts;
    }
    
    
    /**
     * Point in Convex Polygon
     * 
     * Called by method simplifedLinePtsInSleeve
     * 
     * Checks to see if point is inside or on the edge of convex polygon based on 
     * the point in relation to each line (side) that make up the convex polygon
     * Based on sleeve lines stored with their points in a clockwork direction
     * Based on Solution 3 formula from
     * ref: http://local.wasp.uwa.edu.au/~pbourke/geometry/insidepoly/
     * 
     * @param p - Point to check if it is in the convex polygon
     * @param lines - Lines representing the sides of polygon (sleeve) to check
     *                Can also be used to check is point is to the right of
     *                one of more sides (if needed).
     * @return boolean - True if point is inside or on edge of convex polygon, 
     *                   false if point is outside convex polygon
     */

    public boolean isPointInConvexPolygon(Point p, ArrayList<Liner> lines){
        //if calculation less than 0 then P is to the right of the line segment 
        //if calculation more than 0 then P is to the left of the line segment 
        //if calculation equals 0 then P it lies on the line segment
        
        boolean inside = false;
        int counter1 = 0;
        int counter2 = 0;
        int px = p.getX();
        int py = p.getY();
        
        for (int i = 0; i < lines.size(); i++){
            int x1 = lines.get(i).getLinerPoint1().getX();
            int y1 = lines.get(i).getLinerPoint1().getY();
            int x2 = lines.get(i).getLinerPoint2().getX();
            int y2 = lines.get(i).getLinerPoint2().getY();
                
            int calculation;
            calculation = (py - y1)*(x2 - x1) - (px - x1)*(y2 - y1);
            if (calculation <= 0){
                counter1 = counter1 + 1;
            }
             if (calculation >= 0){
                counter2 = counter2 + 1;
            }
        }

        if (counter1 == 4 || counter2 == 4){
            inside = true;
            return inside;
        }
        else{
            return inside;
        }
    }

    

    /**
     * Get Number of Intermediate Points
     * 
     * Called by method lang
     * 
     * @param pts - Input points
     * @return intermediatePtcCount - no of intermediate points 
     *         (excluding start and end points)
     */
    public int getNoOfIntermediatePts(ArrayList<Point> pts){
        int intermediatePtCount = 0;
        for (int j = 1; j < pts.size() - 1; j++){
            intermediatePtCount++;
        }    
        return intermediatePtCount;
    }

   
    /**
     * Is Intermediate Point in line
     * 
     * Called by NthPoint in LineSimplificationFrame
     * 
     * Checks if intermediate point is in the line
     * @param p1 - Point representing point to check if it is in line
     * @param linePts - Points representing the line 
     * @return boolean true if intermediate point(s) is in line otherwise false
     */
    
    public boolean isPointInLine(Point p1, ArrayList<Point> linePts){
        boolean inLine = false;
        p1.getID();
        for (int i = 0; i < linePts.size(); i++){
            Point p2 = linePts.get(i);
            if (p1.getID().equals(p2.getID())){
                inLine = true;
            }
        }
        return inLine;
    }
    
    
    
    /**
     * Distance between a point perpendicular to a Line     
     * 
     * Called by calculatePerpendicularLinesForLineSegment, ramerDouglasPeucker
     * and lang methods
     * 
     * ref: https://en.wikipedia.org/wiki/Distance_from_a_point_to_a_line
     * @param point Point perpendicular to a line
     * @param line - Representing Line 
     * @return distance of point to the line 
     */
    public double distanceOfPointPerpendicularToLine(Point point, Liner line){    
        int pointx = point.getX();                                 
        int pointy = point.getY();

        Liner liner2 = line;

        int lineX1 = liner2.getLinerPoint1().getX();
        int lineY1 = liner2.getLinerPoint1().getY();
        int lineX2 = liner2.getLinerPoint2().getX();
        int lineY2 = liner2.getLinerPoint2().getY();

        int numerator = (((lineY2 - lineY1)* pointx) - ((lineX2 - lineX1) * 
                pointy) + (lineX2 * lineY1) - (lineY2 * lineX1));

        double distanceBetweenLineXandLineY = 
        Math.sqrt((Math.pow(lineY2 - lineY1,2.0)) + 
                (Math.pow(lineX2 - lineX1,2.0)));

        double distance = Math.abs(numerator/distanceBetweenLineXandLineY);
        distance = Math.round(distance * 100.0) / 100.0;
        return distance;
    }



    /**
     * Print out Line lengths for all points in points list         
     * 
     * Called by method routineOfDistanceBetweenPoints
     * 
     * @param points - Points representing a line to print
     */
    public void printLineLengthsForPointInList(ArrayList<Point> points){
        if(points.size() > 1){
            for (int i = 0; i < points.size() - 1; i++){
                Point p1 = points.get(i);
                Point p2 = points.get(i+1);

                Liner line = new Liner(p1,p2);
                System.out.println("Length line " + i  + ", " + 
                        Math.round((line.getLength() * 100) / 100)); 
            }
        }
        else{
           System.out.println("cannot print line lengths as point list has less "
                   + "than 2 points"); 
        }
    }



    /**
     * Calculate Triangle Area
     * 
     * Called by Visvalingam
     * 
     * Triangle area formed from current point (x,y), prev point (x,y) and next 
     * point (x,y)
     * Ref http://www.mathguru.com/level2/
     *           application-of-coordinate-geometry-2007101600011139.aspx
     * Triangle area from coords = (xa - xc)(yb - ya) - (xa - xb)(yc - ya) / 2
     * @param  point - Point to calculate TriangleArea for
     * @param prevPoint - previous point from intermediate point 
     * @param  nextPoint - next point from intermediate point
     * @return  triangleArea  - Next point from point
     */
    public double calcTriangleArea(Point point, Point prevPoint, Point nextPoint){
        double pointx = point.getX();
        double pointy = point.getY();
        double prevX = prevPoint.getX();
        double prevY = prevPoint.getY();
        double nextX = nextPoint.getX();
        double nextY = nextPoint.getY();

        double triangleArea = ((prevX - nextX) * (pointy - prevY)) -
                ((prevX - pointx) * (nextY - prevY));
        triangleArea = Math.abs(triangleArea / 2);
        return triangleArea;
    }

   
    /**
     * Maximum distance                 
     * 
     * Derives a maximum distance measure between the original line and its 
     * simplified version. The maximum distance is the maximum deviation(Maximum 
     * Distortion) between locations (points) of the original line and its 
     * simplified version
     * 
     * @param points - Points (representing line) to create maximum distortion 
     *                 distance for
     * @param line - Line
     * @return maxDistance is the maximum deviation between locations of the 
     *         original line and its simplified version
     */
    public double maximumDistance(ArrayList<Point> points, Liner line){
        //Iterate through each of the points and see which one is 
        //the furthest away from line
        double maxDistance = 0;
 
        for (int i = 1; i < points.size() - 2; i++){
            double distanceToPoint = 
                    distanceOfPointPerpendicularToLine(points.get(i), line);
            if (distanceToPoint > maxDistance){
                maxDistance = distanceToPoint;
            }       
        }
        return maxDistance;
    }

     /**
     *  Draw Triangle Geometry     
     * 
     *  Called by method VisvalingamWhyatt 
     *  
     *  @param intermediatePoint - first vertices point in triangle
     *  @param prevPoint - second vertices point in triangle
     *  @param nextPoint - third vertices point in triangle 
     *  @param npoints  - value representing no of points for geometry 
     *  @param arraySize - value representing the size required for polygon
     *  @return lines representing the lines (sides) of the triangle
     */
    public Polygon drawTriangle(Point intermediatePoint, Point prevPoint, 
            Point nextPoint, int npoints, int arraySize){
      
        int x1 = intermediatePoint.getX();
        int y1 = 600 - intermediatePoint.getY();
        int x2 = prevPoint.getX();
        int y2 = 600 - prevPoint.getY();
        int x3 = nextPoint.getX();
        int y3 = 600 - nextPoint.getY();
                
        int[] xpoints = new int[arraySize];
        int[] ypoints = new int[arraySize];
        
        xpoints[0] = x1;
        xpoints[1] = x2;
        xpoints[2] = x3;
        ypoints[0] = y1;
        ypoints[1] = y2;
        ypoints[2] = y3;
        
        Polygon polygon = new Polygon(xpoints, ypoints, npoints);
        return polygon;
    } 
    
   /**
   * Get Points in Circle
   * 
   * @param pts - Points representing the line points to check if inside circle 
   * @param radius - Value representing the radius of the circle to check
   * @param circlePoint - Point representing location where circle is centred on
   * @return ptsInCircle - Collection of points inside circle
   */
   
   public ArrayList<Point> getPointsInCircle(ArrayList<Point> pts, 
           double radius, Point circlePoint){

    ArrayList<Point> ptsInCircle = new ArrayList<>();
    double circleCenterX = circlePoint.getX();
    double circleCenterY = circlePoint.getY();
    boolean insideCircle = false;
    
 
     for(int j = 0; j < pts.size(); j++){
          double pointX = pts.get(j).getX();
          double pointY = pts.get(j).getY(); 
         
                Point p1 = pts.get(j);
                if(pts.indexOf(p1) < pts.indexOf(circlePoint)){
                    
                }
                else{
                    if (Math.sqrt(Math.pow(circleCenterX-pointX,2)+ 
                            Math.pow(circleCenterY-pointY,2)) <= radius) {
                        System.out.println("The point " + p1.getX() + "," + 
                                p1.getY() + " is inside the circle.");
                        insideCircle = true;
                        //Get rid of pts before the keyPoint to leave
                        //consecutive pts after keyPoint
                        ptsInCircle.add(p1);
                    } 
                    else {
                        System.out.println("The point " + p1.getX() + "," + 
                                p1.getY() + " is NOT inside the circle.");
                        insideCircle = false;		
                    }
                }
                                   
                }
            return ptsInCircle;
    }
}
