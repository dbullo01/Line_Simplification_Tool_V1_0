/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;


import java.util.ArrayList;

/**
 * Sleeve
 * 
 * Creates a sleeve represented by 4 liners to create a rectangle geometry 
 * 
 * @author (Davison Bullock) 
 * @version (01/05/2016)
 */
public class Sleeve
{
    // instance variables 
    private double height;
    private double width;
    

    /**
     * Constructor for objects of class Sleeve
     * 
     * @param height - Value representing the height of the sleeve
     * @param width - Value representing the width of the sleeve
     */
    public Sleeve(double height, double width){
        this.height = height;
        this.width = width;
    }

    public Sleeve(){
        this.height = 0;
        this.width = 0;
    }


     /**
     * Set Height 
     * 
     * Set sleeve height
     * 
     * @param height - Value representing the sleeve height
     * 
     */
    public void setHeight(double height){
        this.height = height;
    }

    /**
     * Set Width
     * 
     * @param width - Value representing the sleeve width
     * 
     */
    public void setWidth(double width){
        this.width = width;
    }

    /**
     * Get Height
     * 
     * @return sleeve height - Value representing sleeve height 
     */

    public double getHeight(){
        return this.height;
    }

    /**
     * Get Width
     * @return sleeve width - Value representing sleeve width
     */

    public double getWidth(){
        return this.width;
    }

    /**
     * Create Sleeve (Rectangle)
     * 
     * Draws a rectangle orientated to input line (start and end points of line)
     * as centreline
     * 
     * Ref https://www.mathsisfun.com/algebra/trig-solving-asa-triangles.html
     * Ref http://www.coolmath.com/algebra/08-lines/06-finding-slope-line-
     * given-two-points-01
     * @param startPtTangent - Start point of line segment (tangent) that sleeve 
     *                         will be drawn orientated to and sized from 
     *                         accordingly. 
     * @param endPtTangent - End point of line segment (tangent) that sleeve will
     *                       be drawn orientated to and sized accordingly
     * @param bearingOfTangent - Value of the bearing of the line segment 
     *                          (tangent)
     * @return sleeve - Line collection representing 4 lines (sides) of Sleeve 
     */
    public ArrayList<Liner> createSleeve(Point startPtTangent, Point endPtTangent, 
        double bearingOfTangent){ 
        int startPointX = startPtTangent.getX();
        int startPointY = startPtTangent.getY();
        int endPointX = endPtTangent.getX();
        int endPointY = endPtTangent.getY();
        ArrayList<Liner> lines = null; 

        long x1 = 0;
        long y1 = 0;
        long x2 = 0;
        long y2 = 0;
        long x3 = 0;
        long y3 = 0;
        long x4 = 0;
        long y4 = 0;
                
        //Get offset x and y distances to offset start point and end point to draw
        //each corner of rectangle. Triangle used in offset is a 90 degree angle
        //with two angles of 45 degrees and one known side which is 1/2 height.
   
        //For tangent bearing calculate coords for all 4 points of the sleeve
        if (bearingOfTangent > 0 & bearingOfTangent <= 90){
            double angle1radians = Math.toRadians(bearingOfTangent);
            double angle2radians = Math.toRadians(90);
            double angle3radians = Math.toRadians(180 - 90 - bearingOfTangent);
            //Finding diffx and diffx is calculated using Law of Sines 
            //(see reference above)
            double diffx = Math.round(((height/2)* Math.sin(angle3radians))/
                    Math.sin(angle2radians));
            double diffy = Math.round(((height/2)* Math.sin(angle1radians))/
                    Math.sin(angle2radians));
 
            //calculate diffx and diffy to add or subtract from tangent start point 
            //and end point x and y coords (depending on quadrant bearingTangent
            //falls in
            x1 = startPointX - (int) diffx;
            y1 = startPointY + (int) diffy;
            x2 = endPointX - (int) diffx;
            y2 = endPointY + (int) diffy;
            x3 = endPointX + (int) diffx;
            y3 = endPointY - (int) diffy;
            x4 = startPointX + (int) diffx; 
            y4 = startPointY - (int) diffy; 
                
        }else if(bearingOfTangent > 90 & bearingOfTangent <= 180){
            double angle1 = 180 - bearingOfTangent;
            double angle1radians = Math.toRadians(angle1);
            double angle2radians = Math.toRadians(90);
            double angle3radians = Math.toRadians(180 - 90 - angle1);
            //Finding diffx and diffx is calculated using Law of Sines 
            //(see reference above)
            double diffx = Math.round(((height/2)* Math.sin(angle3radians))/
                    Math.sin(angle2radians));
            double diffy = Math.round(((height/2)* Math.sin(angle1radians))/
                    Math.sin(angle2radians));
            
            x1 = startPointX + (int) diffx;
            y1 = startPointY + (int) diffy;
            x2 = endPointX + (int) diffx;
            y2 = endPointY + (int) diffy;
            x3 = endPointX - (int) diffx;
            y3 = endPointY - (int) diffy;
            x4 = startPointX - (int) diffx; 
            y4 = startPointY - (int) diffy;
            
        }else if(bearingOfTangent > 180 & bearingOfTangent <= 270){
            double angle1 = 360 - bearingOfTangent;
            double angle1radians = Math.toRadians(angle1);
            double angle2radians = Math.toRadians(90);
            double angle3radians = Math.toRadians(180 - 90 - angle1);
            //Finding diffx and diffx is calculated using Law of Sines 
            //(see reference above)
            double diffx = Math.round(((height/2)* Math.sin(angle3radians))/
                    Math.sin(angle2radians));
            double diffy = Math.round(((height/2)* Math.sin(angle1radians))/
                    Math.sin(angle2radians));
           
            x1 = startPointX + (int) diffx;
            y1 = startPointY + (int) diffy;
            x2 = endPointX + (int) diffx;
            y2 = endPointY + (int) diffy;
            x3 = endPointX - (int) diffx;
            y3 = endPointY - (int) diffy;
            x4 = startPointX - (int) diffx;
            y4 = startPointY - (int) diffy;        
                             
        }else if(bearingOfTangent > 270 & bearingOfTangent <= 360){
            double angle1 = 360 - bearingOfTangent;    
            double angle1radians = Math.toRadians(angle1);
            double angle2radians = Math.toRadians(90);
            double angle3radians = Math.toRadians(180 - 90 - angle1);
            //Finding diffx and diffx is calculated using Law of Sines 
            //(see reference above)
            double diffx = Math.round(((height/2)* Math.sin(angle3radians))/
                    Math.sin(angle2radians));
            double diffy = Math.round(((height/2)* Math.sin(angle1radians))/
                    Math.sin(angle2radians));
            x1 = startPointX - (int) diffx;
            y1 = startPointY - (int) diffy;
            x2 = endPointX - (int) diffx;
            y2 = endPointY - (int) diffy;
            x3 = endPointX + (int) diffx;
            y3 = endPointY + (int) diffy;
            x4 = startPointX + (int) diffx; 
            y4 = startPointY + (int) diffy;
            
        }

        Point p1 = new Point("p1" + "," + x1 + "," + y1);
        Point p2 = new Point("p2" + "," + x2 + "," + y2);
        Point p3 = new Point("p3" + "," + x3 + "," + y3);
        Point p4 = new Point("p4" + "," + x4 + "," + y4);
        
        lines = new ArrayList<>(); 
        Liner line1 = new Liner(p1,p2);
        Liner line2 = new Liner(p2,p3);
        Liner line3 = new Liner(p3,p4);
        Liner line4 = new Liner(p4,p1);

        lines.add(0, line1);                      
        lines.add(1, line2);                       
        lines.add(2, line3);                      
        lines.add(3, line4);                 
          
     return lines; 
    }
}
