package linesimplificationapps;

import java.util.List;
import java.util.ArrayList;
import java.awt.*;

/**
 * LinePerformance 
 * 
 * This class contains line metrics and performance measures
 * and related methods
 * 
 * @author (Davison Bullock) 
 * @version (08/11/2015)

 */
public class LinePerformance {

    private String standardizedVectorDisplacement;
    private String standardizedAreaDisplacement;
    private String areaDistortion;
    private double sumLeftPolygonAreas;
    private double sumRightPolygonAreas;
    private double sumPolygonAreas;
    private double uniformDistortion;
    private double sumOfSimplifiedLineSegments;
    private double maxDistortionDistance;
    private double meanDistortionDistance;
    private double standardDeviationDistortionDistance;
    private int noOfDistortionLines;
    private double sumOfDistortionLineLengths;
    private double percentageDecreaseInLineLengths;
    /**
     * Constructor for objects of class LinePerformance
     */
    public LinePerformance()
    {
        // initialise instance variables
        standardizedVectorDisplacement = "";
        standardizedAreaDisplacement = "";
        areaDistortion = "";
        sumLeftPolygonAreas = 0;
        sumRightPolygonAreas = 0;
        sumPolygonAreas = 0;
        uniformDistortion = 0;
        sumOfSimplifiedLineSegments = 0;
        maxDistortionDistance = 0;
        meanDistortionDistance = 0;
        standardDeviationDistortionDistance = 0;
        noOfDistortionLines = 0;
        sumOfDistortionLineLengths = 0;
        percentageDecreaseInLineLengths = 0;
    }
    
    
    /**
     * Get Percentage Decrease in Line Lengths
     * @return percentageDecreaseInLineLengths - Value representing
     *         percentage Decrease in Line Lengths between two line for example
     *         the original line and simplified line. 
     */
    
    public double getPercentageDecreaseInLineLengths(){
        return this.percentageDecreaseInLineLengths;
    }
    
    /**
     * Set Percentage Decrease in Line Lengths
     * @param percentageDecreaseInLineLengths - Value representing
     *         percentage Decrease in Line Lengths between two line for example
     *         the original line and simplified line. 
     */
    public void setPercentageDecreaseInLineLengths(
            double percentageDecreaseInLineLengths){
        this.percentageDecreaseInLineLengths = percentageDecreaseInLineLengths;
    }
    
    /**
     * Get Sum of Simplified Line Segments
     * @return sumOfSimplifiedLineSegments - Value representing sum of 
     * Simplified Line Segments
     */
    public double getSumOfSimplifiedLineSegments(){
        return this.sumOfSimplifiedLineSegments;
    }
    
    /**
     * Set Sum of Simplified Line Segments
     * @param sumOfSimplifiedLineSegments - Value representing sum of 
     * Simplified Line Segments
     */
    public void setSumOfSimplifiedLineSegments(double sumOfSimplifiedLineSegments){
        this.sumOfSimplifiedLineSegments = sumOfSimplifiedLineSegments;
    }
    
    
    /**
     * Get Max Distortion Distance
     * @return maxDistortionDistance -Value representing max distortion distance 
     */
    public double getMaxDistortionDistance(){
        return this.maxDistortionDistance;
    }
    
    /**
     * Set Max Distortion Distance
     * @param maxDistortionDistance - Value representing max distortion distance
     */
    public void setMaxDistortionDistance(double maxDistortionDistance){
        this.maxDistortionDistance = maxDistortionDistance;
    }
    
    /**
     * Get Mean Distortion Distance
     * @return meanDistortionDistance -Value representing mean distortion distance 
     */
    public double getMeanDistortionDistance(){
        return this.meanDistortionDistance;
    }
    
    /**
     * Set Mean Distortion Distance
     * @param meanDistortionDistance - Value representing mean distortion distance
     */
    public void setMeanDistortionDistance(double meanDistortionDistance){
        this.meanDistortionDistance = meanDistortionDistance;
    }
    
    
    /**
     * Get Standard Deviation Distortion Distance
     * @return standardDeviationDistortionDistance - Value representing 
     * standard deviation distortion distance 
     */
    public double getStandardDeviationDistortionDistance(){
        return this.standardDeviationDistortionDistance;
    }
    
    /**
     * Set Standard Deviation Distortion Distance
     * @param standardDeviationDistortionDistance - Value representing 
     * standard deviation distortion distance
     */
    public void setStandardDeviationDistortionDistance(double 
            standardDeviationDistortionDistance){
        this.standardDeviationDistortionDistance = 
                standardDeviationDistortionDistance;
    }
    
    
    
    /**
     * Get No of Distortion Lines
     * @return noOfDistortionLines - Value representing 
     * no of distortion distances 
     */
    public int getNoOfDistortionLines(){
        return this.noOfDistortionLines;
    }
    
    /**
     * Set No of Distortion Lines
     * @param noOfDistortionLines - Value representing 
     * no of distortion distances
     */
    public void setNoOfDistortionLines(int noOfDistortionLines){
        this.noOfDistortionLines = noOfDistortionLines;
    }

    
    
    /**
     * Get Sum of Distortion Line Lengths
     * @return sumOfDistortionLineLengths - Value representing the sum of 
     * distortion line lengths
     */
    public double getSumOfDistortionLineLengths(){
        return this.sumOfDistortionLineLengths;
    }
    
    /**
     * 
     * Set Sum of Distortion Line Lengths
     * @param sumOfDistortionLineLengths - Value representing the sum of 
     * distortion line lengths 
     */
    public void setSumOfDistortionLineLengths(double sumOfDistortionLineLengths){
        this.sumOfDistortionLineLengths = sumOfDistortionLineLengths;
    }
    
    /**
     * Get Sum Of Left Polygon Areas
     * @return sumLeftPolygonAreas - Value representing the sum of left polygon
     * areas
     */
    public double getSumLeftPolygonAreas(){
        return this.sumLeftPolygonAreas;
    }
    
    /**
     * Sum Left Polygon Areas
     * @param sumLeftPolygonAreas - Value representing the sum of left polygon
     * areas 
     */
    public void setSumLeftPolygonAreas(double sumLeftPolygonAreas){
        this.sumLeftPolygonAreas = sumLeftPolygonAreas;
    }
    
    /**
     * Get Sum Right Polygon Areas
     * @return sumRightPolygonAreas - Value representing the sum of right polygon
     * areas
     */
    public double getSumRightPolygonAreas(){
        return this.sumRightPolygonAreas;
    }
    
    /**
     * Set Sum Right Polygon Areas
     * @param sumRightPolygonAreas - Value representing the sum of right polygon
     * areas
     */
    public void setSumRightPolygonAreas(double sumRightPolygonAreas){
        this.sumRightPolygonAreas = sumRightPolygonAreas;
    }
    
    /**
     * Get Sum Polygon Areas
     * @return sumPolygonAreas - Value representing sum of polygon areas
     */
    public double getSumPolygonAreas(){
        return this.sumPolygonAreas;
    }
    
    /**
     * Set Sum Polygon Areas
     * @param sumPolygonAreas - Value representing sum of polygon areas
     */
    public void setSumPolygonAreas(double sumPolygonAreas){
        this.sumPolygonAreas = sumPolygonAreas;
    }
    
    /**
     * Get Uniform Distortion
     * @return uniformDistortion - Value representing uniform distortion
     */
    public double getUniformDistortion(){
        return this.uniformDistortion;
    }
    
    /**
     * Set Uniform Distortion
     * @param uniformDistortion - Value representing of uniform distortion
     */
    public void setUniformDistortion(double uniformDistortion){
        this.uniformDistortion = uniformDistortion;
    }
    
    /**
     * Set Standardized Vector Displacement
     * @param standardizedVectorDisplacement  - Value representing standardized
     * vector displacement
     */
    public void setStandardizedVectorDisplacement(String 
            standardizedVectorDisplacement){
        this.standardizedVectorDisplacement = standardizedVectorDisplacement;
    }
    
    /**
     * Get Standardized Vector Displacement 
     * @return standardizedVectorDisplacement- Value representing standardized
     * vector displacement
     */
    public String getStandardizedVectorDisplacement(){
        return this.standardizedVectorDisplacement;
    }
    
    /**
     * Set Standardized Area Displacement 
     * @param standardizedAreaDisplacement - Value representing standardized
     * area displacement
     */
    public void setStandardizedAreaDisplacement(String 
            standardizedAreaDisplacement){
        this.standardizedAreaDisplacement = standardizedAreaDisplacement;
    }
    
    /**
     * Get Standardized Area Displacement
     * @return standardizedAreaDisplacement - Value representing standardized
     * area displacement
     */
    public String getStandardizedAreaDisplacement(){
        return this.standardizedAreaDisplacement;
    }

    /**
     * Set Area Distortion
     * @param areaDistortion - Value representing area distortion
     */
    public void setAreaDistortion(String areaDistortion){
        this.areaDistortion = areaDistortion;
    }
    
    /**
     * Get Area Distortion
     * @return areaDistortion - Value representing area distortion
     */
    public String getAreaDistortion(){
        return this.areaDistortion;
    }

    
    /**
     * 
     * Is Line Segments Intersecting
     * 
     * Called by method calculateIntersectionPointBetweenTwoLines
     * 
     * Determines if there are intersecting line segments. Uses slope of line
     * formula y = mx + b to determine slope for a pair of line segments. If 
     * there is an intersection between lines, the point of intersection is 
     * returned as point containing point id, x,y coordinate
     * 
     * Ref:Intersection point of two line segments in 2 dimensions - 
     *     Paul Bourke April 1989
     * http://paulbourke.net/geometry/pointlineplane/    
     * @param line1 First line required to test for intersection
     * @param line2 Second line required to test for intersection
     * @return point
     */
    public Point isLineSegmentsIntersecting2(Liner line1, Liner line2){
        Point p = null;

        double line1x1 = line1.getLinerPoint1().getX();
        double line1y1 = line1.getLinerPoint1().getY();
        double line1x2 = line1.getLinerPoint2().getX();
        double line1y2 = line1.getLinerPoint2().getY();
        double line2x3 = line2.getLinerPoint1().getX();
        double line2y3 = line2.getLinerPoint1().getY();
        double line2x4 = line2.getLinerPoint2().getX();
        double line2y4 = line2.getLinerPoint2().getY();
        
        //Find intersection point x and y
        double numerator1 = ((line1y1 - line2y3) * (line2x4 - line2x3) - 
                (line1x1 - line2x3) * (line2y4 - line2y3));
        double denominator1 = ((line1x2 - line1x1) * (line2y4 - line2y3) - 
                (line1y2 - line1y1) * (line2x4 - line2x3));

        double numerator2 = ((line1y1 - line2y3) * (line1x2 - line1x1) - 
                (line1x1 - line2x3) * (line1y2 - line1y1));
        double denominator2 = ((line1x2 - line1x1) * (line2y4 - line2y3) - 
                (line1y2 - line1y1) * (line2x4 - line2x3));

        double q1 = numerator1/denominator1;
        double q2 = numerator2/denominator2;

        double intersectPtX = ((line1x2 - line1x1) * q1) + line1x1;
        double intersectPtY = ((line1y2 - line1y1) * q1) + line1y1;
        
        System.out.println("q1:" + q1);
        System.out.println("q2:" + q2);
        

        //Check if lines are parallel
        if (q1 == 0 & q2 == 0){
            // System.out.println("Line 1 and Line 2 are parallel");
        }

        //Check if lines are the same
        if ((denominator1 == 0 & numerator1 == 0) & (denominator2 == 0 & 
                numerator2 == 0)){
            //System.out.println("Line 1 and Line 2 are the same");
        }

        //Testing that q1 and q2 lie in between the range (0 and 1)
        //to get the point of intersection from the 2 intersecting line segments
        if ((q1 >= 0 & q1 <= 1) & (q2 >= 0 & q2 <= 1)){
            //System.out.println("Both Line 1 and Line 2 
            //contain the intersection point"); 
            int x = (int) intersectPtX;
            int y = (int) intersectPtY;

            p = new Point("p999" + "," + x + "," + y);
            
            //Check intersection point (p) x,y is not the same as
            //The end points of both Line1 and Line2 lines. If they are
            //the same we dont want to return them hence return p = null instead.
            if((p.getX() == line1x1 & p.getY() == line1y1) |
               (p.getX() == line1x2 & p.getY() == line1y2) |
               (p.getX() == line2x3 & p.getY() == line2y3) |
               (p.getX() == line2x4 & p.getY() == line2y4)){
                //p = null;
                return null;
            }
            else{
                //otherwise return intersection point 
                return p;
            }
        }
        return p;
    }

    
    
    /**
     * Vector Displacement Error
     * 
     * 1. Display Line To Measure                                      
     * 2. Display points of line and point labels                                                               
     * 3. Create simplified Line Hashed (start point, end point)
     * 4. For each intermediate point
     *       4.1. Create distortion line (hashed)                                                               
     *       4.2. Draw distortion line for point perpendicular to simplified line                               
     *       4.3. If distortion line is greater than max distribution line                                      
     *           4.3.1.  Store distortion line and label "Max Distortion Line"  
     * 5. Create and display Max Distortion Line (solid line thick colour)                                                  
     *         
     * Mean and Standard Deviation for Vector Displacement measures
     * Ref: https://www.mathsisfun.com/data/standard-deviation-formulas.html
     * 
     * @param originalLinePts - Points representing the original line 
     * @param simplifiedLinePts - Points representing the simplified line
     * @return liner - Collection of lines representing distortion lines
     */
    
    public ArrayList<Liner> vectorDisplacementError(ArrayList<Point> 
            originalLinePts, ArrayList<Point> simplifiedLinePts){
    
    ArrayList<Liner> distortionLines = new ArrayList<>();
    ArrayList<Liner> simplifiedLineSegments = new ArrayList<>();
    Liner simplifiedLineSegment = null;
    ArrayList<Point> intermediatePointsForDistortionLines = new ArrayList<>();
    int startIndex = 0;
    int endIndex = 0;
    List <Point> list;
    List<Point> sublist;
    ArrayList<Point> ALSublist;
    ArrayList<ArrayList<Point>> arrayListOfarrayLists;
    Liner maxDistortionLine = null;
    double maxDistortionDistance = 0;
    double sumOfDistortionLineLengths = 0;
    double sumOfSimplifiedLineSegments = 0;
    double standardDeviationDistortionDistance = 0;
    LineSimplification ls = new LineSimplification(); 
    ArrayList<Point> ptsResults = new ArrayList<>();
      
    
    //1. Divide simplified line points into simplifed line segments
    //and get simplified line. Also get sum of simplified line segments 
    for (int i = 0; i < simplifiedLinePts.size()-1; i++){
        Point p1 = simplifiedLinePts.get(i);
        Point p2 = simplifiedLinePts.get(i+1);
        simplifiedLineSegment = new Liner(p1, p2); 
        simplifiedLineSegments.add(simplifiedLineSegment);
        double segmentLength = simplifiedLineSegment.getLength();
        sumOfSimplifiedLineSegments = sumOfSimplifiedLineSegments 
                + segmentLength; 
    }
    
    arrayListOfarrayLists = new ArrayList<ArrayList<Point>>();
    
    //2. For each simplified line segment partition the 
    //   original line points into listOfLists
    for (int j = 0; j < simplifiedLineSegments.size(); j++){
        simplifiedLineSegment = simplifiedLineSegments.get(j);
        
        Point p3 = simplifiedLineSegment.getLinerPoint1();
        Point p4 = simplifiedLineSegment.getLinerPoint2();
        
        for (int m = 0; m < originalLinePts.size(); m++){
            Point p5 = originalLinePts.get(m);
            if (p5.getID().equals(p3.getID())){
                startIndex = m;
            }
            if (p5.getID().equals(p4.getID())){
                endIndex = m+1;
            }
        }
           
        list = new ArrayList<>(originalLinePts);
        sublist = list.subList(startIndex,endIndex);
        ALSublist = new ArrayList<>(sublist);
        arrayListOfarrayLists.add(ALSublist);
    }
        
    //3.DEBUG - Print out each sublists to console
    for(int y = 0; y < arrayListOfarrayLists.size(); y++){
        ALSublist = arrayListOfarrayLists.get(y);
        System.out.println("List " + y);
        for (int b = 0; b < ALSublist.size(); b++){
            System.out.println("Pt: " + ALSublist.get(b).getID());
        }
    }
        
    //Create perpendicular lines (distortion lines for each list
    for(int y = 0; y < arrayListOfarrayLists.size(); y++){
         ArrayList<Point> al = arrayListOfarrayLists.get(y);
         Point startPoint = al.get(0);
         Point endPoint = al.get(al.size()-1);
         for (int r = 1; r < al.size()-1; r++){
             
            Point p = al.get(r);
            Liner simplifiedLine = new Liner(startPoint,endPoint);
            
            double distortionDistance = ls.distanceOfPointPerpendicularToLine(p,
                    simplifiedLine);
             
            //Create Point (p2) where distortion distance intersects 
            //simplified line
            String coord =  "p" + r + "," + createPerpendicularPoint(p, 
                    startPoint, endPoint);
            Point p2 = new Point(coord);
            Liner distortionLine = new Liner(p,p2);
            distortionLines.add(distortionLine); 
        
          
            boolean isPtRightOfLine = isPointRightOfLine(p, simplifiedLine);

            //Get the sum of the distortion line segments 
            //(vector displacement lines)
            double distortionLineSegmentLength = distortionLine.getLength();

            if (isPtRightOfLine){
                System.out.println("Point " + al.get(r).getID() + 
                      " is right of Simplfied Line , Distortion Line length: " + 
                    distortionLineSegmentLength);
            }    
            else{
                distortionLineSegmentLength *= -1;
                System.out.println("Point " + al.get(r).getID() + 
                      " is left of Simplified Line , Distortion Line length: " + 
                    distortionLineSegmentLength);
            }
         
            //sumOfDistortionLineLengths = distortionLineSegmentLength + 
            //        sumOfDistortionLineLengths; //Originally had -/+ values 
            sumOfDistortionLineLengths = Math.abs(distortionLineSegmentLength) + 
                 sumOfDistortionLineLengths; 
            System.out.println("Point " + al.get(r).getID() + 
                    " Distortion Line distance: " + distortionLineSegmentLength);
    
            //Determine the maximum distortion line 
            if (distortionDistance > maxDistortionDistance){
                maxDistortionDistance = distortionDistance;
                maxDistortionLine = new Liner(p, p2);
            }  
         }
    }
   
      //Calculate standardised vector displacement formula 
      double standardizedVectorDisplacement = sumOfDistortionLineLengths /
              sumOfSimplifiedLineSegments;
      System.out.println("Simplified line length: " +
            String.format("%8.2f", sumOfSimplifiedLineSegments));
      System.out.println("Maximum vector distortion line distance: " + 
            String.format("%8.2f", maxDistortionDistance));
      System.out.println("Mean vector disortion line distance: " +
            String.format("%8.2f", sumOfDistortionLineLengths / 
                    distortionLines.size()));
      System.out.println("Standard deviation distortion line distance: " +
            String.format("%8.2f", 
                    calculateStandardDeviationDistortionDistance(
                            sumOfDistortionLineLengths / distortionLines.size()
                            , distortionLines)));
      System.out.println("No of distortion line distances: " +
            distortionLines.size());
      System.out.println("Sum of vector distortion line distances: " + 
            String.format("%8.2f", sumOfDistortionLineLengths));
      System.out.println("Standardized vector displacement: " + 
            String.format("%8.6f" , standardizedVectorDisplacement));  
 
      setSumOfSimplifiedLineSegments(sumOfSimplifiedLineSegments);
      setMaxDistortionDistance(maxDistortionDistance);
      setMeanDistortionDistance(sumOfDistortionLineLengths / 
                    distortionLines.size());
      setStandardDeviationDistortionDistance(
              calculateStandardDeviationDistortionDistance(
                            getMeanDistortionDistance(), distortionLines));
      setNoOfDistortionLines(distortionLines.size());
      setSumOfDistortionLineLengths(sumOfDistortionLineLengths);
      setStandardizedVectorDisplacement(String.format("%8.6f" ,
              standardizedVectorDisplacement));
  
    return distortionLines; 
}
    
    
    /**
     * Calculate Standard Deviation Distortion Distance
     * 
     * Ref: https://www.mathsisfun.com/data/standard-deviation-formulas.html
     * 
     * @param mean - Value representing the mean distortion line distance 
     * @param distortionLines - Collection representing the distortion lines
     * @return standardDeviationDistortionDistance - Value representing variance
     * standardDeviationDistortionDistance 
     */
    private double calculateStandardDeviationDistortionDistance(
            double meanDistortionDistance, 
            ArrayList<Liner> distortionLines){
        double standardDeviationDistortionDistance = 0;
        double sum = 0;
        
       
        for (int i = 0; i < distortionLines.size(); i++){
            Liner line = distortionLines.get(i);
               double stdDev = Math.pow(line.getLength() 
                       - meanDistortionDistance, 2);
               sum = sum + stdDev;
        }
        System.out.println("Sum " + sum);
        
        double meanSquareDifferences = (1.0 / distortionLines.size()) * sum;
        
        System.out.println("mean square difference " + meanSquareDifferences);
        standardDeviationDistortionDistance = Math.sqrt(meanSquareDifferences);
        System.out.println("standard deviation distance " + 
                standardDeviationDistortionDistance);
        return standardDeviationDistortionDistance;
    }
  

    /**
     * Is Point Right of Line
     * 
     * Determines if given point is to the left or right of input line
     * Checks to see if point is to the left or right of a line 
     * Based on line stored with start and end points for a lead read in a 
     * clockwork direction. Based on Solution 3 formula from
     * ref: http://paulbourke.net/geometry/pointlineplane/
     *
     * @param p - Point checked to see if right of the line
     * @param line - Line required for the test 
     * @return true or false - True if the point is right of the line. Otherwise
     * false
     */

    public boolean isPointRightOfLine(Point p, Liner line){
        //if calculation less than 0 then P is to the right of the line segment 
        //if calculation more than 0 then P is to the left of the line segment 
        //if calculation equals 0 then P it lies on the line segment  
        boolean isRight = false;
        int counter = 0;
        Point p1 = line.getLinerPoint1();
        Point p2 = line.getLinerPoint2();
        int x1 = p1.getX();
        int y1 = p1.getY();
        int x2 = p2.getX();
        int y2 = p2.getY();
        int px = p.getX();
        int py = p.getY();

        int calculation = (py - y1) * (x2 - x1) - (px - x1) * (y2 - y1);
              
        if (calculation < 0){
            isRight = true;
        }
        return isRight;
    }

   
    /**
     * Area Displacement Error
     * 
     * 1. Get the coordinates of the irregular polygon(s)
     * 2. Determine the number of polygon areas formed between the original 
     *    and simplified lines
     * 3. For each polygon
     * 4.   Store x,y coordinates of each polygon point in an array list
     * 5.   Multiply the x coordinate of point with y coordinate of next point 
     *      in array list to get a value A
     * 6. Sum all of the A values 
     * 7. Multiply the y coordinate of point with x coordinate of next point in
     *    array list to get a value B
     * 8. Sum all of the B values
     * 9. Polygon area is equal to Sum B value subtracted from Sum A value and 
     *    dividing the result by 2
     * 10 Repeat 3 - 10 for each polygon area
     * 11 Sum all polygon areas to get area displacement
     * 
     * Ref: http://www.wikihow.com/Calculate-the-Area-of-a-Polygon#Finding_the_
     * Area_of_Irregular_Polygons_sub
     * @param originalLinePts - Points representing the original line
     * @param simplifiedLinePts - Points representing the simplified line
     * @return polygons - Collection if polygons each representing subparts
     * of the complete polygon formed between the original and simplified lines 
     */ 
    
        public ArrayList<Polygon> areaDisplacementError(ArrayList<Point> 
                originalLinePts, ArrayList<Point> simplifiedLinePts){
       
        String newLine = "\n";    
        ArrayList<Polygon> polygons = new ArrayList<>(); 
        ArrayList<Liner> distortionLines = new ArrayList<>();
        ArrayList<Liner> simplifiedLineSegments = new ArrayList<>();
        Liner simplifiedLineSegment = null;
        ArrayList<Point> intermediatePointsForDistortionLines = new ArrayList<>();
        int startIndex = 0;
        int endIndex = 0;
    
        ArrayList<Point> ALSublist = null;    
        ArrayList<ArrayList<Point>> arrayListOfarrayLists = new ArrayList<>();
        ArrayList<ArrayList<Point>> leftPolygons = new ArrayList<>();
        ArrayList<ArrayList<Point>> rightPolygons = new ArrayList<>();
            
        ArrayList<Point> polygonList = null;
        
        Liner maxDistortionLine = null;
        double maxDistortionDistance = 0;
        double sumOfDistortionLineLengths = 0;

        double sumOfSimplifiedLineSegments = 0;
        ArrayList<Point> ptsResults = new ArrayList<>();
        Point startPoint = null; 
        
        //1. Divide simplified line points into simplifed line segments
        for (int i = 0; i < simplifiedLinePts.size()-1; i++){
            polygonList = new ArrayList<>();
            
            Point p1 = simplifiedLinePts.get(i);
            Point p2 = simplifiedLinePts.get(i+1);
            simplifiedLineSegment = new Liner(p1, p2); 
            simplifiedLineSegments.add(simplifiedLineSegment);   
        }
        
        arrayListOfarrayLists = new ArrayList<>();
    
        //2. For each simplified line segment, use to partition the original line
        //   points into arrayListOfArrayLists (polygons)
        for (int j = 0; j < simplifiedLineSegments.size(); j++){
            simplifiedLineSegment = simplifiedLineSegments.get(j);
        
            Point p3 = simplifiedLineSegment.getLinerPoint1();
            Point p4 = simplifiedLineSegment.getLinerPoint2();
        
            for (int m = 0; m < originalLinePts.size(); m++){
                Point p5 = originalLinePts.get(m);
           
                if (p5.getID().equals(p3.getID())){
                    startIndex = m;
                    startPoint = originalLinePts.get(m);
                }
                if (p5.getID().equals(p4.getID())){
                    endIndex = m+1;
                }
            }
           
            //Creating list of lists using sublist(startIndex and endIndex)
            //Converting to arrayList of arrayLists(arrayListOfarrayLists)
            List<Point> list = new ArrayList<>(originalLinePts);
            List<Point> sublist = list.subList(startIndex,endIndex);
          
        //Add start point as extra point (end point) to the list
        //to close the polygons
        sublist.add(startPoint);
            ALSublist = new ArrayList<>(sublist);
            arrayListOfarrayLists.add(ALSublist);
        }
        
        
        //Determine if each polygon is left or right of simplified line 
        //Done by checking if intermediate points are right or left or
        //the simplified line (formed from the start and end points in each 
        //sublist  
        //boolean isOriginalPtRightOfSimplifiedLineSegment = false;
        for(int f = 0; f < arrayListOfarrayLists.size(); f++){
            ALSublist = arrayListOfarrayLists.get(f);
                Point intermediatep = ALSublist.get(1);
                Point startp = ALSublist.get(0);
                Point endp = ALSublist.get(ALSublist.size()-2);
                Liner simplifiedLn = new Liner(startp, endp);
                
                boolean isOriginalPtRightOfSimplifiedLineSegment = 
                    isPointRightOfLine(intermediatep, simplifiedLn);
            
            System.out.println(isOriginalPtRightOfSimplifiedLineSegment);    
            if(isOriginalPtRightOfSimplifiedLineSegment == true){
                rightPolygons.add(new ArrayList<Point>(ALSublist));
            }
            else{
                leftPolygons.add(new ArrayList<Point>(ALSublist));
            }
           
        }
      
        //DEBUG - print value for rightPolygons
        for(int r = 0; r < rightPolygons.size(); r++){
            System.out.println("Right Polygon:" + r);
            ArrayList<Point> list1 = rightPolygons.get(r);
            for(int w = 0; w < list1.size(); w++){
                Point p = list1.get(w);
                System.out.println(p.getID());
            }
            
        }
        //DEBUG - print value for leftPolygons
        for(int s = 0; s < leftPolygons.size(); s++){
            System.out.println("Left Polygon:" + s);
            ArrayList<Point> list2 = leftPolygons.get(s);
            for(int d = 0; d < list2.size(); d++){
                Point pp = list2.get(d);
                System.out.println(pp.getID());
            }
            
        }
        
        int[] xCoords;
        int[] yCoords;
        
        ////////////////////
        //Check all polygons for self intersecting polygons and split
        //self intersecting polygons into two        
     //   polygonList2 = new ArrayList<>(calculateIntersectionPointBetweenTwoLines(polygonList));
        
        ////////////////////
        
        
        //3.DEBUG - Print out each sublists to console
        for(int y = 0; y < arrayListOfarrayLists.size(); y++){
            ALSublist = arrayListOfarrayLists.get(y);
            
            System.out.println("List " + y);
            xCoords = new int[ALSublist.size()];
            yCoords = new int[ALSublist.size()];
            
            for (int b = 0; b < ALSublist.size(); b++){
                System.out.println("Pt: " + ALSublist.get(b).getID());
                int xCoord = ALSublist.get(b).getX();
                int yCoord = ALSublist.get(b).getY();
                xCoords[b] = xCoord;
                yCoords[b] = 600 - yCoord;
            }
            
           
            System.out.println("List Size: " + ALSublist.size());
            Polygon polygon = new Polygon(xCoords,yCoords,ALSublist.size());
            
            //Finally add polygon list if it has 2 or more points to polygon 
            //lists
            if (ALSublist.size() > 2){
                polygons.add(polygon);
            }
            
            //Printout simplifiedPts FOR DEBUG
            System.out.println("Simplified pts");
            for(int h = 0; h < simplifiedLinePts.size(); h++){
                System.out.println(simplifiedLinePts.get(h).getID());
            }
            
            
                                   
            calculatePolygonAreas(arrayListOfarrayLists,simplifiedLinePts);   
            double sumLeftPolygonAreas = 
                    calculatePolygonAreas(leftPolygons,simplifiedLinePts);
            setSumLeftPolygonAreas(sumLeftPolygonAreas);
            double sumRightPolygonAreas = 
                    calculatePolygonAreas(rightPolygons,simplifiedLinePts);
            setSumRightPolygonAreas(sumRightPolygonAreas);
            double sumPolygonAreas = 
                    sumLeftPolygonAreas + sumRightPolygonAreas;
            setSumPolygonAreas(sumPolygonAreas);
            double uniformDistortion = 
                    calculateUniformDistortion(sumPolygonAreas, simplifiedLinePts);
            setUniformDistortion(uniformDistortion);
            System.out.println("Sum Left Polygon Areas: " + sumLeftPolygonAreas);
            System.out.println("Sum Right Polygon Areas: " + 
                    sumRightPolygonAreas);
            System.out.println("Area distortion:" +
                    sumPolygonAreas);
            System.out.println("Uniform distortion: " + 
                    uniformDistortion);
            setAreaDistortion("" + sumPolygonAreas);
            String strUniformDistortion = "" + 
                    String.format("%.2f", uniformDistortion); 
          
            setStandardizedAreaDisplacement("" + strUniformDistortion);
        }
        
    //// TESTING OUT calculateIntersectionPointBetweenTwoLines TO REMOVE  
    
        polygonList = new ArrayList<>();
        polygonList.add(new Point("p6,241,409"));
        polygonList.add(new Point("p7,321,442"));
        polygonList.add(new Point("p8,358,323"));
        polygonList.add(new Point("p9,447,119"));
        polygonList.add(new Point("p10,479,250"));
        polygonList.add(new Point("p11,523,406"));
        polygonList.add(new Point("p6,241,409"));   
        ArrayList<Point> polygonList2 = new ArrayList<Point>();
        polygonList2 = new ArrayList<>(calculateIntersectionPointBetweenTwoLines(polygonList));
        //Print polygon list
        System.out.println("TESTING calculateIntersectionPointBetweenTwoLines");
        System.out.println("The polygonList2 contents is:");
        for(int i = 0; i < polygonList2.size(); i++){
            System.out.println(polygonList2.get(i).getID());
        }
        
       ArrayList<List<Point>> resultPolygons  = new ArrayList<List<Point>>(splitPolygon(polygonList2));
       for (int i = 0; i < resultPolygons.size(); i++){
            ArrayList<Point> polygon3 = new ArrayList<>(resultPolygons.get(i));
            System.out.println("Polygon " + (i+1) + ":");
            for (int j = 0; j < polygon3.size(); j++){
                Point p = polygon3.get(j);
                System.out.println(p.getID());
            }   
       }
       /////////////////// 
     
        return polygons;
     }
    
        
    /**
     * Add intersection Points To Polygons
     * 
     * Intersection point (NOT WORKING WAS TO BE CALLED BY AREADISPLACEMENT ERROR
     *  
     * @param polygonLists - Sub-lists of points each representing a polygon
     * @return Points - Collection of point sub-lists each representing the 
     * a polygon
     */    
     public ArrayList<ArrayList<Point>> addIntersectionPointsToPolygons(
         ArrayList<ArrayList<Point>> polygonLists){
         ArrayList<Point> polygonList = new ArrayList<>();
         ArrayList<Point> polygonList2 = new ArrayList<>();
         ArrayList<Point> polygonList3 = new ArrayList<>();
         ArrayList<Point> polygonList4 = new ArrayList<>();
         ArrayList<List<Point>> polygonLists4 = null;
         ArrayList<ArrayList<Point>>finalPolygonLists = 
                 new ArrayList<ArrayList<Point>>();
         int noOfIntersectionPts = 0;
         
        //Check each polygon (polygonList) to see if it is self intersecting
        //if it is self intersecting split polygon into smaller polygons
        for (int m = 0; m < polygonLists.size(); m++){
            polygonList = polygonLists.get(m);
            System.out.println("Polygon " + (m + 1));

            //If polygonList is a self intersecting polygon, determine the
            //no of intersection(s) (polygonList2).
            polygonList2 = calculateIntersectionPointBetweenTwoLines(polygonList);

            if (polygonList2 == null){
                finalPolygonLists.add(polygonList);
            }
            else{
                for (int j = 0; j < polygonList2.size(); j++){
                    polygonList3.add(polygonList2.get(j));

                    //Check no of intersections point(s)
                    if(polygonList2.get(j).getID().equals("p9")){
                        noOfIntersectionPts = noOfIntersectionPts + 1;
                    }
                }
                //Add polygon where there are no intersections (regular polygon)
                //to result list (finalPolygonLists)
                if (noOfIntersectionPts == 0){
                    finalPolygonLists.add(polygonList);
                }
                //Add polygon where there is a self intersection to 
                //result list (finalPolygonLists)
                else if (noOfIntersectionPts > 0) {   
                    //finalPolygonLists.add(polygonList3);
                    //polygonLists4 = splitPolygon(polygonList3); //COMMENTED OUT
                    for (int w = 0; w < polygonLists4.size(); w++){
                        List<Point> al2 = polygonLists4.get(w);
                        ArrayList<Point> temp = new ArrayList<>();
                        for(int i = 0; i < al2.size(); i++){
                            Point p = al2.get(i);
                            temp.add(p);
                        }
                        finalPolygonLists.add(temp);
                    }

                }
                System.out.println("There are " + noOfIntersectionPts + 
                        " intersection points in polygon " + (m + 1));
            }

        }
        
        //Printout results of finalPolygonLists FOR DEBUG
        for (int f = 0; f < finalPolygonLists.size(); f++){
            polygonList4 = finalPolygonLists.get(f);
            System.out.println("Polygon " + (f));
            for(int d = 0; d < polygonList4.size(); d++){
                System.out.println(polygonList4.get(d).getID());
            }
        }
        return finalPolygonLists;
     }   
        
             
    /**
     * Split polygon
     * 
     * Takes a polygon list and splits it into two where there
     * is a self intersection i.e where intersection point id = 999
     * 
     * @param polygonList - Point lists representing a single polygon
     * @return ArrayList - List of Polygons. Each polygon is a point list.
     */ 
     
    public ArrayList<ArrayList<Point>> splitPolygon(ArrayList<Point> polygonList)
    {
        ArrayList<ArrayList<Point>> polygonLists = new ArrayList<>();
        List<Point> pts = polygonList;
        int intersectionPtIndex = 0;
        Point intersectionPt = null;
        
        //Get index of point with point id = 999
        for (int i = 0; i < pts.size(); i++){
            Point point = pts.get(i);
            if(point.getID().equals("p999")){
                intersectionPtIndex = i;
                intersectionPt = pts.get(i);
            }
        }
        
        //Split self intersected polygon in two and return list 
        //(polygonLists) of 2 polygons
        List<Point> polygon = pts.subList(0, intersectionPtIndex + 1);
        polygon.add(pts.get(0));
        polygonLists.add(new ArrayList<>(polygon));
        pts = pts.subList(intersectionPtIndex + 2, pts.size()-1);
        pts.add(0,intersectionPt);
        pts.add(intersectionPt);
        polygonLists.add(new ArrayList<>(pts));
        
        return polygonLists;
    }

    /**
     * Remove duplicate points
     * 
     * Called by method calculateIntersectionPointBetweenTwoLines
     * 
     * Removes duplicate points from an array list
     * 
     * To get of rid of duplicate points for array list. One method is below -
     * I could not get that to work
     * @param pts - Point list that require removal of duplicate points
     * @return points - Collection of points without duplicate points
     * 
     */
    public ArrayList<Point> removeDuplicatePoints(ArrayList<Point> pts){
        //Making sure there are no duplicate points in pts list. 
        ArrayList<Point> ls = new ArrayList<>();
        for (int i = 0; i < pts.size(); i++){
            Point point = pts.get(i);
            if(!(ls.contains(point))){
                ls.add(pts.get(i));
            }
        }
        return ls;
    }

    /**
     * Calculate Intersection Point(s) from Two Lines
     *          
     * @param polygonList - Point list representing a polygon
     * @return polygonList - Point list representing a polygon
     */
    public ArrayList<Point> calculateIntersectionPointBetweenTwoLines(
        ArrayList<Point> polygonList){
        //Check if polygon contains self intersecting line(s) 
        //by checking for each polygon line segment if it intersects 
        //any of the other polygon line segments in the polygon
        Point intersectionPoint = null;
        ArrayList<ArrayList<Point>> polygonListsFinal = new ArrayList<>();
        ArrayList<Point> polygonList2 = new ArrayList<>();
        ArrayList<Point> polygonList3 = new ArrayList<>();
        ArrayList<Point> dedupeOfIntersectionPts = new ArrayList<>();
 
        int counter = 0;
        int indexOfPt4 = 0;

        Point pt1 = polygonList.get(0);     //Get pt1 of line segment
        Point pt2 = polygonList.get(polygonList.size()-2); //Get pt2 of line segment
        Liner line1 = new Liner(pt1,pt2);
            
        //Compare with each of the other line segment(s) in 
        //polygon (polygonList)
        for (int h = 0; h < polygonList.size() - 1; h++){
            Point pt3 = polygonList.get(h);     //Get pt1 of line segment
            Point pt4 = polygonList.get(h + 1); //Get pt2 of line segment
            Liner line2 = new Liner(pt3,pt4);   

            indexOfPt4 = h + 1;

            //Get point of intersection (p)
            Point p = isLineSegmentsIntersecting2(line1, line2);

            if (p == null){

            }
            else{
                 //For DEBUG
                    System.out.println("line1: " + line1.getLinerPoint1().getID() +
                    "," + line1.getLinerPoint2().getID() + 
                    " line2: " + line2.getLinerPoint1().getID() +
                    "," + line2.getLinerPoint2().getID() + 
                    ",intersection point: " + p.getID() + "," + p.getX() + 
                    "," + p.getY());


                LineSimplification ls = new LineSimplification();
                //Check point of intersection is not in polygon list
                //and then add it 
                if(!ls.isPointInLine(p, polygonList)){
                    dedupeOfIntersectionPts.add(p);
                    //System.out.println("Intersection point p is " + p.getID()
                    //        + "," + p.getX() + "," + p.getY()); 
                }
            }
        }
       
        dedupeOfIntersectionPts = removeDuplicatePoints(dedupeOfIntersectionPts);        
        System.out.println("Size of dedupedpts is " + 
                dedupeOfIntersectionPts.size());

        int indexOfIntersectionPt = indexPositionOfPointOfIntersection(polygonList);
        System.out.println("Intersection point index: " + 
                (indexOfIntersectionPt - 1));
        
        //Put intersection point into polygonList
        for (int q = 0; q < dedupeOfIntersectionPts.size(); q++){            
            polygonList.add(indexOfIntersectionPt, dedupeOfIntersectionPts.get(q));
        }
        
        return polygonList;
    }

    /**
     * Index position of Point of Intersection
     *
     * Returns index position in array list of point of intersection  
     * @param polygonList - Point list whose points representing a polygon
     *                      whose line segments are formed and checked to see
     *                      if there is a point of intersection. 
     * @return index position of the point of intersection for a polygons points
     * 
     */
    public int indexPositionOfPointOfIntersection(ArrayList<Point> polygonList){
        int pointOfIntersectionIndexPos = 0;
        Point intersectionPoint = null;
        ArrayList<ArrayList<Point>> polygonListsFinal = new ArrayList<>();
        ArrayList<Point> polygonList2 = new ArrayList<>();
        ArrayList<Point> polygonList3 = new ArrayList<>();

        int indexOfPt4 = 0;
        
        Point pt1 = polygonList.get(0);                    //Get pt1 of line segment
        Point pt2 = polygonList.get(polygonList.size()-2); //Get pt2 of line segment
        Liner line1 = new Liner(pt1,pt2);
        
            //Compare with each of the other line segment(s) 
            //in polygon (polygonList)
            for (int h = 0; h < polygonList.size() - 1; h++){
                Point pt3 = polygonList.get(h);
                Point pt4 = polygonList.get(h + 1);
                Liner line2 = new Liner(pt3,pt4);
                indexOfPt4 = h + 1;

                //Get point of intersection (p)
                Point p = isLineSegmentsIntersecting2(line1, line2);
                if (p == null){
                    
                }
                else{
                    pointOfIntersectionIndexPos = indexOfPt4;
                }
            }
        return pointOfIntersectionIndexPos;
    }

   
    /**
     * Calculate Polygon Areas
     * Creates and calculates area of polygons between the 
     * original line and simplified line 
     * 
     * Called by areaDisplacementError method
     * 
     * ref: https://en.wikipedia.org/wiki/Shoelace_formula
     * @param polygonLists - Point lists. Each representing a polygon
     * @param simplifiedPts - Points representing the simplified line
     * @return polygon area - Sum of polygon area(s)
     */ 

    public double calculatePolygonAreas(ArrayList<ArrayList<Point>>polygonLists,
            ArrayList<Point> simplifiedPts){
       
        int polygonCounter = 0;
        double sumProduct1 = 0;
        double sumProduct2 = 0;
        double sumPolygonArea = 0;   
        
     
        //Calculate and display polygon Area(s) size measures in GUI
        for(int k = 0; k < polygonLists.size(); k++){
            ArrayList<Point> polygonList = polygonLists.get(k);
            //1. Check each polygon list has more than 2 points
            if (polygonList.size() > 2){

                //4. Calculate Polygon Area 
                polygonCounter++;
                for (int m = 0; m < polygonList.size()-1; m++){
                    Point p1 = polygonList.get(m);
                    Point p2 = polygonList.get(m + 1);  

                    //multiply p1.x * p2.y
                    double product1 = p1.getX() * p2.getY();
                    sumProduct1 = product1 + sumProduct1;

                    //multiply p1.y * p2.x
                    double product2 = p1.getY() * p2.getX();
                    sumProduct2 = product2 + sumProduct2;
                }
                
                double diff;
                if (sumProduct1 > sumProduct2){
                    diff = sumProduct1 - sumProduct2;
                }
                else{
                    diff = sumProduct2 - sumProduct1;
                }

                System.out.println("sumProduct1 " + sumProduct1);
                System.out.println("sumProduct2 " + sumProduct2);
                System.out.println("diff " + diff);   
                double polygonArea = diff/2;

                sumPolygonArea = polygonArea + sumPolygonArea;
                System.out.println("Polygon Area " + (k+1) + " is: " 
                        + polygonArea);
            }   
          
            sumProduct1 = 0;
            sumProduct2 = 0;
        }
        System.out.println("Sum Polygon Area: " + sumPolygonArea);
        System.out.println("Total No of Polygon Area(s): " + polygonCounter);
        
        return sumPolygonArea;
    }

    /**
     * Calculate Uniform Distortion
     * 
     * Calculates uniform distortion measure which is the sum of polygon area 
     * differences divided by simplified line length
     * 
     * Called by method areaDisplacementError
     *
     *@param sumPolygonAreas - Sum of polygon areas
     *@param simplifiedLine - Points representing the simplified line 
     *@return uniformDistortion - Value representing the Uniform Distance 
     *                            Distortion measure
     */
    public double calculateUniformDistortion(double sumPolygonAreas, 
            ArrayList<Point> simplifiedLine){
        double sumSimplifiedLineLength = 0;
        for(int i = 0; i < simplifiedLine.size() - 1; i++){ 
            //Get start and end points for each line segment in Simplified Line 
            Point startPt = simplifiedLine.get(i);
            Point endPt = simplifiedLine.get(i+1);
            double x1 = startPt.getX();
            double y1 = startPt.getY();
            double x2 = endPt.getX();
            double y2 = endPt.getY();

            //Calculate each line segment length from Simplified Line 
            double distance = Math.sqrt(Math.pow(x2 - x1 ,2) +
                    Math.pow(y2 - y1, 2));
            sumSimplifiedLineLength = distance + sumSimplifiedLineLength;
        }
        double uniformDistortion = sumPolygonAreas / sumSimplifiedLineLength;
        return uniformDistortion;
    }

    /**
     * Create New Point which is perpendicular to simplified line using:
     * Existing Point, Bearing Angle of Simplified Line and Distortion Distance
     * 
     * 
     * Using surveying formula
     * REF: Slide 6 www.tcd.ie/civileng/Staff/Brian.Caulfield/.../
     * 3A1%20Lecture%207.pdf
     * 
     * USING VECTOR SOLUTION
     * https://uk.answers.yahoo.com/question/index?qid=20080919104705AAhtY3e 
     * USING VECTOR SOLUTION
     * https://www.youtube.com/watch?v=H98iBqt1fFQ 
     * DETERMINING SLOPE OF A LINE
     * http://www.mathwarehouse.com/algebra/linear_equation/slope-of-a-line.php 
     * ONE USED!
     * http://classroom.synonym.com/coordinates-distances-angles-2732.html  
     * @param point - Point required to calculate bearing
     * @param distance - Distance value required to calculate bearing
     * @param bearing - Bearing of starting point
     * @return String coordinate - Representing coordinate of point createed from 
     *                             starting point, bearing and distance.
     */
    private String createPointFromPointBrgAndDist(Point point, double distance, 
            double bearing){
        double eastingB = point.getX() + distance * Math.cos(bearing);
        double northingB =  point.getY() + distance * Math.sin(bearing);
        int easting = (int) eastingB;
        int northing = (int) northingB;
        String coord = "" + easting + "," + northing;
        return coord;
    }

    /**
     * Create New Point which is perpendicular to simplified line using, Existing Point
     * 
     * Called by method vectorDisplacementError
     * 
     * Ref: http://stackoverflow.com/questions/1811549/perpendicular-on-a-line-
     * from-a-given-point
     * Ref: http://stackoverflow.com/questions/10301001/perpendicular-on-a-line-
     * segment-from-a-given-point
     * 
     * @param point
     * @param startPoint - The point representing the start point of the
     *                     simplified line
     * @param endPoint - The point representing end point of simplified line
     * @return coordinate - Coordinate as string for point of intersection where 
     *                      distortion line is perpendicular to simplified line
     */
    public String createPerpendicularPoint(Point point, Point startPoint, 
            Point endPoint){
        int x1 = startPoint.getX();
        int x2 = endPoint.getX();      
        int y1 = startPoint.getY();
        int y2 = endPoint.getY();
        int x3 = point.getX();
        int y3 = point.getY();

        double t = ((x3-x1)*(x2-x1)+(y3-y1)*(y2-y1))/
                (Math.pow((x2-x1),2)+ Math.pow((y2-y1),2));

        //Get coordinates for point of Intersection.
        double interSectionPtX = x1+t*(x2-x1);
        double interSectionPtY = y1+t*(y2-y1);

        int x = (int) Math.round(interSectionPtX);
        int y = (int) Math.round(interSectionPtY);

        String coord = "" + x + "," + y;    
        
        return coord;
    }

 
    /**
     * Ratio in Change of Angularity (sinuosity) - Measures Angularity of a line 
     * 
     * Measures non similarity of the simplified line and the original line
     * 
     * This function uses a linear attribute measurement to determine similarity
     * or non similarity of a line. In this case the linear attribute measurement
     * used is the angle of inclination at each vertices of the original line and
     * also in the simplified line. Angle of inclination of each line section is
     * measured from a line parallel to the x axis and measures counter clockwise
     *(in maths terms) to get the angle of the line.
     * 
     * formula: Ratio in change of Angularity = 
     *        (sum of angles for line segments in simplified line / 
     *        sum of angles of change for the segments in original line) x 100
     * 
     * @param originalLine - Points representing the orginal line
     * @param simplifiedLine - Points representing the simplified line
     * @return ratioOfChangeInAngularity - Value representing the Ratio of 
     *                      Change in Angularity measure
     */
    public double ratioInChangeOfAngularity(ArrayList<Point> originalLine, 
            ArrayList<Point> simplifiedLine){
        double sumAnglesOfChangeInOriginalLine = Math.round((
                sumAnglesOfChange(originalLine) / 100) * 100);
        double sumAnglesOfChangeInSimplifiedLine = 
                Math.round((sumAnglesOfChange(simplifiedLine) / 100) * 100);
        double ratioInChangeOfAngularity = Math.round((((
                sumAnglesOfChangeInSimplifiedLine / 
                        sumAnglesOfChangeInOriginalLine) * 100) / 100) * 100);
        
        System.out.println("Sum Angles Of Change In Original Line: " + 
                sumAnglesOfChangeInOriginalLine); 
        System.out.println("Sum Angles Of Change In Simplified Line: " +
                sumAnglesOfChangeInSimplifiedLine); 
        System.out.println("Ratio In Change of Angularity: " + 
                ratioInChangeOfAngularity);   
        return ratioInChangeOfAngularity;
    }

    /**
     * Sum Angles of Change
     * 
     * Calculates the sum of all angles of change in a line where an angle of 
     * change is an angle of inclination 
     * of each line section measured from a line parallel to the x axis and 
     * measures counter clockwise (in maths terms)
     * to get the angle of the line.
     * 
     * Called by method ratioInChangeOfAngularity
     * 
     * @param line - Points representing the line whose angles of change 
     *               are to be summed
     * @return sumOfAngles - Sum of angles of change for the line
     * 
     */
    private double sumAnglesOfChange(ArrayList<Point> line){
        
        double angleOfInclination = 0;
        double sumOfAngles = 0;
        int lineSegmentCounter = 0;
        ArrayList<Double> lineSegmentBearings = new ArrayList<>();

        //Get each pair of points for each line segment in line
        for (int i = 0; i < line.size() - 1; i++){
            lineSegmentCounter = lineSegmentCounter + 1;
            Point startPoint = line.get(i);
            Point endPoint = line.get(i+1);

            //Calculate bearing of each line segment in line
            Liner liner = new Liner(startPoint, endPoint);
            double bearingOfTangent = liner.calculateBearingofLine(startPoint, 
                    endPoint);
            System.out.println("bearing of line segment " + lineSegmentCounter +
                    "," + bearingOfTangent); 
            lineSegmentBearings.add(bearingOfTangent);
        }

        for (int j = 0; j < lineSegmentBearings.size() - 1; j++){
            double bearing1 = lineSegmentBearings.get(j);
            double bearing2 = lineSegmentBearings.get(j + 1);
            int angleOfInclinationCounter = 0;

            if (bearing1 < bearing2){
                angleOfInclination = (bearing2 - bearing1);
                angleOfInclinationCounter++;
            }
            if (bearing1 > bearing2){
                angleOfInclination = (bearing1 - bearing2); 
                angleOfInclinationCounter++;
            }
            if (bearing1 == bearing2){
                angleOfInclination = 0;
                angleOfInclinationCounter++;
            }
            sumOfAngles = angleOfInclination + sumOfAngles;
        }
        return sumOfAngles;
    }

    /** 
     * Percent Change In The Number Of Coordinates
     *
     * This is a linear attribute measure. It is a metric performed on a single 
     * line and measures point density by the percentage change in points between
     * the original line and simplified line (McMaster 1986). 
     * 
     * formula:  decrease = number of points in original line - number of points
     *           in simplified line
     *           percentage decrease = 
     *                      (decrease / number of points in original line) x 100
     * 
     * @param originalLine - Points representing original line
     * @param simplifiedLine - Points representing the simplified line
     * @return percentageChange - Value representing Percentage change (decrease)
     *                          in points between the original line and simplified
     *                          line
     */

    public double percentageChangeInNumberOfCoordinates(ArrayList<Point> 
            originalLine, ArrayList<Point> simplifiedLine){
        int totalNoOfOriginalLinePts = originalLine.size();
        int totalNoOfSimplifiedLinePts = simplifiedLine.size();
        double decreaseInPoints = (double) (totalNoOfOriginalLinePts -
                totalNoOfSimplifiedLinePts);
        double percentageDecrease = Math.round((((decreaseInPoints*100)/100) /
                totalNoOfOriginalLinePts) * 100); 
        System.out.println("Original line has : " + 
                totalNoOfOriginalLinePts + " points");
        System.out.println("Simplified line has : " + 
                totalNoOfSimplifiedLinePts + " points");
        System.out.println("Percentage Decrease In Number of Coordinates : " +
                percentageDecrease + "%"); 
        return percentageDecrease;
    }   
    
    /*
    * Percentage change in line lengths
    * 
    * This is a measure in the percentage decrease of the original line length
    * and the simplified line length
    *
    * Ref: http://www.skillsyouneed.com/num/percent-change.html
    *
    * @param originalLinePts - Points representing the original line
    * @param simplifiedLinePts - Points representing the simplified line
    */
    public double percentageChangeInLineLengths(ArrayList<Point> originalLinePts,
        ArrayList<Point> simplifiedLinePts){;
        double sumLine1Length = 0;
        double sumLine2Length = 0;
        
        for(int j = 0; j < originalLinePts.size()-1; j++){
            Point p1 = originalLinePts.get(j);
            Point p2 = originalLinePts.get(j + 1);
            Liner originalLine = new Liner(p1,p2);
            double line1Length = originalLine.getLength();
            sumLine1Length = sumLine1Length + line1Length;
        }
    
        for(int k = 0; k < simplifiedLinePts.size()-1; k++){
            Point p1 = simplifiedLinePts.get(k);
            Point p2 = simplifiedLinePts.get(k + 1);
            Liner simplifiedLine = new Liner(p1,p2);
            double line2Length = simplifiedLine.getLength();
            sumLine2Length = sumLine2Length + line2Length;
        }
        
        double decrease = sumLine1Length - sumLine2Length;
        double percentDecrease = (decrease / sumLine1Length) * 100; 
    
        System.out.println("Original line length : " + 
                sumLine1Length);
        System.out.println("Simplified line length : " + 
                sumLine2Length);
        System.out.println("Percentage Decrease In Line Length : " +
                percentDecrease + "%"); 
        this.percentageDecreaseInLineLengths = percentDecrease;
        return percentDecrease;
    }
    
   
    
     /** 
     * Sum Line Segment Lengths
     * @param pts - Points represent a line
     * @return sum of line segment lengths - Value representing the sum of
     *                                       line segment lengths for the given
     *                                       line points.
     */
    
    public double sumLineSegmentLengths(ArrayList<Point> pts){
        double sumLineSegmentLength = 0;
        for(int i = 0; i < pts.size()-1; i++){
            Point p1 = pts.get(i);
            Point p2 = pts.get(i+1);
            Liner line = new Liner(p1, p2);
            sumLineSegmentLength = sumLineSegmentLength + line.getLength();
        }
        return sumLineSegmentLength;
    }
    
//    /**
//     * IdentifyAllIntersectionPoints
//     * 
//     * Uses Bentley Ottmann formula to return intersection points
//     * Ref: Pseudo code - http://geomalgorithms.com/a09-_intersect-3.html
//     * @param sublists 
//     * @return points - Points representing the intersection points 
//     */
//    
//    public ArrayList<Point> IdentifyAllIntersectionPoints(ArrayList<Point> sublists){
//        Point p1 = new Point("p1,100,100");
//        Point p2 = new Point("p2,200,200");
//        ArrayList<Point> intersectionPoints = new ArrayList<>();
//        ArrayList<Point> eventQueue = new ArrayList<>();
//        
//        //1.Initialize event queue EQ = all segment endpoints;
//    
//        //2.Sort EQ by increasing x and y;
//        
//       
//        //3. Initialize sweep line SL to be empty;
//        ArrayList<Liner> sweepLine = new ArrayList<>();    
//        Liner segmentE = null;
//        segmentE = sweepLine;
//
//        //4.Initialize output intersection points list IL to be empty;
//        intersectionPoints = new ArrayList<>();
//        
//        //5.While (EQ is nonempty) {
//        for (int i = 0; i < eventQueue.size(); i++){
//        //6.Let E = the next event from EQ;
//            Point E = eventQueue.get(i);
//            If (E == left endpoint) {
//                //Let segE = E's segment;
//                //Add segE to SL;
//                //Let segA = the segment Above segE in SL;
//                //Let segB = the segment Below segE in SL;
//                //If (I = Intersect( segE with segA) exists) 
//                //    Insert I into EQ;
//                //If (I = Intersect( segE with segB) exists) 
//                //    Insert I into EQ;
//            }
//            else if (E == right endpoint) {
//            //    Let segE = E's segment;
//            //    Let segA = the segment Above segE in SL;
//            //    Let segB = the segment Below segE in SL;
//            //    Delete segE from SL;
//            //    If (I = Intersect( segA with segB) exists) 
//            //        If (I is not in EQ already) 
//            //            Insert I into EQ;
//            }
//            else {  // E is an intersection event
//            //    Add E’s intersect point to the output list IL;
//            //    Let segE1 above segE2 be E's intersecting segments in SL;
//            //    Swap their positions so that segE2 is now above segE1;
//            //    Let segA = the segment above segE2 in SL;
//            //    Let segB = the segment below segE1 in SL;
//            //    If (I = Intersect(segE2 with segA) exists)
//            //        If (I is not in EQ already) 
//            //            Insert I into EQ;
//            //    If (I = Intersect(segE1 with segB) exists)
//            //        If (I is not in EQ already) 
//            //           Insert I into EQ;
//            }
//            //remove E from EQ;
//            eventQueue.remove(E);
//        }
//        return intersectionPoints;
//    } 
}
