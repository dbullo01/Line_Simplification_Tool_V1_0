/*
 * To change this license header, choose License Headers in Project 
 * Properties. To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;

import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.io.FileNotFoundException;
import javax.swing.JFileChooser;
import java.util.Scanner;

/**
 * FileWrite
 * 
 * Allows data to be written to specified file
 * 
 * @author (Davison Bullock) 
 * @version (01/05/2016)
 */

public class FileWrite{
    private File file;

    /**
     * Constructor for objects of class FileWrite
     */
    public FileWrite(){
        this.file = null;
    } 
  
    /**
     * Append Write
     *
     * @param file - File to write line data to
     * @param text - Text (line data) to write to file
     */

    public void appendWrite(File file, String text){
        this.file = file;
        try{
            if (file.exists() | !file.exists()){
                file.createNewFile();
                FileOutputStream outputStream = 
                        new FileOutputStream(file,true);
                OutputStreamWriter outputStreamWriter = 
                        new OutputStreamWriter(outputStream, "UTF-8");    
                try (BufferedWriter w = 
                        new BufferedWriter(outputStreamWriter)) {
                    w.write(text);
                    w.newLine();
                }
            }
        }catch(IOException e){
            System.err.println("Cannot write to file");
        }
    }

    /**
     * Load a CSV File
     *
     * @return File - File that has been chosen/created by user to be written to
     */    
    public File loadCSVFile(){
       
        JFileChooser selectedCSVFile = new JFileChooser("C:\\ACTESTDATA\\");
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        int selected = selectedCSVFile.showDialog(lsf, "Load CSV File");
        if(selected == JFileChooser.APPROVE_OPTION){
            file = selectedCSVFile.getSelectedFile();        
        }
        return file;
    }

    /**
     * Save a CSV File
     * 
     * @return File - File that has been chosen/created by user have original 
     *                line data to be saved to
     */    
    public File saveCSVFile(){
 
        JFileChooser selectedCSVFile = new JFileChooser("C:\\ACTESTDATA\\");
        selectedCSVFile.setDialogTitle("Save CSV File");
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        int selected = selectedCSVFile.showDialog(lsf, "Save CSV File");
        
        if(selected == JFileChooser.APPROVE_OPTION){
            file = selectedCSVFile.getSelectedFile();
            
        }
        return file;
    }
    
    /**
     * Save a CSV File
     * 
     * @return File - File that has been chosen/created by user have simplified 
     *                line data to be saved to.
     */    
    public File saveSimplifiedLineToCSVFile(){
 
        JFileChooser selectedCSVFile = 
                new JFileChooser("C:\\ACTESTDATA\\");
        selectedCSVFile.setDialogTitle("Save Simplified Line To CSV File");
        LineSimplificationFrame lsf = new LineSimplificationFrame();
        int selected = selectedCSVFile.showDialog(lsf, "Save CSV File");
        
        if(selected == JFileChooser.APPROVE_OPTION){
            file = selectedCSVFile.getSelectedFile();
            
        }
        return file;
    }

    /**
     * Get file extension
     * 
     * Get a file extension from a file
     * 
     * @param file - File to get file extension from
     * @return String representing the file extension
     */

    public String getFileExtension(File file) {
        String fileName = file.getName();
        String fileExtension = "";

        try {
            int pos = fileName.indexOf(".");
            fileExtension = fileName.substring(pos);
        } catch (Exception e) {
            fileExtension = "";
        }
        return fileExtension;
    }

    /**
     * Returns the First Line of a File
     * 
     * @param file - File to get first line from
     * @return firstLineOfFile - String representing the first line of the file
     * @throws java.io.FileNotFoundException
     */
    public String ReturnFirstLineOfFile(File file)
            throws FileNotFoundException{
        String firstLineOfFile;
        try (Scanner in = new Scanner(file)) {
            firstLineOfFile = in.nextLine();
        }
        return firstLineOfFile;
    }
}

