/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;


/**
 * Liner
 * 
 * Creates a line that takes two points
 * representing start and end points for line
 * 
 * @author (Davison Bullock) 
 * @version (24/03/2016)
 */
public class Liner{
    // instance variables 
    Point point1;
    Point point2;

    /***
     * Constructor for objects of class Liner
     * 
     * @param point1 - Point representing start point of line
     * @param point2 - Point representing end point of line
     * 
     */
    public Liner(Point point1, Point point2)
    {
        // initialise instance variables
        this.point1 = point1;
        this.point2 = point2;
    }

    /**
     * getLinerPoint1
     * 
     * @return point1 - Point representing start point of line 
     */
    public Point getLinerPoint1(){
        return this.point1;
    }
    
    
    /**
     * getLinerPoint2
     *
     * @return point2 - Point representing end point of line 
     */
    public Point getLinerPoint2(){
        return this.point2;
    }
    
    
    /**
     * get length
     * 
     * Calculates and returns the line's length
     *
     * @return length of liner
     */
    public double getLength(){
        double x1 = (double) this.getLinerPoint1().getX();
        double y1 = (double) this.getLinerPoint1().getY();
        double x2 = (double) this.getLinerPoint2().getX();
        double y2 = (double) this.getLinerPoint2().getY();        
        double lineLength = Math.sqrt(Math.pow(x2-x1,2)+ Math.pow(y2-y1,2));
        
        return lineLength;
    }
    
    
    /**
     * Calculate Bearing of Line
     * 
     * Called my method sumAnglesOfChange
     * 
     * Using surveying formula
     * REF: Slide 9 www.tcd.ie/civileng/Staff/Brian.Caulfield/.../
     * 3A1%20Lecture%207.pdf
     * REF: http://stackoverflow.com/questions/3449826/
     * how-do-i-find-the-inverse-tangent-of-a-line
     * REF: http://mathforum.org/library/drmath/view/62034.html
     * @param point1 - Point representing start point of line
     * @param point2 - Point representing end point of line
     * @return bearing - Value representing the bearing of the line
     */
    public double calculateBearingofLine(Point point1, Point point2){
        double diffx = (point2.getX() - point1.getX());
        double diffy = (point2.getY() - point1.getY());
        //Atan2 Handles line orientation and where they are in Whole Circle 
        //quadrants so no need to handle this  
        double bearing = 90 - (180/Math.PI)* Math.atan2(diffy, diffx);
        //Round bearing to 2 dp (Using 100) and round function 
        bearing = bearing*100;
        bearing = Math.round(bearing);
        bearing = bearing /100;
        if (bearing < 0){
            bearing = bearing + 360;
        }
        return bearing;
    }
}
