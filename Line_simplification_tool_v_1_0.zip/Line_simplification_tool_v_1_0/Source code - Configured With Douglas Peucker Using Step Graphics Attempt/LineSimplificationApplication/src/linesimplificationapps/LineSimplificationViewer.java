/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linesimplificationapps;


import javax.swing.JFrame;

/**
 * Line Simplification GUI program. 
 * 
 * Allows users to learn about common point simplification algorithms
 * and how they work. Users can assess an algorithms strengths and 
 * weaknesses using implemented line metrics and performance measures 
 * functionality
 * 
 * @author Davison Bullock
 * @version (24/07/2016)
 */
public class LineSimplificationViewer
{  
   public static void main(String[] args)
   {  
      JFrame lsframe = new LineSimplificationFrame();
      lsframe.setTitle("Line Simplification Algorithms - Learning Tool"); 
      lsframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      lsframe.setVisible(true);
   }

}

