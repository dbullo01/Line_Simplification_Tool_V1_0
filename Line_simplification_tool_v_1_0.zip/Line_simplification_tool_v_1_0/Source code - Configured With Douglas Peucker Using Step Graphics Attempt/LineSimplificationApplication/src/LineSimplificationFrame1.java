

package linesimplificationapp;

import java.awt.event.*;
import java.awt.event.MouseAdapter;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.File;
import java.util.ArrayList;
import java.awt.*;
import java.awt.geom.Line2D;


public class LineSimplificationFrame1 extends javax.swing.JFrame implements ItemListener {
    private ArrayList<Point> points;     // Original line
    private ArrayList<Point> points2;    // Simplified Line
    private ArrayList<Point> points3;
    private ArrayList<Liner> lines;
    private MouseListener mouseListener;
    
    private DisplayPanel panel2;
    
    public class DisplayPanel extends JPanel 
    {  

        ///** The Constant FRAME_WIDTH & HEIGHT. */        //ADDED DBULLOCK 7/5/2016
        private static final int FRAME_WIDTH =  600;
        private static final int FRAME_HEIGHT = 600;

        public DisplayPanel(){       
            //setSize(FRAME_WIDTH, FRAME_HEIGHT);           //ADDED DBULLOCK 7/5/2016
        }

        /* 
         * Display loaded data on repaint event.
         */
        @Override
        public void paintComponent(Graphics g)
        {  

            Point midpoint = null;
            //display all lines first (so that junctions are placed on top)

            if (getLines() != null){
                //g.setColor(Color.GREEN);
                displayLines2(g, getLines()); //Display input lines
                //DisplayPanel dp = new DisplayPanel();
                revalidate();
                repaint();
            }

            //display original line
            if (getPoints() != null){
                // midpoint = null;
                for(int ct1=0; ct1< getPoints().size(); ct1++){
                    int noOfPoints = getPoints().size();
                    int midPointIndex = noOfPoints / 2;
                    midpoint = getPoints().get(midPointIndex);
                    getPoints().get(ct1).DisplayPoint(g);
                }

                displayLines(getPoints(), g);  //Display original line (RED)
                //midpoint.setY(100);
                Point labelPt = new Point("p100" + "," + 150 + "," + 600); 
                createText(g, labelPt, "Original Line");
                
                //DisplayPanel dp = new DisplayPanel();
                revalidate();
                repaint();
                //repaint();
            }

            //display simplified line 
            if (getPoints2() != null){
                for(int ct=0; ct< getPoints2().size(); ct++){
                    int noOfPoints = getPoints().size();
                    int midPointIndex = noOfPoints / 2;
                    midpoint = getPoints().get(midPointIndex);
                    getPoints2().get(ct).DisplayPoint(g);
                    /////////////////////////////////////drawCircle(g, points2.get(ct), 100);   //Used of other simplifcation algorithms
                    revalidate();
                    repaint();
                }
                g.setColor(Color.BLUE);
                displayLines3(getPoints2(), g); //Display simplified line (BLUE)
                // midpoint.setY(50);
                //////////////////////////////////////////createText(g, midpoint, "Simplified Line");  //COMMENTED OUT DBULLOCK 08/04/2016

                //Display all lines  //Added D Bullock
                // int j = 0;
                // for(int i = 0; i < points.size() - 1; i++){
                //     j = i + 1;
                //     Point p1 = points.get(i);
                //     Point p2 = points.get(j);               
                //     Graphics2D g2 = (Graphics2D) g; 

                //g2.drawLine(p1.getX()+20,p1.getY()+10,p2.getX()+20,p2.getY()+10) ;
                //    g2.drawLine(p1.getX(),500 - p1.getY(),p2.getX(),500 - p2.getY()) ;

            }
        }

    }
   
    
    /** Creates new form LineSimplificationFrame*/
    public LineSimplificationFrame1() {
        initComponents();  
    }
    
    @Override
    public void itemStateChanged(ItemEvent e) {
        if (chkOriginalLineButton.isSelected()){
            setPoints2(getPoints2());
            repaint();
        }
        else{
            setPoints3(getPoints3());
            repaint();
        }
    }
   
    
    /**
     *  Get Points
     *  @return points
     */
    public ArrayList<Point> getPoints(){
        return this.points;
    }

    /**
     * Get Points 2
     * @return points2
     */
    public ArrayList<Point> getPoints2(){
        return this.points2;
    }

    /**
     * Get Points 3
     * @return points3
     */

    public ArrayList<Point> getPoints3(){
        return this.points3;
    }

    /**
     * Get Lines
     * @return lines
     */
    public ArrayList<Liner> getLines(){
        return this.lines;
    }

    /**
     * Set points 1
     * @param points
     */
    public void setPoints (ArrayList<Point> points){
        this.points = points;    
    }

    /**
     * Set points 2
     * @param points
     */
    public void setPoints2 (ArrayList<Point> points){
        this.points2 = points;    
    }

    /**
     * Set points 3
     * @param points
     */
    public void setPoints3 (ArrayList<Point> points){
        this.points3 = points;    
    }

    /**
     * Set liner
     * @param lines
     */
    public void setLiners (ArrayList<Liner> lines){
        this.lines = lines;    
    }

     /**
     * Capture Points
     * Allows capturedPoints to be captured as pointID, X, Y coords and stored
     * in original line points array list
     * 
     * @param e
     * @param count
     * @return
     */

    public Point capturePointClicked(MouseEvent e, int count){
        int x = e.getX();
        int y = 600 - e.getY();

        String strCoord = "p" + count + "," + x + "," +  y;
        System.out.println(strCoord);
        Point p = new Point(strCoord);
        
        //originalLinePts.add(p); 
        //setPoints(originalLinePts);
        //repaint();
        return p;
    } 
    
    
    
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel()

        {

            @Override
            public void paintComponent(Graphics g)
            {

                Point midpoint = null;
                //display all lines first (so that junctions are placed on top)

                if (lines != null){
                    //g.setColor(Color.GREEN);
                    displayLines2(g, lines); //Display input lines
                    repaint();
                }

                //display original line
                if (points != null){
                    // midpoint = null;
                    for(int ct1=0; ct1< points.size(); ct1++){
                        int noOfPoints = points.size();
                        int midPointIndex = noOfPoints / 2;
                        midpoint = points.get(midPointIndex);
                        points.get(ct1).DisplayPoint(g);
                    }

                    displayLines(points, g);  //Display original line (RED)
                    //midpoint.setY(100);
                    Point labelPt = new Point("p100" + "," + 150 + "," + 600);
                    createText(g, labelPt, "Original Line");
                    repaint();
                }

                //display simplified line
                if (points2 != null){
                    for(int ct=0; ct< points2.size(); ct++){
                        int noOfPoints = points.size();
                        int midPointIndex = noOfPoints / 2;
                        midpoint = points.get(midPointIndex);
                        points2.get(ct).DisplayPoint(g);
                        /////////////////////////////////////drawCircle(g, points2.get(ct), 100);   //Used of other simplifcation algorithms
                        repaint();
                    }
                    g.setColor(Color.BLUE);
                    displayLines3(points2, g); //Display simplified line (BLUE)
                    // midpoint.setY(50);
                    //////////////////////////////////////////createText(g, midpoint, "Simplified Line");  //COMMENTED OUT DBULLOCK 08/04/2016

                    //Display all lines  //Added D Bullock
                    // int j = 0;
                    // for(int i = 0; i < points.size() - 1; i++){
                        //     j = i + 1;
                        //     Point p1 = points.get(i);
                        //     Point p2 = points.get(j);
                        //     Graphics2D g2 = (Graphics2D) g;

                        //g2.drawLine(p1.getX()+20,p1.getY()+10,p2.getX()+20,p2.getY()+10) ;
                        //    g2.drawLine(p1.getX(),500 - p1.getY(),p2.getX(),500 - p2.getY()) ;

                    }
                }

            };
            jPanel2 = new javax.swing.JPanel();
            lblPerpendicularDistance = new javax.swing.JLabel();
            lblSimplificationAlgorithm = new javax.swing.JLabel();
            lblNthPoint = new javax.swing.JLabel();
            lblRadialDistance = new javax.swing.JLabel();
            txtPerpendicularDistance = new javax.swing.JTextField();
            CboSimplificationAlgorithm = new javax.swing.JComboBox();
            txtNthPoint = new javax.swing.JTextField();
            txtRadialDistance = new javax.swing.JTextField();
            lblWidth = new javax.swing.JLabel();
            lblHeight = new javax.swing.JLabel();
            loadCSVFileButton = new javax.swing.JButton();
            loadSaveCSVFileButton = new javax.swing.JButton();
            loadSimplifyButton = new javax.swing.JButton();
            txtWidth = new javax.swing.JTextField();
            txtHeight = new javax.swing.JTextField();
            lblPercentageDecrease = new javax.swing.JLabel();
            lblPositionalError = new javax.swing.JLabel();
            lblNoOfOriginalLinePts = new javax.swing.JLabel();
            lblNoOfSimplifiedLinePts = new javax.swing.JLabel();
            loadStepButton = new javax.swing.JButton();
            loadResetButton = new javax.swing.JButton();
            loadExitButton = new javax.swing.JButton();
            lblNoOfPoints = new javax.swing.JLabel();
            txtNoOfPoints = new javax.swing.JTextField();
            lblPositionalErrorValue = new javax.swing.JLabel();
            lblNoOfOriginalLinePtsValue = new javax.swing.JLabel();
            lblNoOfSimplifiedLinePoints = new javax.swing.JLabel();
            lblPercentageDecreaseValue = new javax.swing.JLabel();
            loadAreaDisplacementErrorButton = new javax.swing.JButton();
            loadVectorDisplacementErrorButton = new javax.swing.JButton();
            lblVectorDisplacement = new javax.swing.JLabel();
            lblVectorDisplacementValue = new javax.swing.JLabel();
            jLabel18 = new javax.swing.JLabel();
            lblAreaDisplacementValue = new javax.swing.JLabel();
            jScrollPane1 = new javax.swing.JScrollPane();
            jTextArea1 = new javax.swing.JTextArea();
            chkOriginalLineButton = new javax.swing.JCheckBox();
            chkSimplifiedLineButton = new javax.swing.JCheckBox();
            loadRatioInChangeOfAngularityButton = new javax.swing.JButton();
            loadSaveADrawnLineToCSVFileButton = new javax.swing.JButton();
            loadDrawALineButton = new javax.swing.JButton();
            lblRatioAngularityChange = new javax.swing.JLabel();
            lblRatioAngularityChangeValue = new javax.swing.JLabel();

            org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
            jPanel3.setLayout(jPanel3Layout);
            jPanel3Layout.setHorizontalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 100, Short.MAX_VALUE)
            );
            jPanel3Layout.setVerticalGroup(
                jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 100, Short.MAX_VALUE)
            );

            setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
            setTitle("Line Simplification Learning Tool");
            setUndecorated(true);

            jPanel1.setBackground(new java.awt.Color(255, 255, 255));
            jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
            jPanel1.setDoubleBuffered(false);

            org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
            jPanel1.setLayout(jPanel1Layout);
            jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 805, Short.MAX_VALUE)
            );
            jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(0, 579, Short.MAX_VALUE)
            );

            jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
            jPanel2.setDoubleBuffered(false);
            jPanel2.setEnabled(false);

            lblPerpendicularDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPerpendicularDistance.setText("       Perpendicular distance:");
            lblPerpendicularDistance.setEnabled(false);

            lblSimplificationAlgorithm.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblSimplificationAlgorithm.setText("       Simplification algorithm:");
            lblSimplificationAlgorithm.setEnabled(false);

            lblNthPoint.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNthPoint.setText("Nth point:");
            lblNthPoint.setEnabled(false);

            lblRadialDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRadialDistance.setText("       Radial distance:");
            lblRadialDistance.setToolTipText("");
            lblRadialDistance.setEnabled(false);

            txtPerpendicularDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtPerpendicularDistance.setText("0.00");
            txtPerpendicularDistance.setToolTipText("");
            txtPerpendicularDistance.setEnabled(false);

            CboSimplificationAlgorithm.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            CboSimplificationAlgorithm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Nth point", "Routine of radial distance", "Routine of perpendicular distance", "Reumann-Witkam", "Lang", "Douglas Peucker", "Visvalingam Whyatt", " " }));
            CboSimplificationAlgorithm.setEnabled(false);
            CboSimplificationAlgorithm.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    CboSimplificationAlgorithmActionPerformed(evt);
                }
            });

            txtNthPoint.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtNthPoint.setText("0");
            txtNthPoint.setAutoscrolls(false);
            txtNthPoint.setEnabled(false);

            txtRadialDistance.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtRadialDistance.setText("0.00");
            txtRadialDistance.setEnabled(false);

            lblWidth.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblWidth.setText("       Width:");
            lblWidth.setEnabled(false);

            lblHeight.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblHeight.setText("       Height:");
            lblHeight.setEnabled(false);

            loadCSVFileButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadCSVFileButton.setText("Load Line from CSV");
            loadCSVFileButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadCSVFileButtonActionPerformed(evt);
                }
            });

            loadSaveCSVFileButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSaveCSVFileButton.setText("Save Line to CSV");
            loadSaveCSVFileButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSaveCSVFileButtonActionPerformed(evt);
                }
            });

            loadSimplifyButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSimplifyButton.setText("Simplify");
            loadSimplifyButton.setEnabled(false);
            loadSimplifyButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSimplifyButtonActionPerformed(evt);
                }
            });

            txtWidth.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtWidth.setText("0.00");
            txtWidth.setEnabled(false);

            txtHeight.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtHeight.setText("0.00");
            txtHeight.setEnabled(false);

            lblPercentageDecrease.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPercentageDecrease.setText("% decrease:");

            lblPositionalError.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPositionalError.setText("Positional error:");

            lblNoOfOriginalLinePts.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfOriginalLinePts.setText("Original line points:");

            lblNoOfSimplifiedLinePts.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfSimplifiedLinePts.setText("Simplified line points:");

            loadStepButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadStepButton.setText("Step");
            loadStepButton.setEnabled(false);
            loadStepButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadStepButtonActionPerformed(evt);
                }
            });

            loadResetButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadResetButton.setText("Reset");
            loadResetButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadResetButtonActionPerformed(evt);
                }
            });

            loadExitButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadExitButton.setText("Exit");
            loadExitButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadExitButtonActionPerformed(evt);
                }
            });

            lblNoOfPoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfPoints.setText("No of points:");
            lblNoOfPoints.setEnabled(false);

            txtNoOfPoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            txtNoOfPoints.setText("0");
            txtNoOfPoints.setEnabled(false);

            lblPositionalErrorValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPositionalErrorValue.setText("0.00");

            lblNoOfOriginalLinePtsValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfOriginalLinePtsValue.setText("0");

            lblNoOfSimplifiedLinePoints.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblNoOfSimplifiedLinePoints.setText("0");
            lblNoOfSimplifiedLinePoints.setToolTipText("");

            lblPercentageDecreaseValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblPercentageDecreaseValue.setText("0.00");

            loadAreaDisplacementErrorButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadAreaDisplacementErrorButton.setText("Area Error");
            loadAreaDisplacementErrorButton.setEnabled(false);
            loadAreaDisplacementErrorButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadAreaDisplacementErrorButtonActionPerformed(evt);
                }
            });

            loadVectorDisplacementErrorButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadVectorDisplacementErrorButton.setText("Vector Error");
            loadVectorDisplacementErrorButton.setToolTipText("");
            loadVectorDisplacementErrorButton.setEnabled(false);
            loadVectorDisplacementErrorButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadVectorDisplacementErrorButtonActionPerformed(evt);
                }
            });

            lblVectorDisplacement.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblVectorDisplacement.setText("Vector displacement:");
            lblVectorDisplacement.setToolTipText("");

            lblVectorDisplacementValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblVectorDisplacementValue.setText("0.00");
            lblVectorDisplacementValue.setToolTipText("");

            jLabel18.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            jLabel18.setText("Area displacement: ");

            lblAreaDisplacementValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblAreaDisplacementValue.setText("0.00");
            lblAreaDisplacementValue.setToolTipText("");

            jTextArea1.setBackground(new java.awt.Color(204, 204, 204));
            jTextArea1.setColumns(20);
            jTextArea1.setLineWrap(true);
            jTextArea1.setRows(5);
            jTextArea1.setText("Information about selected algorithm to\ngo here....\nProcessing steps to go here....");
            jScrollPane1.setViewportView(jTextArea1);

            chkOriginalLineButton.setText("Original line");
            chkOriginalLineButton.setToolTipText("");
            chkOriginalLineButton.setEnabled(false);
            chkOriginalLineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    chkOriginalLineButtonActionPerformed(evt);
                }
            });

            chkSimplifiedLineButton.setText("Simplified line");
            chkSimplifiedLineButton.setToolTipText("");
            chkSimplifiedLineButton.setEnabled(false);
            chkSimplifiedLineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    chkSimplifiedLineButtonActionPerformed(evt);
                }
            });

            loadRatioInChangeOfAngularityButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadRatioInChangeOfAngularityButton.setText("Change Of Angularity ");
            loadRatioInChangeOfAngularityButton.setEnabled(false);
            loadRatioInChangeOfAngularityButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadRatioInChangeOfAngularityButtonActionPerformed(evt);
                }
            });

            loadSaveADrawnLineToCSVFileButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadSaveADrawnLineToCSVFileButton.setText("Save Line");
            loadSaveADrawnLineToCSVFileButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadSaveADrawnLineToCSVFileButtonActionPerformed(evt);
                }
            });

            loadDrawALineButton.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            loadDrawALineButton.setText("Draw Line");
            loadDrawALineButton.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    loadDrawALineButtonActionPerformed(evt);
                }
            });

            lblRatioAngularityChange.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRatioAngularityChange.setText("Ratio Angularity Change");

            lblRatioAngularityChangeValue.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
            lblRatioAngularityChangeValue.setText("0.00");
            lblRatioAngularityChangeValue.setToolTipText("");

            org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
            jPanel2.setLayout(jPanel2Layout);
            jPanel2Layout.setHorizontalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel2Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(5, 5, 5)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(lblNthPoint)
                                        .add(lblPerpendicularDistance)
                                        .add(lblRadialDistance)
                                        .add(lblWidth)
                                        .add(lblHeight))
                                    .add(18, 18, 18)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtHeight, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtPerpendicularDistance)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtRadialDistance)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtWidth)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, txtNthPoint)))
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(lblNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 73, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(18, 18, 18)
                                    .add(txtNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(loadSimplifyButton)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2Layout.createSequentialGroup()
                                    .add(43, 43, 43)
                                    .add(chkOriginalLineButton)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(chkSimplifiedLineButton)))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadCSVFileButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadSaveADrawnLineToCSVFileButton, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, loadDrawALineButton, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                                .add(loadSaveCSVFileButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                            .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(lblSimplificationAlgorithm)
                            .add(18, 18, 18)
                            .add(CboSimplificationAlgorithm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 188, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(0, 4, Short.MAX_VALUE))))
                .add(jPanel2Layout.createSequentialGroup()
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(20, 20, 20)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(loadExitButton)
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(loadStepButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(loadResetButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .add(loadVectorDisplacementErrorButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 159, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(org.jdesktop.layout.GroupLayout.TRAILING, loadAreaDisplacementErrorButton, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 159, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(org.jdesktop.layout.GroupLayout.TRAILING, loadRatioInChangeOfAngularityButton))))
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel2Layout.createSequentialGroup()
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(14, 14, 14)
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                                .add(lblNoOfOriginalLinePts)
                                                .add(lblPositionalError)))
                                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(org.jdesktop.layout.GroupLayout.TRAILING, lblNoOfSimplifiedLinePts)
                                            .add(org.jdesktop.layout.GroupLayout.TRAILING, lblPercentageDecrease)))
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(lblPositionalErrorValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(lblNoOfOriginalLinePtsValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(lblNoOfSimplifiedLinePoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(lblPercentageDecreaseValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(jPanel2Layout.createSequentialGroup()
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(lblVectorDisplacement)
                                        .add(jPanel2Layout.createSequentialGroup()
                                            .add(10, 10, 10)
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                                .add(jLabel18)
                                                .add(lblRatioAngularityChange, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                                .add(lblAreaDisplacementValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .add(lblVectorDisplacementValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .add(lblRatioAngularityChangeValue, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 349, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(1, 1, 1)))
                    .add(0, 0, Short.MAX_VALUE))
            );
            jPanel2Layout.setVerticalGroup(
                jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel2Layout.createSequentialGroup()
                    .add(15, 15, 15)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lblSimplificationAlgorithm)
                        .add(CboSimplificationAlgorithm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(txtNoOfPoints, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lblNoOfPoints))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(txtNthPoint, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lblNthPoint))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(txtPerpendicularDistance, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(lblPerpendicularDistance))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblRadialDistance)
                                .add(txtRadialDistance, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(loadDrawALineButton)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(loadSaveADrawnLineToCSVFileButton)))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(txtWidth, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(loadCSVFileButton))
                        .add(lblWidth))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lblHeight)
                        .add(txtHeight, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(loadSaveCSVFileButton))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(loadSimplifyButton)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(chkOriginalLineButton)
                        .add(chkSimplifiedLineButton))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 181, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(8, 8, 8)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(loadStepButton)
                                .add(loadResetButton))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(loadVectorDisplacementErrorButton)
                            .add(3, 3, 3)
                            .add(loadAreaDisplacementErrorButton)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(loadRatioInChangeOfAngularityButton)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(loadExitButton))
                        .add(jPanel2Layout.createSequentialGroup()
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblPositionalError)
                                .add(lblPositionalErrorValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblNoOfOriginalLinePts)
                                .add(lblNoOfOriginalLinePtsValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblNoOfSimplifiedLinePts)
                                .add(lblNoOfSimplifiedLinePoints))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblPercentageDecrease)
                                .add(lblPercentageDecreaseValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblVectorDisplacement)
                                .add(lblVectorDisplacementValue))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(jLabel18, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(lblAreaDisplacementValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lblRatioAngularityChange, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(lblRatioAngularityChangeValue, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .add(10, 10, 10))))
            );

            loadStepButton.getAccessibleContext().setAccessibleName("loadStepButton");

            org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(layout.createSequentialGroup()
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap())
                .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                    .add(0, 0, Short.MAX_VALUE)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(23, 23, 23))
            );

            jPanel1.getAccessibleContext().setAccessibleName("");
            jPanel1.getAccessibleContext().setAccessibleDescription("");
            jPanel2.getAccessibleContext().setAccessibleName("Line Simplication");

            pack();
        }// </editor-fold>//GEN-END:initComponents

    private void loadSimplifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSimplifyButtonActionPerformed
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        LinePerformance lp = new LinePerformance();
        
        switch (selectedText) {
            case "Routine of radial distance":
                txtRadialDistance.setVisible(true);
                 try{
                    //points = Point.LoadPoints();                                          //Original line
                    removeMouseListener(mouseListener);
                    int n = Integer.parseInt(txtRadialDistance.getText());  
                    LineSimplification ls = new LineSimplification();
                    setPoints2(ls.routineOfDistanceBetweenPoints(getPoints(),n));           //Simplified line
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());                    
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    //setPerformanceButtonsOn();
                    
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    chkOriginalLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setEnabled(true);
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    
                   }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Nth point":
                txtNthPoint.setVisible(true);
                try{
                    removeMouseListener(mouseListener);
                    int n = Integer.parseInt(txtNthPoint.getText());  
                    LineSimplification ls = new LineSimplification();
                    setPoints2(ls.nthPoint(getPoints(),n));                                  //Simplified line
                    for (int i = 0; i < getPoints2().size(); i++){
                      //  resultArea.insert("" + getPoints2().get(i).getID() + "," + 
                      //      Integer.toString(getPoints2().get(i).getX()) + "," + 
                      //      Integer.toString(getPoints2().get(i).getY()), i);  //DEBUG
                    }
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                    //resultArea.setEditable(false);
                    //scrollPane = new JScrollPane(resultArea);
                    //panel.add(scrollPane);
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Routine of perpendicular distance":
                txtPerpendicularDistance.setVisible(true);
                try{
                    removeMouseListener(mouseListener);
                    int n = Integer.parseInt(txtPerpendicularDistance.getText());  
                    LineSimplification ls = new LineSimplification();
                    //points = Point.LoadPoints();
                    setPoints2(ls.perpendicularDistanceRoutine(points,n));
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                    //setPoints2(ls.test(points));
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Reumann-Witkam":
                txtHeight.setVisible(true);
                txtWidth.setVisible(true);
                 try{
                    removeMouseListener(mouseListener);
                    int height = Integer.parseInt(txtHeight.getText());
                    int width = Integer.parseInt(txtWidth.getText());
                    LineSimplification ls = new LineSimplification();
                    //setPoints2(ls.reumannWitkam(g, points, height, width));
                    //points = Point.LoadPoints();
                    setLiners(ls.reumannWitkam(points, height, width));
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
               break;
            case "Lang":
                txtPerpendicularDistance.setVisible(true);
                try{
                    removeMouseListener(mouseListener);
                    int n = Integer.parseInt(txtPerpendicularDistance.getText());  
                    double perpendicularDistanceTolerance = 100.00;// Double.parseDouble(langPerpendicularDistanceToleranceTxtField.getText());  
                    LineSimplification ls = new LineSimplification();
                    //points = Point.LoadPoints();
                    //setPoints2(ls.Lang(points, n, perpendicularDistanceTolerance));
                    /////////////////////////////////// setPoints2(ls.davisonLang(points, n, perpendicularDistanceTolerance));
                    //setLiners(ls.davisonLang(points, n, perpendicularDistanceTolerance));
                    setPoints2(ls.lang(points,n));  //COMMENTED OUT DBULLOCK 10/04/2015
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                    //setPoints2(ls.test(points));
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Douglas Peucker":
                txtPerpendicularDistance.setVisible(true);
                try{ 
                    removeMouseListener(mouseListener);
                    int rdpInt = Integer.parseInt(txtPerpendicularDistance.getText());
                    LineSimplification ls = new LineSimplification();
                    setPoints2(ls.ramerDouglasPeucker(points, rdpInt));             //Simplified line
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lblRatioAngularityChangeValue.setText("" + lp.ratioInChangeOfAngularity(getPoints(), getPoints2()));
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            case "Visvalingam Whyatt":
                txtNoOfPoints.setVisible(true);
                try{
                    removeMouseListener(mouseListener);
                    int vwInt = Integer.parseInt(txtNoOfPoints.getText());
                    LineSimplification ls = new LineSimplification();
                    setPoints2(ls.visvalingamWhyattSimplified(points,vwInt));  
                    //displayLines(getPoints2(),g);                                   //Simplified line
                    chkSimplifiedLineButton.setEnabled(true);
                    chkSimplifiedLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblNoOfSimplifiedLinePoints.setText("" + getPoints2().size());
                    lblPercentageDecreaseValue.setText("" + lp.percentageChangeInNumberOfCoordinates(getPoints(),getPoints2()));
                    lp.ratioInChangeOfAngularity(getPoints(), getPoints2());
                    loadStepButton.setEnabled(true);
                    loadVectorDisplacementErrorButton.setEnabled(true);
                    loadAreaDisplacementErrorButton.setEnabled(true);
                    loadRatioInChangeOfAngularityButton.setEnabled(true);
                    //setPerformanceButtonsOn();
                }
                catch (Exception e){
                    System.out.println("File not found"); 
                }
                break;
            default:
                break;
        }
        System.out.println(selectedText);
    }//GEN-LAST:event_loadSimplifyButtonActionPerformed

    private void loadExitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadExitButtonActionPerformed
         try{ 
                removeMouseListener(mouseListener);
                System.exit(0);
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadExitButtonActionPerformed

    private void loadSaveCSVFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSaveCSVFileButtonActionPerformed
         try{
                //Return file object of selected file from fileChooser dialog 
                removeMouseListener(mouseListener);
                FileWrite fw = new FileWrite();
                File file = fw.loadCSVFile();  
                String fileExtension = fw.getFileExtension(file);

                //DEBUG - Checking file extension is .csv or .CSV 
                System.out.println("File extension of selected file is: " + fileExtension);

                if (fileExtension.equals(".csv") || fileExtension.equals(".CSV")){
                    //TO DO = STILL NEED TO Validate the first line of the file to make sure it contains valid content   [TO DO!]
                    String firstLineInCSVFile = fw.ReturnFirstLineOfFile(file); 
                    points = Point.LoadPoints(file);                                   
                    repaint();
                    chkOriginalLineButton.setEnabled(true);
                    chkOriginalLineButton.setSelected(true);
                }
                else{
                    System.out.println("File is not a csv file with file extension .csv or .CSV. Please try loading a CSV again!");
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadSaveCSVFileButtonActionPerformed

    private void loadCSVFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadCSVFileButtonActionPerformed

         try{
                //Return file object of selected file from fileChooser dialog 
                removeMouseListener(mouseListener);
                FileWrite fw = new FileWrite();
                File file = fw.loadCSVFile();  
                String fileExtension = fw.getFileExtension(file);

                //DEBUG - Checking file extension is .csv or .CSV 
                System.out.println("File extension of selected file is: " + fileExtension);

                if (fileExtension.equals(".csv") || fileExtension.equals(".CSV")){
                    //TO DO = STILL NEED TO Validate the first line of the file to make sure it contains valid content   [TO DO!]
                    String firstLineInCSVFile = fw.ReturnFirstLineOfFile(file); 
                    //points = Point.LoadPoints(file);                                   
                    setPoints(Point.LoadPoints(file)); 
                    repaint();
                    chkOriginalLineButton.setEnabled(true);
                    chkOriginalLineButton.setSelected(true);
                    lblNoOfOriginalLinePtsValue.setText("" + getPoints().size());
                    lblPercentageDecreaseValue.setText("0");
                    lblRatioAngularityChangeValue.setText("0");
                    lblSimplificationAlgorithm.setEnabled(true);
                    CboSimplificationAlgorithm.setEnabled(true);
                    loadSimplifyButton.setEnabled(true);
                }
                else{
                    System.out.println("File is not a csv file with file extension .csv or .CSV. Please try loading a CSV again!");
                }
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }        
    }//GEN-LAST:event_loadCSVFileButtonActionPerformed

    private void loadStepButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadStepButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_loadStepButtonActionPerformed

    private void CboSimplificationAlgorithmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CboSimplificationAlgorithmActionPerformed
        String selectedText = (String)CboSimplificationAlgorithm.getSelectedItem();
        
        switch (selectedText) {
            case "Routine of radial distance":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(true);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(true);
                lblWidth.setEnabled(false);
                break;
            case "Nth point":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(true);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(true);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                break;
            case "Routine of perpendicular distance":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                break;
            case "Reumann-Witkam":
                txtHeight.setEnabled(true);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(true);
                lblHeight.setEnabled(true);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(true);
                break;
            case "Lang":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                break;
            case "Douglas Peucker":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(true);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(true);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                break;
            case "Visvalingam Whyatt":
                txtHeight.setEnabled(false);
                txtNoOfPoints.setEnabled(true);
                txtNthPoint.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                lblNoOfPoints.setEnabled(true);
                lblNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                break;
            default:
                break;
        }
        System.out.println(selectedText);
    }//GEN-LAST:event_CboSimplificationAlgorithmActionPerformed

    private void loadAreaDisplacementErrorButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadAreaDisplacementErrorButtonActionPerformed
         try{
                removeMouseListener(mouseListener);
                LinePerformance lp = new LinePerformance();
                lp.areaDisplacementError(getPoints(), getPoints2());
                ////////////////////////////////////////////////setLiners(lp.areaDisplacementError(points));
                //displayLines2(g, lines);   
                // drawPolygon(g, polygonList, arraySize, noOfLineSegments);
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadAreaDisplacementErrorButtonActionPerformed

    private void loadVectorDisplacementErrorButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadVectorDisplacementErrorButtonActionPerformed
        try{
                removeMouseListener(mouseListener);
                //int n = Integer.parseInt(positionalUncertaintyTxtField.getText());  
                LinePerformance lp = new LinePerformance();
                setLiners(lp.vectorDisplacementError(getPoints2()));
                //displayLines2(g, lines);   
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadVectorDisplacementErrorButtonActionPerformed

    private void loadResetButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadResetButtonActionPerformed
         try{ 
                removeMouseListener(mouseListener);
                setPoints(null);     // Original line
                setPoints2(null);    // Simplified Line
                setPoints3(null);
                setLiners(null);
                chkOriginalLineButton.setEnabled(false);
                chkOriginalLineButton.setSelected(false);
                chkSimplifiedLineButton.setEnabled(false);
                chkSimplifiedLineButton.setSelected(false);
                //setPerformanceButtonsOff();
                txtNoOfPoints.setText("");
                txtNthPoint.setText("");
                txtPerpendicularDistance.setText("");
                txtRadialDistance.setText("");
                txtWidth.setText("");
                txtHeight.setText("");
                lblNoOfOriginalLinePtsValue.setText("0");
                lblNoOfSimplifiedLinePoints.setText("0");
                lblPercentageDecreaseValue.setText("0");
                lblRatioAngularityChangeValue.setText("0");
                
                lblSimplificationAlgorithm.setEnabled(false); 
                CboSimplificationAlgorithm.setEnabled(false);
                lblNoOfPoints.setEnabled(false);
                txtNoOfPoints.setEnabled(false);
                lblNthPoint.setEnabled(false);
                txtNthPoint.setEnabled(false);
                lblPerpendicularDistance.setEnabled(false);
                txtPerpendicularDistance.setEnabled(false);
                lblRadialDistance.setEnabled(false);
                txtRadialDistance.setEnabled(false);
                lblWidth.setEnabled(false);
                txtWidth.setEnabled(false);
                lblHeight.setEnabled(false);
                txtHeight.setEnabled(false);
                loadSimplifyButton.setEnabled(false);

                loadStepButton.setEnabled(false);
                loadVectorDisplacementErrorButton.setEnabled(false);
                loadAreaDisplacementErrorButton.setEnabled(false);
                loadRatioInChangeOfAngularityButton.setEnabled(false);
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadResetButtonActionPerformed

    private void loadRatioInChangeOfAngularityButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadRatioInChangeOfAngularityButtonActionPerformed
            try{
                removeMouseListener(mouseListener);
                LinePerformance lp = new LinePerformance();
                lp.ratioInChangeOfAngularity(points, points2);
                //displayLines2(g, lines);   
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadRatioInChangeOfAngularityButtonActionPerformed

    private void loadSaveADrawnLineToCSVFileButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadSaveADrawnLineToCSVFileButtonActionPerformed

            try{
                LineSimplificationFrame1 nf = new LineSimplificationFrame1();
                removeMouseListener(mouseListener);
                FileWrite fw = new FileWrite();
                File file = fw.saveCSVFile();
                //Get original line pts (getPoints()), and write line to file
                for (int i = 0; i < getPoints().size(); i++){
                    String ID = getPoints().get(i).getID();
                    int x = getPoints().get(i).getX();
                    int y = getPoints().get(i).getY();
                    String strLine = ID + "," + x + "," + y;
                    fw.appendWrite(file, strLine);
                }

                //Get rid of original line saved to clear the screen after it was saved to CSV above 
                setPoints(null);
                repaint();
                chkOriginalLineButton.setEnabled(false);
                chkOriginalLineButton.setSelected(false);
                lblNoOfOriginalLinePtsValue.setText("0");
               
            }   
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadSaveADrawnLineToCSVFileButtonActionPerformed

    private void loadDrawALineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadDrawALineButtonActionPerformed
        try{ 
                addMouseListener(mouseListener = new MouseAdapter(){   
                        // Original line

                        int count = 0;
                        ArrayList<Point> originalLinePts = new ArrayList<Point>();
                        @Override
                        public void mousePressed(MouseEvent e){
                            setPoints2(null);    // clear Simplified Line
                            setPoints3(null);    
                            setLiners(null);     // Clear sleeve lines and construction lines

                            count++;
                            Point p = capturePointClicked(e, count);
                            lblNoOfOriginalLinePtsValue.setText("" + count);
                            //if (p.getX() > getWidth()) {     // get Width of DisplayPanel
                            //    count--;
                            //}
                            //else{
                                //Save the point to original line if it is inside display panel 
                                originalLinePts.add(p); 
                                setPoints(originalLinePts);
                                repaint(); 
                            //}
                        }
                    });   
            }
            catch (Exception e){
                System.out.println("File not found"); 
            }
    }//GEN-LAST:event_loadDrawALineButtonActionPerformed

    private void chkOriginalLineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkOriginalLineButtonActionPerformed

        if(chkOriginalLineButton.isSelected() == true){
            setPoints(getPoints());
            repaint();
        }
        else{
             panel1.removeAll();
    
        panel1.revalidate();
        panel1.repaint();}})
        }
        
    }//GEN-LAST:event_chkOriginalLineButtonActionPerformed

    private void chkSimplifiedLineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSimplifiedLineButtonActionPerformed
        
        if(chkSimplifiedLineButton.isSelected() == true){
            setPoints2(getPoints2());
            repaint();
        }
        else{
            repaint();
        }
    }//GEN-LAST:event_chkSimplifiedLineButtonActionPerformed
     
    
    /**
     * displayLines 
     * 
     * Display Lines between pairs of points
     * @param pts
     * @param g
     */
    //Display all lines  //Added D Bullock
    public void displayLines(ArrayList<Point> pts, Graphics g){
        int j = 0;
        for(int i = 0; i < pts.size() - 1; i++){
            j = i + 1;
            Point p1 = pts.get(i);
            Point p2 = pts.get(j);

            Graphics2D g2 = (Graphics2D) g; 
            g2.setColor(Color.RED);

            g2.setStroke(new BasicStroke(3));
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(), 600 - p2.getY()));
            //g2.drawLine(p1.getX()+20,p1.getY()+10,p2.getX()+20,p2.getY()+10) ;
            //g2.drawLine(p1.getX(),600 - p1.getY(),p2.getX(),600 - p2.getY()) ;  //Good One; 
            repaint();
        }
    }

    public void displayLines3(ArrayList<Point> pts, Graphics g){
        int j = 0;
        for(int i = 0; i < pts.size() - 1; i++){
            j = i + 1;
            Point p1 = pts.get(i);
            Point p2 = pts.get(j);

            Graphics2D g2 = (Graphics2D) g; 
            g2.setColor(Color.BLUE);

            g2.setStroke(new BasicStroke(3));
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(), 600 - p2.getY()));
            //g2.drawLine(p1.getX()+20,p1.getY()+10,p2.getX()+20,p2.getY()+10) ;
            //g2.drawLine(p1.getX(),600 - p1.getY(),p2.getX(),600 - p2.getY()) ;  //Good One; 
            repaint();
        }
    }

    /**
     * Displays a Line.
     * 
     * The line is a line connecting 2 points.   
     * @param g - A Graphics object onto which the line is drawn between a pair of points.
     * @param lines
     */
    public void displayLines2(Graphics g, ArrayList<Liner> lines){   
        Point p1 = null; 
        Point p2 = null;

        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.BLUE);
        // g2.setStroke(new BasicStroke(3));

        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);
        for (int i = 0; i < lines.size(); i++){
            Liner line = lines.get(i);
            p1 = line.getLinerPoint1();
            p2 = line.getLinerPoint2();
            g2.draw(new Line2D.Float(p1.getX(), 600 - p1.getY(), p2.getX(), 600 - p2.getY()));
            repaint();

            //g2.drawLine((Integer) p1.getX(),(Integer) (600 - p1.getY()), (Integer)p2.getX(),(Integer) (600 - p2.getY())) ;
        }
    }

    /**
     * Draw Circle  (MOVE TO GRAPHICS LIBRARY)
     * 
     * Draws a Circle on the screen centred on a point with a String message
     * @param g 
     * @param point
     * @param radius
     */
    public void drawCircle(Graphics g, Point point, int radius){
        int x = point.getX();
        int y = 600 - (point.getY());

        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.GREEN);
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);

        //Centre circle using x,y and radius
        g.drawOval(x - radius, y - radius, radius * 2, radius * 2);   
    }

    /**
     * Draw graticule (MOVE TO GRAPHICS LIBRARY - NOT FINISHED)
     * 
     * Draw a graticule on the screen
     * @param g
     * @param width
     * @param height
     */
    public void drawGraticule(Graphics g, int width, int height){
        //Liner line = new Liner();     
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(Color.BLACK);
        Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {3,6}, 0);
        g2.setStroke(dotted);

        int x1 = 0;
        int x2 = 0;
        int y1 = 0;
        int y2 = 0;

        for (int i = 0; i < height; i = i + 100){
            x1 = x1 + 100;
            x2 = 600;
            y1 = 600 - i;
            y2 = 600 - i;
            g2.draw(new Line2D.Float(x1, y1, x2, y2));

            for(int j = 0; i < width; j = j + 100){
                //   x1 = x1 + 100;
                //   x2 = x2 + 100;
                //   g2.draw(x1,y1,x2,y2);
            }
        }
    }

    /**
     * Create text at point location   NEED TO DECIDE WHAT SUITABLE POSITION IS BASED ON MBR OF LINE?
     * 
     * @param g
     * @param p - point on the original line which is the midpoint of the line to label
     * @param caption 
     */
    public void createText(Graphics g, Point p, String caption){
        g.setColor(Color.BLACK);
        int x = p.getX();
        int y = p.getY();
        g.drawString(caption,x,600-y-10);
        g.setFont(new Font("TimesRoman", Font.PLAIN, 35));
    }

    /**
     * Draw polygon
     * 
     * @param g
     * @param polygonList
     * @param arraySize
     * @param nofOfLineSegments
     */
    public void drawPolygon(Graphics g, ArrayList<Point> polygonList, int arraySize, int noOfLineSegments){
        int[] x = new int[arraySize];
        int[] y = new int[arraySize];

        for (int i = 0; i < polygonList.size(); i++){
            x[i]=(polygonList.get(i).getX());
            y[i]=(polygonList.get(i).getY());
        }
        g.drawPolygon(x, y, noOfLineSegments);
    }   
    
  
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            javax.swing.UIManager.LookAndFeelInfo[] installedLookAndFeels=javax.swing.UIManager.getInstalledLookAndFeels();
            for (int idx=0; idx<installedLookAndFeels.length; idx++)
                if ("Nimbus".equals(installedLookAndFeels[idx].getName())) {
                    javax.swing.UIManager.setLookAndFeel(installedLookAndFeels[idx].getClassName());
                    break;
                }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LineSimplificationFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
            new LineSimplificationFrame().setVisible(true);            
                
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox CboSimplificationAlgorithm;
    private javax.swing.JCheckBox chkOriginalLineButton;
    private javax.swing.JCheckBox chkSimplifiedLineButton;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblAreaDisplacementValue;
    private javax.swing.JLabel lblHeight;
    private javax.swing.JLabel lblNoOfOriginalLinePts;
    private javax.swing.JLabel lblNoOfOriginalLinePtsValue;
    private javax.swing.JLabel lblNoOfPoints;
    private javax.swing.JLabel lblNoOfSimplifiedLinePoints;
    private javax.swing.JLabel lblNoOfSimplifiedLinePts;
    private javax.swing.JLabel lblNthPoint;
    private javax.swing.JLabel lblPercentageDecrease;
    private javax.swing.JLabel lblPercentageDecreaseValue;
    private javax.swing.JLabel lblPerpendicularDistance;
    private javax.swing.JLabel lblPositionalError;
    private javax.swing.JLabel lblPositionalErrorValue;
    private javax.swing.JLabel lblRadialDistance;
    private javax.swing.JLabel lblRatioAngularityChange;
    private javax.swing.JLabel lblRatioAngularityChangeValue;
    private javax.swing.JLabel lblSimplificationAlgorithm;
    private javax.swing.JLabel lblVectorDisplacement;
    private javax.swing.JLabel lblVectorDisplacementValue;
    private javax.swing.JLabel lblWidth;
    private javax.swing.JButton loadAreaDisplacementErrorButton;
    private javax.swing.JButton loadCSVFileButton;
    private javax.swing.JButton loadDrawALineButton;
    private javax.swing.JButton loadExitButton;
    private javax.swing.JButton loadRatioInChangeOfAngularityButton;
    private javax.swing.JButton loadResetButton;
    private javax.swing.JButton loadSaveADrawnLineToCSVFileButton;
    private javax.swing.JButton loadSaveCSVFileButton;
    private javax.swing.JButton loadSimplifyButton;
    private javax.swing.JButton loadStepButton;
    private javax.swing.JButton loadVectorDisplacementErrorButton;
    private javax.swing.JTextField txtHeight;
    private javax.swing.JTextField txtNoOfPoints;
    private javax.swing.JTextField txtNthPoint;
    private javax.swing.JTextField txtPerpendicularDistance;
    private javax.swing.JTextField txtRadialDistance;
    private javax.swing.JTextField txtWidth;
    // End of variables declaration//GEN-END:variables
       
}
